#include "MainWindow.h"
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QInputDialog>
#include <QLineEdit>
#include <QKeySequence>
#include <QApplication>
#include <QStatusBar>
#include <QFileInfo>
#include <QTextBlock>
#include <QTextDocument>
#include <QStringConverter>

MainWindow::MainWindow(const QString &configPath, QWidget *parent)
    : QMainWindow(parent)
    , m_editor(new Editor(this))
    , m_config(new ConfigManager(configPath, this))
    , m_currentFile()
    , m_modified(false)
    , m_lastFindText()
{
    setCentralWidget(m_editor);
    setMinimumSize(400, 300);
    resize(900, 600);

    setupMenu();
    applyConfigToEditor();
    updateWindowTitle();

    connect(m_editor, &Editor::modificationChanged,
            this, &MainWindow::onModificationChanged);
    connect(m_editor, &Editor::cursorPositionChanged,
            this, &MainWindow::onCursorPositionChanged);
    connect(m_config, &ConfigManager::configReloaded,
            this, &MainWindow::applyConfigToEditor);

    updateStatusBar();
}

void MainWindow::openFiles(const QStringList &paths)
{
    if (paths.isEmpty())
        return;
        
    for (const QString &path : paths) {
        loadFile(path);
    }


    for (int i = 0; i < paths.size(); ++i) {
        const QString &path = paths.at(i);
        
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qWarning() << "Could not open file:" << path << "-" << file.errorString();
            continue;
        }

        QTextStream in(&file);
        in.setEncoding(QStringConverter::Utf8);
        QString content = in.readAll();
        file.close();

        // For simplicity: load the last file in the main editor
        // To support tabs/multiple documents, extend Editor class accordingly
        if (i == paths.size() - 1) {
            m_editor->setPlainText(content);
            m_currentFile = path;
            m_editor->reapplyLineHeight();
            m_modified = false;
            m_editor->resetModified();
            updateWindowTitle();
            statusBar()->showMessage(tr("Opened %1").arg(path), 3000);
        } else {
            qDebug() << "Loaded (discarded):" << path;
        }
    }
}

void MainWindow::openFilesAndMaximize(const QStringList &paths)
{
    if (paths.isEmpty())
        return;

    for (const QString &path : paths) {
        loadFile(path);
    }

    // Show maximized for full-window experience
    showMaximized();
}


void MainWindow::setupMenu()
{
    KeyBindings *kb = m_config->keyBindings();

    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));

    auto addAction = [&](QMenu *menu, const QString &text, KeyBindings::Action action,
                         void (MainWindow::*slot)()) -> QAction * {
        QAction *a = menu->addAction(text);
        a->setShortcut(kb->binding(action));
        connect(a, &QAction::triggered, this, slot);
        return a;
    };

    addAction(fileMenu, tr("&New"), KeyBindings::New, &MainWindow::onNew);
    addAction(fileMenu, tr("&Open..."), KeyBindings::Open, &MainWindow::onOpen);
    fileMenu->addSeparator();
    addAction(fileMenu, tr("&Save"), KeyBindings::Save, &MainWindow::onSave);
    addAction(fileMenu, tr("Save &As..."), KeyBindings::SaveAs, &MainWindow::onSaveAs);
    fileMenu->addSeparator();
    {
        QAction *a = fileMenu->addAction(tr("&Quit"));
        a->setShortcut(kb->binding(KeyBindings::Quit));
        connect(a, &QAction::triggered, this, &QWidget::close);
    }

    QMenu *editMenu = menuBar()->addMenu(tr("&Edit"));
    addAction(editMenu, tr("&Find..."), KeyBindings::Find, &MainWindow::onFind);
    addAction(editMenu, tr("Find &Next"), KeyBindings::FindNext, &MainWindow::onFindNext);
    addAction(editMenu, tr("&Go to Line..."), KeyBindings::GotoLine, &MainWindow::onGotoLine);
    editMenu->addSeparator();
    addAction(editMenu, tr("Reload &Config"), KeyBindings::ReloadConfig, &MainWindow::onReloadConfig);
    addAction(editMenu, tr("Toggle &Word Wrap"), KeyBindings::ToggleWordWrap, &MainWindow::onToggleWordWrap);
    addAction(editMenu, tr("Toggle &Block Cursor"), KeyBindings::ToggleBlockCursor, &MainWindow::onToggleBlockCursor);
    editMenu->addSeparator();
    addAction(editMenu, tr("Increase Font"), KeyBindings::IncreaseFont, &MainWindow::onIncreaseFont);
    addAction(editMenu, tr("Decrease Font"), KeyBindings::DecreaseFont, &MainWindow::onDecreaseFont);

    QMenu *viewMenu = menuBar()->addMenu(tr("&View"));
    addAction(viewMenu, tr("&Full Screen"), KeyBindings::ToggleFullscreen, &MainWindow::onToggleFullscreen);
    addAction(viewMenu, tr("Show &Line Numbers"), KeyBindings::ToggleLineNumbers, &MainWindow::onToggleLineNumbers);
    addAction(viewMenu, tr("Highlight &Current Line"), KeyBindings::ToggleCurrentLine, &MainWindow::onToggleCurrentLine);
    addAction(viewMenu, tr("Show &Status Bar"), KeyBindings::ToggleStatusBar, &MainWindow::onToggleStatusBar);
}

void MainWindow::applyConfigToEditor()
{
    const EditorConfig &cfg = m_config->editorConfig();
    m_editor->setWordWrap(cfg.wordWrap);
    m_editor->setBorderSize(cfg.borderSize);
    m_editor->setBorderColor(cfg.borderColor);
    m_editor->setBackgroundColor(cfg.backgroundColor);
    m_editor->setCurrentLineColor(cfg.currentLineColor);
    m_editor->setLineNumberColor(cfg.lineNumberColor);
    m_editor->setBackgroundColor(cfg.backgroundColor);
    m_editor->setTextColor(cfg.textColor);
    m_editor->setBlockCursor(cfg.blockCursor);
    m_editor->setFontConfig(cfg.fontFamily, cfg.fontSize);
    m_editor->setLineHeight(cfg.lineHeight);
    m_editor->setPixelsAbove(cfg.pixelsAbove);
    m_editor->setPixelsBelow(cfg.pixelsBelow);
    m_editor->setLineDistance(cfg.lineDistance);
    m_editor->setLineNumbersVisible(cfg.showLineNumbers);
    m_editor->setHighlightCurrentLine(cfg.highlightCurrentLine);
    statusBar()->setVisible(cfg.showStatusBar);
    updateStatusBar();
}

void MainWindow::reloadConfig()
{
    m_config->reload();
    statusBar()->showMessage(tr("Config reloaded"), 2000);
}

void MainWindow::updateWindowTitle()
{
    QString name = m_currentFile.isEmpty()
                       ? tr("Untitled")
                       : QFileInfo(m_currentFile).fileName();
    QString title = QStringLiteral("slate — %1").arg(name);
    if (m_modified)
        title += QStringLiteral(" [modified]");
    setWindowTitle(title);
}

bool MainWindow::maybeSave()
{
    if (!m_modified)
        return true;

    QMessageBox::StandardButton ret = QMessageBox::warning(
        this,
        tr("slate"),
        tr("The document has been modified.\nDo you want to save your changes?"),
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);

    if (ret == QMessageBox::Save) {
        onSave();
        return !m_modified;
    }
    if (ret == QMessageBox::Cancel)
        return false;
    return true;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (maybeSave())
        event->accept();
    else
        event->ignore();
}

void MainWindow::onNew()
{
    if (!maybeSave())
        return;
    m_editor->clear();
    m_editor->resetModified();
    m_currentFile.clear();
    m_modified = false;
    updateWindowTitle();
}

void MainWindow::onOpen()
{
    if (!maybeSave())
        return;

    QString path = QFileDialog::getOpenFileName(
        this, tr("Open File"), QString(),
        tr("Text files (*.txt *.md *.cpp *.h *.py *.ini);;All files (*)"));
    if (path.isEmpty())
        return;

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("slate"),
                             tr("Cannot open file:\n%1").arg(file.errorString()));
        return;
    }

    QTextStream in(&file);
    in.setEncoding(QStringConverter::Utf8);
    m_editor->setPlainText(in.readAll());
    file.close();
    m_editor->reapplyLineHeight();

    m_currentFile = path;
    m_editor->resetModified();
    m_modified = false;
    updateWindowTitle();
    statusBar()->showMessage(tr("Opened %1").arg(path), 3000);
}

bool MainWindow::saveToFile(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("slate"),
                             tr("Cannot write file:\n%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out << m_editor->toPlainText();
    file.close();

    m_currentFile = path;
    m_editor->resetModified();
    m_modified = false;
    updateWindowTitle();
    statusBar()->showMessage(tr("Saved %1").arg(path), 3000);
    return true;
}

void MainWindow::onSave()
{
    if (m_currentFile.isEmpty()) {
        onSaveAs();
        return;
    }
    saveToFile(m_currentFile);
}

void MainWindow::onSaveAs()
{
    QString path = QFileDialog::getSaveFileName(
        this, tr("Save As"), m_currentFile.isEmpty() ? QString() : m_currentFile,
        tr("Text files (*.txt);;All files (*)"));
    if (path.isEmpty())
        return;
    saveToFile(path);
}

void MainWindow::onFind()
{
    bool ok = false;
    QString text = QInputDialog::getText(this, tr("Find"), tr("Find:"),
                                         QLineEdit::Normal, m_lastFindText, &ok);
    if (!ok || text.isEmpty())
        return;

    m_lastFindText = text;
    if (!m_editor->find(text)) {
        QTextCursor c = m_editor->textCursor();
        c.movePosition(QTextCursor::Start);
        m_editor->setTextCursor(c);
        if (!m_editor->find(text))
            statusBar()->showMessage(tr("Not found: %1").arg(text), 2000);
        else
            statusBar()->showMessage(tr("Found (wrapped)"), 1500);
    }
}

void MainWindow::onFindNext()
{
    if (m_lastFindText.isEmpty()) {
        onFind();
        return;
    }
    if (!m_editor->find(m_lastFindText)) {
        QTextCursor c = m_editor->textCursor();
        c.movePosition(QTextCursor::Start);
        m_editor->setTextCursor(c);
        if (!m_editor->find(m_lastFindText))
            statusBar()->showMessage(tr("Not found: %1").arg(m_lastFindText), 2000);
        else
            statusBar()->showMessage(tr("Found (wrapped)"), 1500);
    }
}

void MainWindow::onGotoLine()
{
    const int maxLine = m_editor->document()->blockCount();
    bool ok = false;
    int line = QInputDialog::getInt(this, tr("Go to Line"),
                                    tr("Line number (1–%1):").arg(maxLine),
                                    m_editor->textCursor().blockNumber() + 1,
                                    1, maxLine, 1, &ok);
    if (!ok)
        return;

    QTextBlock block = m_editor->document()->findBlockByNumber(line - 1);
    if (!block.isValid())
        return;
    QTextCursor c(block);
    m_editor->setTextCursor(c);
    m_editor->ensureCursorVisible();
    updateStatusBar();
}

void MainWindow::onReloadConfig()
{
    reloadConfig();
}

void MainWindow::onToggleWordWrap()
{
    bool currentlyWrapped = (m_editor->lineWrapMode() != QTextEdit::NoWrap);
    m_editor->setWordWrap(!currentlyWrapped);
    statusBar()->showMessage(currentlyWrapped ? tr("Word wrap off") : tr("Word wrap on"), 1500);
}

void MainWindow::onToggleBlockCursor()
{
    bool next = !m_editor->isBlockCursor();
    m_editor->setBlockCursor(next);
    statusBar()->showMessage(next ? tr("Block cursor") : tr("Beam cursor"), 1500);
}

void MainWindow::onIncreaseFont()
{
    QFont f = m_editor->font();
    f.setPointSize(f.pointSize() + 1);
    m_editor->setFontConfig(f.family(), f.pointSize());
}

void MainWindow::onDecreaseFont()
{
    QFont f = m_editor->font();
    int sz = f.pointSize() - 1;
    if (sz < 6)
        sz = 6;
    m_editor->setFontConfig(f.family(), sz);
}

void MainWindow::onToggleFullscreen()
{
    if (isFullScreen())
        showNormal();
    else
        showFullScreen();
}

void MainWindow::onToggleLineNumbers()
{
    bool next = !m_editor->lineNumbersVisible();
    m_editor->setLineNumbersVisible(next);
    statusBar()->showMessage(next ? tr("Line numbers on") : tr("Line numbers off"), 1500);
}

void MainWindow::onToggleCurrentLine()
{
    bool next = !m_editor->highlightCurrentLineEnabled();
    m_editor->setHighlightCurrentLine(next);
    statusBar()->showMessage(next ? tr("Current line highlight on")
                                  : tr("Current line highlight off"), 1500);
}

void MainWindow::onToggleStatusBar()
{
    bool next = !statusBar()->isVisible();
    statusBar()->setVisible(next);
    if (next)
        updateStatusBar();
}

void MainWindow::updateStatusBar()
{
    if (!statusBar()->isVisible())
        return;
    QTextCursor c = m_editor->textCursor();
    const int line = c.blockNumber() + 1;
    const int col = c.positionInBlock() + 1;
    statusBar()->showMessage(tr("Ln %1, Col %2").arg(line).arg(col));
}

void MainWindow::onCursorPositionChanged()
{
    updateStatusBar();
}

void MainWindow::onModificationChanged(bool modified)
{
    m_modified = modified;
    updateWindowTitle();
}


void MainWindow::loadFile(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Could not open file:" << path << "-" << file.errorString();
        return;
    }

    QTextStream in(&file);
    in.setEncoding(QStringConverter::Utf8);
    m_editor->setPlainText(in.readAll());
    file.close();
    m_editor->reapplyLineHeight();

    m_currentFile = path;
    m_editor->resetModified();
    m_modified = false;
    updateWindowTitle();
    statusBar()->showMessage(tr("Opened %1").arg(path), 3000);
}



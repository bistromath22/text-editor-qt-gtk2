#include "ConfigManager.h"
#include <QSettings>
#include <QFileInfo>
#include <QDebug>

ConfigManager::ConfigManager(const QString &configPath, QObject *parent)
    : QObject(parent)
    , m_configPath(configPath)
    , m_keyBindings(new KeyBindings())
{
    load();
}

ConfigManager::~ConfigManager()
{
    delete m_keyBindings;
    m_keyBindings = nullptr;
}

void ConfigManager::load()
{
    parseConfig();
}

void ConfigManager::reload()
{
    parseConfig();
    emit configReloaded();
}

void ConfigManager::parseConfig()
{
    m_config = EditorConfig{};
    delete m_keyBindings;
    m_keyBindings = new KeyBindings();

    if (m_configPath.isEmpty() || !QFileInfo::exists(m_configPath)) {
        m_valid = false;
        qWarning() << "Config file not found:" << m_configPath << "— using defaults";
        return;
    }

    QSettings settings(m_configPath, QSettings::IniFormat);
    if (settings.status() != QSettings::NoError) {
        m_valid = false;
        qWarning() << "Failed to parse config:" << m_configPath;
        return;
    }

    m_valid = true;
    settings.beginGroup(QStringLiteral("editor"));

    if (settings.contains(QStringLiteral("wordwrap")))
        m_config.wordWrap = settings.value(QStringLiteral("wordwrap")).toBool();

    if (settings.contains(QStringLiteral("border_size"))) {
        bool ok = false;
        int v = settings.value(QStringLiteral("border_size")).toInt(&ok);
        if (ok && v >= 0)
            m_config.borderSize = v;
        else
            qWarning() << "Invalid border_size, using default";
    }

    if (settings.contains(QStringLiteral("border_color"))) {
        QColor c(settings.value(QStringLiteral("border_color")).toString().trimmed());
        if (c.isValid())
            m_config.borderColor = c;
        else
            qWarning() << "Invalid border_color";
    }

    if (settings.contains(QStringLiteral("background_color"))) {
        QColor c(settings.value(QStringLiteral("background_color")).toString().trimmed());
        if (c.isValid())
            m_config.backgroundColor = c;
        else
            qWarning() << "Invalid background_color";
    }

    if (settings.contains(QStringLiteral("current_line_color"))) {
        QString hex = settings.value(QStringLiteral("current_line_color")).toString().trimmed();
        if (!hex.isEmpty()) {
            QColor c(hex);
            if (c.isValid())
                m_config.currentLineColor = c;
            else
                qWarning() << "Invalid current_line_color";
        }
    }

    if (settings.contains(QStringLiteral("line_number_color"))) {
        QColor c(settings.value(QStringLiteral("line_number_color")).toString().trimmed());
        if (c.isValid())
            m_config.lineNumberColor = c;
        else
            qWarning() << "Invalid line_number_color";
    }

    if (settings.contains(QStringLiteral("text_color"))) {
        QColor c(settings.value(QStringLiteral("text_color")).toString().trimmed());
        if (c.isValid())
            m_config.textColor = c;
        else
            qWarning() << "Invalid text_color";
    }

    if (settings.contains(QStringLiteral("block_cursor")))
        m_config.blockCursor = settings.value(QStringLiteral("block_cursor")).toBool();

    if (settings.contains(QStringLiteral("font_family"))) {
        QString fam = settings.value(QStringLiteral("font_family")).toString().trimmed();
        if (!fam.isEmpty())
            m_config.fontFamily = fam;
    }

    if (settings.contains(QStringLiteral("font_size"))) {
        bool ok = false;
        int v = settings.value(QStringLiteral("font_size")).toInt(&ok);
        if (ok && v > 0 && v < 200)
            m_config.fontSize = v;
        else
            qWarning() << "Invalid font_size, using default";
    }

    if (settings.contains(QStringLiteral("line_height"))) {
        bool ok = false;
        qreal v = settings.value(QStringLiteral("line_height")).toDouble(&ok);
        if (ok && v > 0.0 && v < 10.0)
            m_config.lineHeight = v;
        else
            qWarning() << "Invalid line_height, using default";
    }

    auto loadNonNegInt = [&](const char *key, int &dest) {
        if (!settings.contains(QString::fromLatin1(key)))
            return;
        bool ok = false;
        int v = settings.value(QString::fromLatin1(key)).toInt(&ok);
        if (ok && v >= 0 && v < 200)
            dest = v;
        else
            qWarning() << "Invalid" << key << "— using default";
    };
    loadNonNegInt("pixels_above", m_config.pixelsAbove);
    loadNonNegInt("pixels_below", m_config.pixelsBelow);
    loadNonNegInt("line_distance", m_config.lineDistance);

    if (settings.contains(QStringLiteral("show_line_numbers")))
        m_config.showLineNumbers = settings.value(QStringLiteral("show_line_numbers")).toBool();

    if (settings.contains(QStringLiteral("highlight_current_line")))
        m_config.highlightCurrentLine = settings.value(QStringLiteral("highlight_current_line")).toBool();

    if (settings.contains(QStringLiteral("show_statusbar")))
        m_config.showStatusBar = settings.value(QStringLiteral("show_statusbar")).toBool();

    settings.endGroup();
    m_keyBindings->loadFromSettings(settings);
}

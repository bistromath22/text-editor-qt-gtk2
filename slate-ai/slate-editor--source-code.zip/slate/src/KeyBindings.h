#pragma once

#include <QHash>
#include <QKeySequence>
#include <QSettings>
#include <QString>

class KeyBindings
{
public:
    enum Action {
        New,
        Open,
        Save,
        SaveAs,
        Quit,
        Find,
        ReloadConfig,
        ToggleWordWrap,
        ToggleBlockCursor,
        IncreaseFont,
        DecreaseFont,
        ToggleFullscreen,
        ToggleLineNumbers,
        ToggleCurrentLine,
        ToggleStatusBar,
        FindNext,
        GotoLine
    };

    explicit KeyBindings()
    {
        setDefaults();
    }

    void loadFromSettings(QSettings &settings)
    {
        settings.beginGroup(QStringLiteral("shortcuts"));

        auto load = [&](const QString &key, Action action) {
            if (settings.contains(key)) {
                const QString value = settings.value(key).toString().trimmed();
                if (!value.isEmpty()) {
                    QKeySequence seq(value);
                    if (!seq.isEmpty())
                        m_bindings[action] = seq;
                }
            }
        };

        load(QStringLiteral("new_file"), New);
        load(QStringLiteral("open"), Open);
        load(QStringLiteral("save"), Save);
        load(QStringLiteral("save_as"), SaveAs);
        load(QStringLiteral("quit"), Quit);
        load(QStringLiteral("find"), Find);
        load(QStringLiteral("reload_config"), ReloadConfig);
        load(QStringLiteral("toggle_wordwrap"), ToggleWordWrap);
        load(QStringLiteral("toggle_block_cursor"), ToggleBlockCursor);
        load(QStringLiteral("increase_font"), IncreaseFont);
        load(QStringLiteral("decrease_font"), DecreaseFont);
        load(QStringLiteral("fullscreen"), ToggleFullscreen);
        load(QStringLiteral("toggle_line_numbers"), ToggleLineNumbers);
        load(QStringLiteral("toggle_current_line"), ToggleCurrentLine);
        load(QStringLiteral("toggle_statusbar"), ToggleStatusBar);
        load(QStringLiteral("find_next"), FindNext);
        load(QStringLiteral("goto_line"), GotoLine);

        settings.endGroup();
    }

    QKeySequence binding(Action action) const
    {
        return m_bindings.value(action);
    }

    void setBinding(Action action, const QKeySequence &seq)
    {
        m_bindings[action] = seq;
    }

private:
    QHash<Action, QKeySequence> m_bindings;

    void setDefaults()
    {
        m_bindings[New]               = QKeySequence(QStringLiteral("Ctrl+N"));
        m_bindings[Open]              = QKeySequence(QStringLiteral("Ctrl+O"));
        m_bindings[Save]              = QKeySequence(QStringLiteral("Ctrl+S"));
        m_bindings[SaveAs]            = QKeySequence(QStringLiteral("Ctrl+Shift+S"));
        m_bindings[Quit]              = QKeySequence(QStringLiteral("Ctrl+Q"));
        m_bindings[Find]              = QKeySequence(QStringLiteral("Ctrl+F"));
        m_bindings[ReloadConfig]      = QKeySequence(QStringLiteral("Ctrl+R"));
        m_bindings[ToggleWordWrap]    = QKeySequence(QStringLiteral("Ctrl+W"));
        m_bindings[ToggleBlockCursor] = QKeySequence(QStringLiteral("Ctrl+B"));
        m_bindings[IncreaseFont]      = QKeySequence(QStringLiteral("Ctrl++"));
        m_bindings[DecreaseFont]      = QKeySequence(QStringLiteral("Ctrl+-"));
        m_bindings[ToggleFullscreen]   = QKeySequence(QStringLiteral("F11"));
        m_bindings[ToggleLineNumbers]  = QKeySequence(QStringLiteral("Ctrl+L"));
        m_bindings[ToggleCurrentLine]  = QKeySequence(QStringLiteral("Ctrl+H"));
        m_bindings[ToggleStatusBar]    = QKeySequence(QStringLiteral("Ctrl+Shift+B"));
        m_bindings[FindNext]           = QKeySequence(QStringLiteral("F3"));
        m_bindings[GotoLine]           = QKeySequence(QStringLiteral("Ctrl+G"));
    }
};

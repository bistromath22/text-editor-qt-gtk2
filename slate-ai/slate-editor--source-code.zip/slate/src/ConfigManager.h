#pragma once

#include <QObject>
#include <QString>
#include <QColor>
#include "KeyBindings.h"

struct EditorConfig {
    bool wordWrap = true;
    int borderSize = 20;
    QColor borderColor = QColor(QStringLiteral("#313244"));
    QColor backgroundColor = QColor(QStringLiteral("#1e1e2e"));
    QColor currentLineColor;          // invalid = auto lighter(background)
    QColor lineNumberColor = QColor(QStringLiteral("#6c7086"));
    QColor textColor = QColor(QStringLiteral("#cdd6f4"));
    bool blockCursor = true;
    QString fontFamily = QStringLiteral("Monaco");
    int fontSize = 18;
    qreal lineHeight = 1.4;
    int pixelsAbove = 0;
    int pixelsBelow = 0;
    int lineDistance = 0;
    bool showLineNumbers = false;
    bool highlightCurrentLine = true;
    bool showStatusBar = false;
};

class ConfigManager : public QObject
{
    Q_OBJECT
public:
    explicit ConfigManager(const QString &configPath, QObject *parent = nullptr);
    ~ConfigManager() override;

    void load();
    void reload();

    const EditorConfig &editorConfig() const { return m_config; }
    KeyBindings *keyBindings() const { return m_keyBindings; }
    QString configPath() const { return m_configPath; }
    bool isValid() const { return m_valid; }

signals:
    void configReloaded();

private:
    void parseConfig();

    QString m_configPath;
    EditorConfig m_config;
    KeyBindings *m_keyBindings;
    bool m_valid = false;
};

#pragma once

#include <QTextEdit>
#include <QColor>
#include <QWidget>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QTextBlock>

class LineNumberArea;

class Editor : public QTextEdit
{
    Q_OBJECT
public:
    explicit Editor(QWidget *parent = nullptr);

    void setWordWrap(bool enabled);
    void setBorderSize(int pixels);
    void setBorderColor(const QColor &color);
    void setBackgroundColor(const QColor &color);
    void setCurrentLineColor(const QColor &color);  // invalid = auto
    void setLineNumberColor(const QColor &color);
    void setTextColor(const QColor &color);
    void setBlockCursor(bool enabled);
    void setFontConfig(const QString &family, int size);
    void setLineHeight(qreal multiplier);
    void setPixelsAbove(int pixels);
    void setPixelsBelow(int pixels);
    void setLineDistance(int pixels);
    void setLineNumbersVisible(bool visible);
    void setHighlightCurrentLine(bool enabled);

    bool isBlockCursor() const { return m_blockCursor; }
    bool lineNumbersVisible() const { return m_showLineNumbers; }
    bool highlightCurrentLineEnabled() const { return m_highlightCurrentLine; }
    bool isModified() const;
    void resetModified();
    void reapplyLineHeight();

    // Overrides that also re-apply line metrics after bulk text changes
    void setPlainText(const QString &text);
    void clear();

    void lineNumberAreaPaintEvent(QPaintEvent *event);
    int lineNumberAreaWidth() const;

signals:
    void modificationChanged(bool modified);

protected:
    void resizeEvent(QResizeEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void updateLineNumberAreaWidth(int newBlockCount = 0);
    void updateLineNumberArea(const QRect &rect, int dy);
    void onTextChanged();
    void highlightCurrentLine();
    void onBlockCountChanged(int newBlockCount);

private:
    void applyLineHeightToDocument();
    void applyLineHeightToBlock(const QTextBlock &block);
    void applyChromeColors();

    LineNumberArea *m_lineNumberArea;
    bool m_blockCursor = false;
    bool m_showLineNumbers = true;
    bool m_highlightCurrentLine = true;
    int m_borderSize = 8;
    QColor m_borderColor = QColor(QStringLiteral("#313244"));
    QColor m_backgroundColor = QColor(QStringLiteral("#1e1e2e"));
    QColor m_currentLineColor;  // invalid = auto lighter(background)
    QColor m_lineNumberColor = QColor(QStringLiteral("#6c7086"));
    QColor m_textColor = QColor(QStringLiteral("#cdd6f4"));
    qreal m_lineHeightMultiplier = 1.4;
    int m_pixelsAbove = 0;
    int m_pixelsBelow = 0;
    int m_lineDistance = 0;
    bool m_modified = false;
    bool m_applyingLineHeight = false;
};

class LineNumberArea : public QWidget
{
public:
    explicit LineNumberArea(Editor *editor)
        : QWidget(editor)
        , m_editor(editor)
    {}

    QSize sizeHint() const override
    {
        return QSize(m_editor->lineNumberAreaWidth(), 0);
    }

protected:
    void paintEvent(QPaintEvent *event) override
    {
        m_editor->lineNumberAreaPaintEvent(event);
    }

private:
    Editor *m_editor;
};

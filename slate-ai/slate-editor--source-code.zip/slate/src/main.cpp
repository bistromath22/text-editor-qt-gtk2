#include <QApplication>
#include <QCommandLineParser>
#include <QDir>
#include <QFileInfo>
#include <QStandardPaths>
#include <QTextStream>
#include "MainWindow.h"

static QString userConfigPath()
{
    return QStandardPaths::writableLocation(QStandardPaths::ConfigLocation)
           + QStringLiteral("/slate/config.ini");
}

static QString discoverConfigPath()
{
    // 1. Current working directory
    if (QFileInfo::exists(QStringLiteral("config.ini")))
        return QDir::current().absoluteFilePath(QStringLiteral("config.ini"));

    // 2. ~/.config/slate/config.ini
    const QString userConfig = userConfigPath();
    if (QFileInfo::exists(userConfig))
        return userConfig;

    // 3. /etc/slate/config.ini
    if (QFileInfo::exists(QStringLiteral("/etc/slate/config.ini")))
        return QStringLiteral("/etc/slate/config.ini");

    // Fall back to user config path (will use defaults if missing)
    return userConfig;
}

static QStringList configSearchPaths()
{
    return {
        QDir::current().absoluteFilePath(QStringLiteral("config.ini")),
        userConfigPath(),
        QStringLiteral("/etc/slate/config.ini")
    };
}

static QString defaultConfigText()
{
    // Keep in sync with the shipped config.ini
    return QStringLiteral(
        "[editor]\n"
        "wordwrap=true\n"
        "border_size=8\n"
        "border_color=#313244\n"
        "background_color=#1e1e2e\n"
        "current_line_color=#313244\n"
        "line_number_color=#6c7086\n"
        "text_color=#cdd6f4\n"
        "block_cursor=false\n"
        "font_family=Monospace\n"
        "font_size=12\n"
        "line_height=1.4\n"
        "pixels_above=0\n"
        "pixels_below=0\n"
        "line_distance=0\n"
        "show_line_numbers=true\n"
        "highlight_current_line=true\n"
        "show_statusbar=true\n"
        "\n"
        "[shortcuts]\n"
        "open=Ctrl+O\n"
        "save=Ctrl+S\n"
        "save_as=Ctrl+Shift+S\n"
        "quit=Ctrl+Q\n"
        "find=Ctrl+F\n"
        "find_next=F3\n"
        "goto_line=Ctrl+G\n"
        "reload_config=Ctrl+R\n"
        "new_file=Ctrl+N\n"
        "toggle_wordwrap=Ctrl+W\n"
        "toggle_block_cursor=Ctrl+B\n"
        "increase_font=Ctrl++\n"
        "decrease_font=Ctrl+-\n"
        "fullscreen=F11\n"
        "toggle_line_numbers=Ctrl+L\n"
        "toggle_current_line=Ctrl+H\n"
        "toggle_statusbar=Ctrl+Shift+B\n"
    );
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("slate"));
    QApplication::setApplicationVersion(QStringLiteral("1.0"));
    QApplication::setOrganizationName(QStringLiteral("slate"));

    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("slate — a fast, lightweight text editor"));
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption configOpt(
        QStringList() << QStringLiteral("c") << QStringLiteral("config"),
        QStringLiteral("Path to config.ini"),
        QStringLiteral("path"));
    parser.addOption(configOpt);

    QCommandLineOption printConfigOpt(
        QStringLiteral("print-config"),
        QStringLiteral("Print the default config.ini to stdout and exit"));
    parser.addOption(printConfigOpt);

    QCommandLineOption printPathsOpt(
        QStringLiteral("print-config-paths"),
        QStringLiteral("Print config search paths (and which exist) and exit"));
    parser.addOption(printPathsOpt);

    // Allow positional arguments (file names to open)
    parser.addPositionalArgument(
        QStringLiteral("files"),
        QStringLiteral("File(s) to open"),
        QStringLiteral("[files...]"));

    parser.process(app);

    QTextStream out(stdout);

    if (parser.isSet(printConfigOpt)) {
        out << defaultConfigText();
        out.flush();
        return 0;
    }

    if (parser.isSet(printPathsOpt)) {
        const QString active = parser.isSet(configOpt)
                                   ? parser.value(configOpt)
                                   : discoverConfigPath();
        out << "Search order:\n";
        const QStringList paths = configSearchPaths();
        for (int i = 0; i < paths.size(); ++i) {
            const QString &p = paths.at(i);
            const bool exists = QFileInfo::exists(p);
            out << QStringLiteral("  %1. %2  [%3]\n")
                       .arg(i + 1)
                       .arg(p, exists ? QStringLiteral("found") : QStringLiteral("missing"));
        }
        out << QStringLiteral("\nActive path: %1  [%2]\n")
                   .arg(active, QFileInfo::exists(active) ? QStringLiteral("found")
                                                          : QStringLiteral("missing — using built-in defaults"));
        out.flush();
        return 0;
    }

    const QString configPath = parser.isSet(configOpt)
                                   ? parser.value(configOpt)
                                   : discoverConfigPath();
    MainWindow window(configPath);
    
    // Get positional arguments (file names)
    QStringList files = parser.positionalArguments();
    
    // Pass files to the main window for opening
    if (!files.isEmpty()) {
		window.openFilesAndMaximize(files);  // <-- Changed here
	} else {
		// Normal startup - show regular size
		window.show();
	}

    return app.exec();
}


#pragma once

#include <QMainWindow>
#include <QCloseEvent>
#include <QString>
#include <QStringList>
#include "Editor.h"
#include "ConfigManager.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(const QString &configPath, QWidget *parent = nullptr);
    void reloadConfig();
    void openFiles(const QStringList &paths);
    void openFilesAndMaximize(const QStringList &paths);

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onNew();
    void onOpen();
    void onSave();
    void onSaveAs();
    void onFind();
    void onFindNext();
    void onGotoLine();
    void onReloadConfig();
    void onToggleWordWrap();
    void onToggleBlockCursor();
    void onIncreaseFont();
    void onDecreaseFont();
    void onToggleFullscreen();
    void onToggleLineNumbers();
    void onToggleCurrentLine();
    void onToggleStatusBar();
    void onModificationChanged(bool modified);
    void onCursorPositionChanged();

private:
    void setupMenu();
    void applyConfigToEditor();
    void updateWindowTitle();
    void updateStatusBar();
    bool maybeSave();
    bool saveToFile(const QString &path);
    void loadFile(const QString &path);

    Editor *m_editor;
    ConfigManager *m_config;
    QString m_currentFile;
    QString m_lastFindText;
    bool m_modified = false;
};



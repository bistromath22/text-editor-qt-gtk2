#include "Editor.h"
#include <QPainter>
#include <QTextBlock>
#include <QScrollBar>
#include <QFontMetrics>
#include <QKeyEvent>
#include <QPalette>
#include <QApplication>
#include <QTextCursor>
#include <QAbstractTextDocumentLayout>
#include <QTextOption>

Editor::Editor(QWidget *parent)
    : QTextEdit(parent)
    , m_lineNumberArea(new LineNumberArea(this))
{
    // QTextEdit honors FixedHeight / margins; QPlainTextEdit often ignores them
    setAcceptRichText(false);
    setUndoRedoEnabled(true);
    setTabStopDistance(fontMetrics().horizontalAdvance(QLatin1Char(' ')) * 4);

    setWordWrap(true);
    setBorderSize(8);
    setBorderColor(QColor(QStringLiteral("#313244")));
    setBackgroundColor(QColor(QStringLiteral("#1e1e2e")));
    setBlockCursor(false);
    setFontConfig(QStringLiteral("Monospace"), 12);
    setLineHeight(1.4);

    connect(document(), &QTextDocument::blockCountChanged,
            this, &Editor::updateLineNumberAreaWidth);
    connect(document(), &QTextDocument::blockCountChanged,
            this, &Editor::onBlockCountChanged);
    connect(document(), &QTextDocument::contentsChanged,
            this, &Editor::onTextChanged);
    connect(this, &Editor::cursorPositionChanged,
            this, &Editor::highlightCurrentLine);
    connect(verticalScrollBar(), &QScrollBar::valueChanged, this, [this](int) {
        m_lineNumberArea->update();
    });
    connect(document()->documentLayout(),
            &QAbstractTextDocumentLayout::update,
            this, [this](const QRectF &) {
        m_lineNumberArea->update();
    });

    updateLineNumberAreaWidth();
    highlightCurrentLine();
}

void Editor::setPlainText(const QString &text)
{
    QTextEdit::setPlainText(text);
    reapplyLineHeight();
    resetModified();
}

void Editor::clear()
{
    QTextEdit::clear();
    reapplyLineHeight();
}



void Editor::setWordWrap(bool enabled)
{
    if (enabled) {
        setLineWrapMode(QTextEdit::WidgetWidth);
        setWordWrapMode(QTextOption::WrapAtWordBoundaryOrAnywhere);
    } else {
        setLineWrapMode(QTextEdit::NoWrap);
    }
}

void Editor::setBorderSize(int pixels)
{
    m_borderSize = qMax(0, pixels);
    setViewportMargins(lineNumberAreaWidth(), m_borderSize, m_borderSize, m_borderSize);
}

void Editor::applyChromeColors()
{
    // Viewport = text background; widget frame/margins use border color via palette
    setAutoFillBackground(true);
    viewport()->setAutoFillBackground(true);

    QPalette wp = palette();
    wp.setColor(QPalette::Window, m_borderColor);
    wp.setColor(QPalette::Base, m_backgroundColor);
    wp.setColor(QPalette::Text, m_textColor);
    setPalette(wp);

    QPalette vp = viewport()->palette();
    vp.setColor(QPalette::Base, m_backgroundColor);
    vp.setColor(QPalette::Text, m_textColor);
    viewport()->setPalette(vp);

    m_lineNumberArea->update();
    update();
}

void Editor::setBorderColor(const QColor &color)
{
    if (!color.isValid())
        return;
    m_borderColor = color;
    applyChromeColors();
}

void Editor::setBackgroundColor(const QColor &color)
{
    if (!color.isValid())
        return;
    m_backgroundColor = color;
    applyChromeColors();
    highlightCurrentLine();
}

void Editor::setCurrentLineColor(const QColor &color)
{
    // Invalid color means "auto" (derived from background)
    m_currentLineColor = color;
    highlightCurrentLine();
}

void Editor::setLineNumberColor(const QColor &color)
{
    if (!color.isValid())
        return;
    m_lineNumberColor = color;
    m_lineNumberArea->update();
}

void Editor::setTextColor(const QColor &color)
{
    if (!color.isValid())
        return;
    m_textColor = color;
    applyChromeColors();
}

void Editor::setBlockCursor(bool enabled)
{
    m_blockCursor = enabled;
    if (enabled) {
        setCursorWidth(fontMetrics().horizontalAdvance(QLatin1Char('M')));
        QApplication::setCursorFlashTime(0);
    } else {
        setCursorWidth(1);
        QApplication::setCursorFlashTime(1000);
    }
}

void Editor::setFontConfig(const QString &family, int size)
{
    QFont f(family, size);
    f.setStyleHint(QFont::Monospace);
    setFont(f);
    document()->setDefaultFont(f);
    setTabStopDistance(fontMetrics().horizontalAdvance(QLatin1Char(' ')) * 4);

    if (m_blockCursor)
        setCursorWidth(fontMetrics().horizontalAdvance(QLatin1Char('M')));

    updateLineNumberAreaWidth();
    applyLineHeightToDocument();
}

void Editor::setLineHeight(qreal multiplier)
{
    m_lineHeightMultiplier = qBound(0.5, multiplier, 5.0);
    applyLineHeightToDocument();
}

void Editor::setPixelsAbove(int pixels)
{
    m_pixelsAbove = qMax(0, pixels);
    applyLineHeightToDocument();
}

void Editor::setPixelsBelow(int pixels)
{
    m_pixelsBelow = qMax(0, pixels);
    applyLineHeightToDocument();
}

void Editor::setLineDistance(int pixels)
{
    m_lineDistance = qMax(0, pixels);
    applyLineHeightToDocument();
}

void Editor::setLineNumbersVisible(bool visible)
{
    m_showLineNumbers = visible;
    m_lineNumberArea->setVisible(visible);
    updateLineNumberAreaWidth();
}

void Editor::setHighlightCurrentLine(bool enabled)
{
    m_highlightCurrentLine = enabled;
    highlightCurrentLine();
}

void Editor::reapplyLineHeight()
{
    applyLineHeightToDocument();
}

void Editor::applyLineHeightToBlock(const QTextBlock &block)
{
    if (!block.isValid())
        return;

    const int base = QFontMetrics(document()->defaultFont()).lineSpacing();
    const int px = qMax(1, qRound(base * m_lineHeightMultiplier) + m_lineDistance);

    QTextCursor bc(block);
    QTextBlockFormat fmt = block.blockFormat();
    bool changed = false;

    if (fmt.lineHeightType() != QTextBlockFormat::FixedHeight || fmt.lineHeight() != px) {
        fmt.setLineHeight(px, QTextBlockFormat::FixedHeight);
        changed = true;
    }
    if (static_cast<int>(fmt.topMargin()) != m_pixelsAbove) {
        fmt.setTopMargin(m_pixelsAbove);
        changed = true;
    }
    if (static_cast<int>(fmt.bottomMargin()) != m_pixelsBelow) {
        fmt.setBottomMargin(m_pixelsBelow);
        changed = true;
    }

    if (changed)
        bc.setBlockFormat(fmt);
}

void Editor::applyLineHeightToDocument()
{
    if (m_applyingLineHeight)
        return;
    m_applyingLineHeight = true;

    const bool wasModified = document()->isModified();

    QTextCursor cursor(document());
    cursor.beginEditBlock();
    for (QTextBlock block = document()->firstBlock(); block.isValid(); block = block.next())
        applyLineHeightToBlock(block);
    cursor.endEditBlock();

    // Formatting should not mark the file dirty
    document()->setModified(wasModified);

    m_applyingLineHeight = false;
    viewport()->update();
    m_lineNumberArea->update();
}

bool Editor::isModified() const
{
    return m_modified;
}

void Editor::resetModified()
{
    m_modified = false;
    document()->setModified(false);
    emit modificationChanged(false);
}

void Editor::onTextChanged()
{
    if (m_applyingLineHeight)
        return;

    bool nowModified = document()->isModified();
    if (nowModified != m_modified) {
        m_modified = nowModified;
        emit modificationChanged(m_modified);
    }
}

void Editor::onBlockCountChanged(int /*newBlockCount*/)
{
    // Intentionally do NOT re-apply line metrics here.
    // Applying FixedHeight / margins synchronously (or even deferred)
    // while Qt is still finishing an empty-block insertion is what
    // prevented consecutive blank lines from being created.
    // New blocks inherit the format of the block they were split from;
    // we guarantee that format in keyPressEvent and after bulk loads.
}

int Editor::lineNumberAreaWidth() const
{
    if (!m_showLineNumbers)
        return m_borderSize;

    int digits = 1;
    int max = qMax(1, document()->blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }
    int space = 6 + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits;
    return space + m_borderSize;
}

void Editor::updateLineNumberAreaWidth(int /*newBlockCount*/)
{
    setViewportMargins(lineNumberAreaWidth(), m_borderSize, m_borderSize, m_borderSize);
}

void Editor::updateLineNumberArea(const QRect &rect, int dy)
{
    Q_UNUSED(rect);
    Q_UNUSED(dy);
    m_lineNumberArea->update();
}

void Editor::resizeEvent(QResizeEvent *event)
{
    QTextEdit::resizeEvent(event);
    QRect cr = contentsRect();
    m_lineNumberArea->setGeometry(QRect(cr.left(), cr.top(),
                                        lineNumberAreaWidth(), cr.height()));
}

void Editor::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    if (!m_showLineNumbers)
        return;

    QPainter painter(m_lineNumberArea);
    painter.fillRect(event->rect(), m_borderColor);

    QTextBlock block = document()->begin();
    int blockNumber = 0;
    QAbstractTextDocumentLayout *layout = document()->documentLayout();
    const int contentsY = verticalScrollBar()->value();
    const int viewportHeight = viewport()->height();

    QColor numberColor = m_lineNumberColor;

    while (block.isValid()) {
        QRectF br = layout->blockBoundingRect(block);
        int top = qRound(br.top()) - contentsY + m_borderSize;
        int height = qRound(br.height());

        if (top > viewportHeight + m_borderSize)
            break;

        if (top + height >= 0) {
            QString number = QString::number(blockNumber + 1);
            painter.setPen(numberColor);
            painter.drawText(0, top,
                             m_lineNumberArea->width() - 4, height,
                             Qt::AlignRight | Qt::AlignVCenter, number);
        }

        block = block.next();
        ++blockNumber;
    }
}

void Editor::highlightCurrentLine()
{
    QList<QTextEdit::ExtraSelection> extraSelections;
    if (m_highlightCurrentLine && !isReadOnly()) {
        QTextEdit::ExtraSelection selection;
        QColor lineColor = m_currentLineColor.isValid()
                               ? m_currentLineColor
                               : m_backgroundColor.lighter(115);
        selection.format.setBackground(lineColor);
        selection.format.setProperty(QTextFormat::FullWidthSelection, true);
        selection.cursor = textCursor();
        selection.cursor.clearSelection();
        extraSelections.append(selection);
    }
    setExtraSelections(extraSelections);
}

void Editor::keyPressEvent(QKeyEvent *event)
{
    const bool isNewline = (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter)
                           && !(event->modifiers() & (Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier));

    if (isNewline && !isReadOnly()) {
        // Special path for Enter: guarantee a new block is created even when
        // the current line is completely empty, and that both the old and
        // the new empty blocks receive the correct FixedHeight / margins.
        // This avoids the Qt quirk where custom block formats applied during
        // the default insertion path suppress consecutive blank lines.
        QTextCursor cursor = textCursor();
        cursor.beginEditBlock();

        // Make sure the block we are leaving already has correct metrics
        // (so the new block inherits a good format).
        applyLineHeightToBlock(cursor.block());

        cursor.insertBlock();               // creates the new empty block
        applyLineHeightToBlock(cursor.block()); // force metrics on the new one

        // Also touch the previous block again (the one we just left)
        QTextBlock prev = cursor.block().previous();
        if (prev.isValid())
            applyLineHeightToBlock(prev);

        cursor.endEditBlock();
        setTextCursor(cursor);
        ensureCursorVisible();
        event->accept();
        return;
    }

    QTextEdit::keyPressEvent(event);

    // For ordinary keys, keep the current block's metrics correct
    // (e.g. after font changes or when a block loses its format).
    if (!m_applyingLineHeight)
        applyLineHeightToBlock(textCursor().block());
}

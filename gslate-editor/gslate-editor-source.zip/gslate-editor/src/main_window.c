#include "main_window.h"
#include "editor.h"
#include "file_manager.h"
#include "key_bindings.h"
#include <string.h>

typedef enum { PENDING_NONE, PENDING_NEW, PENDING_OPEN, PENDING_QUIT } PendingAction;

struct _GSlateMainWindow {
    GtkApplication *app;
    GtkWindow *window;
    GtkWidget *root;
    GtkWidget *status_row;
    GtkLabel *status_label;
    GSlateEditor *editor;
    GSlateConfig config;
    gchar *config_path;
    gchar *last_search;
    GFile *current_file;
    gboolean fullscreen;
    PendingAction pending;
    GSimpleAction *undo_action, *redo_action;
    GSimpleAction *wrap_action, *numbers_action, *highlight_action, *status_action;
};

static void update_title(GSlateMainWindow *self);
static void update_status(GSlateMainWindow *self);
static void request_pending(GSlateMainWindow *self, PendingAction pending);
static void show_open_dialog(GSlateMainWindow *self);
static void show_save_as_dialog(GSlateMainWindow *self, PendingAction after_save);
static gboolean save_current(GSlateMainWindow *self);

static void copy_config(GSlateConfig *dst, const GSlateConfig *src)
{
    gslate_config_init_defaults(dst);
    dst->wordwrap=src->wordwrap; dst->block_cursor=src->block_cursor; dst->show_line_numbers=src->show_line_numbers;
    dst->highlight_current_line=src->highlight_current_line; dst->show_statusbar=src->show_statusbar;
    dst->border_size=src->border_size; dst->font_size=src->font_size; dst->pixels_above=src->pixels_above;
    dst->pixels_below=src->pixels_below; dst->line_distance=src->line_distance; dst->line_height=src->line_height;
#define CPY(f) do { g_free(dst->f); dst->f=g_strdup(src->f); } while (0)
    CPY(border_color); CPY(background_color); CPY(gutter_background_color); CPY(current_line_color); CPY(line_number_color); CPY(text_color); CPY(font_family);
#undef CPY
    for (guint i=0;i<22;i++) { g_free(dst->shortcuts[i]); dst->shortcuts[i]=g_strdup(src->shortcuts[i]); }
    dst->config_path=g_strdup(src->config_path);
}

static void show_message(GSlateMainWindow *self, const gchar *message)
{
    GtkAlertDialog *dialog = gtk_alert_dialog_new("%s", message);
    gtk_alert_dialog_show(dialog, self->window);
    g_object_unref(dialog);
}

static gboolean save_to_file(GSlateMainWindow *self, GFile *file)
{
    gchar *text = gslate_editor_dup_text(self->editor);
    GError *error = NULL;
    gboolean ok = gslate_file_save_text(file, text, strlen(text), &error);
    g_free(text);
    if (!ok) {
        show_message(self, error ? error->message : "The document could not be saved.");
        g_clear_error(&error);
        return FALSE;
    }
    g_set_object(&self->current_file, file);
    gtk_text_buffer_set_modified(gslate_editor_get_buffer(self->editor), FALSE);
    update_title(self);
    return TRUE;
}

static gboolean save_current(GSlateMainWindow *self)
{
    if (!self->current_file) return FALSE;
    return save_to_file(self, self->current_file);
}

static void load_file(GSlateMainWindow *self, GFile *file)
{
    GError *error = NULL;
    gchar *text = gslate_file_load_text(file, &error);
    if (!text) {
        show_message(self, error ? error->message : "The file could not be opened.");
        g_clear_error(&error);
        return;
    }
    gslate_editor_set_text(self->editor, text);
    g_free(text);
    g_set_object(&self->current_file, file);
    update_title(self); update_status(self);
}

static void update_title(GSlateMainWindow *self)
{
    gchar *name = self->current_file ? g_file_get_basename(self->current_file) : g_strdup("Untitled");
    gboolean modified = gtk_text_buffer_get_modified(gslate_editor_get_buffer(self->editor));
    gchar *title = g_strdup_printf("gSlate Editor — %s%s", name, modified ? " [modified]" : "");
    gtk_window_set_title(self->window, title);
    g_free(title); g_free(name);
}

static void update_status(GSlateMainWindow *self)
{
    GtkTextBuffer *buffer = gslate_editor_get_buffer(self->editor);
    GtkTextIter iter;
    gtk_text_buffer_get_iter_at_mark(buffer, &iter, gtk_text_buffer_get_insert(buffer));
    gchar *status = g_strdup_printf("Ln %d, Col %d", gtk_text_iter_get_line(&iter)+1, gtk_text_iter_get_line_offset(&iter)+1);
    gtk_label_set_text(self->status_label, status);
    g_free(status);
    if (self->undo_action) g_simple_action_set_enabled(self->undo_action, gtk_text_buffer_get_can_undo(buffer));
    if (self->redo_action) g_simple_action_set_enabled(self->redo_action, gtk_text_buffer_get_can_redo(buffer));
    update_title(self);
}

static void on_buffer_changed(GtkTextBuffer *buffer, gpointer data)
{
    update_status(data); (void)buffer;
}
static void on_mark_set(GtkTextBuffer *buffer, const GtkTextIter *iter, GtkTextMark *mark, gpointer data)
{
    if (mark == gtk_text_buffer_get_insert(buffer)) update_status(data);
    (void)iter;
}

static void perform_pending(GSlateMainWindow *self)
{
    PendingAction pending = self->pending;
    self->pending = PENDING_NONE;
    if (pending == PENDING_NEW) {
        gslate_editor_set_text(self->editor, "");
        g_clear_object(&self->current_file);
        update_title(self); update_status(self);
    } else if (pending == PENDING_OPEN) {
        show_open_dialog(self);
    } else if (pending == PENDING_QUIT) {
        gtk_window_destroy(self->window);
    }
}

static void confirm_unsaved_done(GObject *source, GAsyncResult *result, gpointer data)
{
    GSlateMainWindow *self = data;
    GError *error = NULL;
    gint choice = gtk_alert_dialog_choose_finish(GTK_ALERT_DIALOG(source), result, &error);
    if (error) { g_warning("Unsaved-changes dialog failed: %s", error->message); g_clear_error(&error); self->pending = PENDING_NONE; return; }
    if (choice == 0) { /* Save */
        if (self->current_file) {
            if (save_current(self)) perform_pending(self);
            else show_save_as_dialog(self, self->pending);
        } else show_save_as_dialog(self, self->pending);
    } else if (choice == 1) { /* Discard only when the requested replacement/close actually proceeds. */
        perform_pending(self);
    } else {
        self->pending = PENDING_NONE;
    }
}

static void request_pending(GSlateMainWindow *self, PendingAction pending)
{
    if (!gtk_text_buffer_get_modified(gslate_editor_get_buffer(self->editor))) {
        self->pending = pending; perform_pending(self); return;
    }
    self->pending = pending;
    const gchar *buttons[] = {"Save", "Discard", "Cancel", NULL};
    GtkAlertDialog *dialog = gtk_alert_dialog_new("Save changes before continuing?");
    gtk_alert_dialog_set_buttons(dialog, buttons);
    gtk_alert_dialog_set_default_button(dialog, 0);
    gtk_alert_dialog_set_cancel_button(dialog, 2);
    gtk_alert_dialog_choose(dialog, self->window, NULL, confirm_unsaved_done, self);
    g_object_unref(dialog);
}

static gboolean on_close_request(GtkWindow *window, gpointer data)
{
    GSlateMainWindow *self = data;
    request_pending(self, PENDING_QUIT);
    (void)window;
    return TRUE;
}

static void open_done(GObject *source, GAsyncResult *result, gpointer data)
{
    GSlateMainWindow *self = data; GError *error = NULL;
    GFile *file = gtk_file_dialog_open_finish(GTK_FILE_DIALOG(source), result, &error);
    if (file) { load_file(self, file); g_object_unref(file); }
    else if (error && !g_error_matches(error, GTK_DIALOG_ERROR, GTK_DIALOG_ERROR_DISMISSED)) {
        show_message(self, error->message);
    }
    g_clear_error(&error);
}

static void show_open_dialog(GSlateMainWindow *self)
{
    GtkFileDialog *dialog = gtk_file_dialog_new();
    gtk_file_dialog_set_title(dialog, "Open Text File");
    gtk_file_dialog_open(dialog, self->window, NULL, open_done, self);
    g_object_unref(dialog);
}

static void save_done(GObject *source, GAsyncResult *result, gpointer data)
{
    GSlateMainWindow *self = data; GError *error = NULL;
    GFile *file = gtk_file_dialog_save_finish(GTK_FILE_DIALOG(source), result, &error);
    if (file) {
        if (save_to_file(self, file)) {
            if (self->pending != PENDING_NONE) perform_pending(self);
        } else {
            self->pending = PENDING_NONE;
        }
        g_object_unref(file);
    } else if (error && !g_error_matches(error, GTK_DIALOG_ERROR, GTK_DIALOG_ERROR_DISMISSED)) {
        show_message(self, error->message);
        self->pending = PENDING_NONE;
    } else if (self->pending != PENDING_NONE) {
        self->pending = PENDING_NONE;
    }
    g_clear_error(&error);
}

static void show_save_as_dialog(GSlateMainWindow *self, PendingAction after_save)
{
    self->pending = after_save;
    GtkFileDialog *dialog = gtk_file_dialog_new();
    gtk_file_dialog_set_title(dialog, "Save Text File");
    gtk_file_dialog_save(dialog, self->window, NULL, save_done, self);
    g_object_unref(dialog);
}

static void action_new(GSimpleAction *a, GVariant *p, gpointer d) { request_pending(d, PENDING_NEW); (void)a;(void)p; }
static void action_open(GSimpleAction *a, GVariant *p, gpointer d) { request_pending(d, PENDING_OPEN); (void)a;(void)p; }
static void action_save(GSimpleAction *a, GVariant *p, gpointer d) { GSlateMainWindow *s=d; if (s->current_file) save_current(s); else show_save_as_dialog(s, PENDING_NONE); (void)a;(void)p; }
static void action_save_as(GSimpleAction *a, GVariant *p, gpointer d) { show_save_as_dialog(d, PENDING_NONE); (void)a;(void)p; }
static void action_quit(GSimpleAction *a, GVariant *p, gpointer d) { request_pending(d, PENDING_QUIT); (void)a;(void)p; }
static void action_undo(GSimpleAction *a, GVariant *p, gpointer d) { GtkTextBuffer *b=gslate_editor_get_buffer(((GSlateMainWindow*)d)->editor); if(gtk_text_buffer_get_can_undo(b)) gtk_text_buffer_undo(b); (void)a;(void)p; }
static void action_redo(GSimpleAction *a, GVariant *p, gpointer d) { GtkTextBuffer *b=gslate_editor_get_buffer(((GSlateMainWindow*)d)->editor); if(gtk_text_buffer_get_can_redo(b)) gtk_text_buffer_redo(b); (void)a;(void)p; }
static void action_cut(GSimpleAction *a, GVariant *p, gpointer d) { gslate_editor_cut(((GSlateMainWindow*)d)->editor); (void)a;(void)p; }
static void action_copy(GSimpleAction *a, GVariant *p, gpointer d) { gslate_editor_copy(((GSlateMainWindow*)d)->editor); (void)a;(void)p; }
static void action_paste(GSimpleAction *a, GVariant *p, gpointer d) { gslate_editor_paste(((GSlateMainWindow*)d)->editor); (void)a;(void)p; }

static void find_text(GSlateMainWindow *self, const gchar *term, gboolean show_error)
{
    GtkTextBuffer *buffer = gslate_editor_get_buffer(self->editor);
    GtkTextIter start, match_start, match_end, begin, end;
    gboolean found = FALSE;
    if (!term || !*term) return;
    if (gtk_text_buffer_get_selection_bounds(buffer, &begin, &end)) start = end;
    else gtk_text_buffer_get_iter_at_mark(buffer, &start, gtk_text_buffer_get_insert(buffer));
    found = gtk_text_iter_forward_search(&start, term, GTK_TEXT_SEARCH_CASE_INSENSITIVE, &match_start, &match_end, NULL);
    if (!found) {
        gtk_text_buffer_get_start_iter(buffer, &start);
        found = gtk_text_iter_forward_search(&start, term, GTK_TEXT_SEARCH_CASE_INSENSITIVE, &match_start, &match_end, NULL);
    }
    if (found) {
        gtk_text_buffer_select_range(buffer, &match_start, &match_end);
        gtk_text_view_scroll_to_iter(gslate_editor_get_view(self->editor), &match_start, 0.15, FALSE, 0, 0);
    } else if (show_error) show_message(self, "The search text was not found.");
}

static void find_response(GtkDialog *dialog, gint response, gpointer data)
{
    GSlateMainWindow *self = data;
    if (response == GTK_RESPONSE_ACCEPT) {
        GtkWidget *entry = g_object_get_data(G_OBJECT(dialog), "gslate-entry");
        const gchar *text = gtk_editable_get_text(GTK_EDITABLE(entry));
        g_free(self->last_search); self->last_search = g_strdup(text);
        find_text(self, text, TRUE);
    }
    gtk_window_destroy(GTK_WINDOW(dialog));
}
static void action_find(GSimpleAction *a,GVariant*p,gpointer d)
{
    GSlateMainWindow *s=d; GtkWidget *dialog=gtk_dialog_new_with_buttons("Find",s->window,GTK_DIALOG_MODAL,"Cancel",GTK_RESPONSE_CANCEL,"Find",GTK_RESPONSE_ACCEPT,NULL);
    GtkWidget *entry=gtk_entry_new(); gtk_entry_set_placeholder_text(GTK_ENTRY(entry),"Search text");
    if(s->last_search) gtk_editable_set_text(GTK_EDITABLE(entry),s->last_search);
    gtk_box_append(GTK_BOX(gtk_dialog_get_content_area(GTK_DIALOG(dialog))),entry);
    g_object_set_data(G_OBJECT(dialog),"gslate-entry",entry);
    g_signal_connect(dialog,"response",G_CALLBACK(find_response),s); gtk_window_present(GTK_WINDOW(dialog)); (void)a;(void)p;
}
static void action_find_next(GSimpleAction*a,GVariant*p,gpointer d){GSlateMainWindow*s=d;if(s->last_search)find_text(s,s->last_search,TRUE);else show_message(s,"Use Find first.");(void)a;(void)p;}

static void goto_response(GtkDialog *dialog, gint response, gpointer data)
{
    if (response == GTK_RESPONSE_ACCEPT) {
        GSlateMainWindow *self=data; GtkWidget *spin=g_object_get_data(G_OBJECT(dialog),"gslate-spin");
        gslate_editor_goto_line(self->editor,(guint)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin)));
    }
    gtk_window_destroy(GTK_WINDOW(dialog));
}
static void action_goto_line(GSimpleAction*a,GVariant*p,gpointer d)
{
    GSlateMainWindow*s=d; GtkWidget*dialog=gtk_dialog_new_with_buttons("Go to Line",s->window,GTK_DIALOG_MODAL,"Cancel",GTK_RESPONSE_CANCEL,"Go",GTK_RESPONSE_ACCEPT,NULL);
    GtkWidget*spin=gtk_spin_button_new_with_range(1,gslate_editor_get_line_count(s->editor),1);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin),1); gtk_box_append(GTK_BOX(gtk_dialog_get_content_area(GTK_DIALOG(dialog))),spin);
    g_object_set_data(G_OBJECT(dialog),"gslate-spin",spin); g_signal_connect(dialog,"response",G_CALLBACK(goto_response),s); gtk_window_present(GTK_WINDOW(dialog));(void)a;(void)p;
}

static void refresh_toggle_states(GSlateMainWindow *s)
{
    g_simple_action_set_state(s->wrap_action,g_variant_new_boolean(s->config.wordwrap));
    g_simple_action_set_state(s->numbers_action,g_variant_new_boolean(s->config.show_line_numbers));
    g_simple_action_set_state(s->highlight_action,g_variant_new_boolean(s->config.highlight_current_line));
    g_simple_action_set_state(s->status_action,g_variant_new_boolean(s->config.show_statusbar));
}
static void on_toggle(GSimpleAction *action, GVariant *value, gpointer data)
{
    GSlateMainWindow *s=data; gboolean enabled=g_variant_get_boolean(value);
    const gchar *name=g_action_get_name(G_ACTION(action));
    if(g_str_equal(name,"word-wrap")) s->config.wordwrap=enabled;
    else if(g_str_equal(name,"line-numbers")) s->config.show_line_numbers=enabled;
    else if(g_str_equal(name,"current-line")) s->config.highlight_current_line=enabled;
    else if(g_str_equal(name,"statusbar")) s->config.show_statusbar=enabled;
    gslate_editor_apply_config(s->editor,&s->config);
    gtk_widget_set_visible(s->status_row,s->config.show_statusbar);
    g_simple_action_set_state(action,value);
}
static void action_fullscreen(GSimpleAction*a,GVariant*p,gpointer d){GSlateMainWindow*s=d;s->fullscreen=!s->fullscreen;if(s->fullscreen)gtk_window_fullscreen(s->window);else gtk_window_unfullscreen(s->window);(void)a;(void)p;}
static void action_inc_font(GSimpleAction*a,GVariant*p,gpointer d){GSlateMainWindow*s=d;if(s->config.font_size<72)s->config.font_size++;gslate_editor_apply_config(s->editor,&s->config);(void)a;(void)p;}
static void action_dec_font(GSimpleAction*a,GVariant*p,gpointer d){GSlateMainWindow*s=d;if(s->config.font_size>6)s->config.font_size--;gslate_editor_apply_config(s->editor,&s->config);(void)a;(void)p;}
static void action_reload(GSimpleAction*a,GVariant*p,gpointer d)
{
    GSlateMainWindow*s=d; GSlateConfig next; gslate_config_init_defaults(&next);
    gchar *path=s->config_path?g_strdup(s->config_path):gslate_config_discover_path(NULL);
    GError*error=NULL;
    if(path && !gslate_config_load(&next,path,&error)){show_message(s,error->message);g_clear_error(&error);g_free(path);gslate_config_clear(&next);return;}
    g_free(path); gslate_config_clear(&s->config); s->config=next;
    gslate_editor_apply_config(s->editor,&s->config); gslate_key_bindings_apply(s->app,&s->config);
    gtk_widget_set_visible(s->status_row,s->config.show_statusbar);refresh_toggle_states(s);(void)a;(void)p;
}

static void add_action(GSlateMainWindow *s, const gchar *name, GCallback callback)
{
    GSimpleAction *a=g_simple_action_new(name,NULL); g_signal_connect(a,"activate",callback,s);
    g_action_map_add_action(G_ACTION_MAP(s->app),G_ACTION(a));g_object_unref(a);
}
static void on_toggle_activate(GSimpleAction *action, GVariant *parameter, gpointer data)
{
    GVariant *state = g_action_get_state(G_ACTION(action));
    gboolean current = state ? g_variant_get_boolean(state) : FALSE;
    if (state) g_variant_unref(state);
    g_action_change_state(G_ACTION(action), g_variant_new_boolean(!current));
    (void)parameter; (void)data;
}

static GSimpleAction *add_toggle_action(GSlateMainWindow*s,const gchar*name,gboolean state)
{
    GSimpleAction*a=g_simple_action_new_stateful(name,NULL,g_variant_new_boolean(state));
    g_signal_connect(a,"activate",G_CALLBACK(on_toggle_activate),s);
    g_signal_connect(a,"change-state",G_CALLBACK(on_toggle),s);g_action_map_add_action(G_ACTION_MAP(s->app),G_ACTION(a));return a;
}

static GMenuModel *build_menu(GSlateMainWindow *s)
{
    GMenu *bar=g_menu_new(),*file=g_menu_new(),*edit=g_menu_new(),*view=g_menu_new();
#define ITEM(menu,label,action) g_menu_append(menu,label,"app." action)
    ITEM(file,"New","new"); ITEM(file,"Open…","open"); ITEM(file,"Save","save"); ITEM(file,"Save As…","save-as"); g_menu_append(file,"Quit","app.quit");
    ITEM(edit,"Undo","undo"); ITEM(edit,"Redo","redo"); g_menu_append(edit,"Cut","app.cut"); g_menu_append(edit,"Copy","app.copy"); g_menu_append(edit,"Paste","app.paste");
    ITEM(edit,"Find…","find"); ITEM(edit,"Find Next","find-next"); ITEM(edit,"Go to Line…","goto-line"); ITEM(edit,"Reload Config","reload-config");
    ITEM(edit,"Increase Font","increase-font"); ITEM(edit,"Decrease Font","decrease-font");
    g_menu_append(view,"Word Wrap","app.word-wrap"); g_menu_append(view,"Show Line Numbers","app.line-numbers");
    g_menu_append(view,"Highlight Current Line","app.current-line"); g_menu_append(view,"Show Status Bar","app.statusbar"); g_menu_append(view,"Full Screen","app.fullscreen");
    g_menu_append_submenu(bar,"File",G_MENU_MODEL(file));g_menu_append_submenu(bar,"Edit",G_MENU_MODEL(edit));g_menu_append_submenu(bar,"View",G_MENU_MODEL(view));
    g_object_unref(file);g_object_unref(edit);g_object_unref(view);(void)s;return G_MENU_MODEL(bar);
#undef ITEM
}

GSlateMainWindow *
gslate_main_window_new(GtkApplication *app, const GSlateConfig *config, const gchar *config_path, const gchar *initial_file)
{
    GSlateMainWindow *s=g_new0(GSlateMainWindow,1);s->app=app;copy_config(&s->config,config);s->config_path=g_strdup(config_path);
    s->window=GTK_WINDOW(gtk_application_window_new(app));gtk_window_set_default_size(s->window,900,600);gtk_widget_set_size_request(GTK_WIDGET(s->window),400,300);
    s->root=gtk_box_new(GTK_ORIENTATION_VERTICAL,0);gtk_window_set_child(s->window,s->root);
    s->editor=gslate_editor_new(&s->config);
    GMenuModel *menu_model=build_menu(s);GtkWidget *menubar=gtk_popover_menu_bar_new_from_model(menu_model);g_object_unref(menu_model);gtk_box_append(GTK_BOX(s->root),menubar);
    gtk_box_append(GTK_BOX(s->root),gslate_editor_get_widget(s->editor));
    s->status_row=gtk_box_new(GTK_ORIENTATION_HORIZONTAL,0);gtk_widget_set_margin_start(s->status_row,8);gtk_widget_set_margin_end(s->status_row,8);
    gtk_widget_set_margin_top(s->status_row,3);gtk_widget_set_margin_bottom(s->status_row,3);
    s->status_label=GTK_LABEL(gtk_label_new("Ln 1, Col 1"));gtk_box_append(GTK_BOX(s->status_row),GTK_WIDGET(s->status_label));gtk_box_append(GTK_BOX(s->root),s->status_row);
    gtk_widget_set_visible(s->status_row,s->config.show_statusbar);

    add_action(s,"new",G_CALLBACK(action_new));add_action(s,"open",G_CALLBACK(action_open));add_action(s,"save",G_CALLBACK(action_save));add_action(s,"save-as",G_CALLBACK(action_save_as));add_action(s,"quit",G_CALLBACK(action_quit));
    add_action(s,"undo",G_CALLBACK(action_undo));add_action(s,"redo",G_CALLBACK(action_redo));add_action(s,"cut",G_CALLBACK(action_cut));add_action(s,"copy",G_CALLBACK(action_copy));add_action(s,"paste",G_CALLBACK(action_paste));
    add_action(s,"find",G_CALLBACK(action_find));add_action(s,"find-next",G_CALLBACK(action_find_next));add_action(s,"goto-line",G_CALLBACK(action_goto_line));add_action(s,"reload-config",G_CALLBACK(action_reload));
    s->undo_action=G_SIMPLE_ACTION(g_action_map_lookup_action(G_ACTION_MAP(app),"undo"));s->redo_action=G_SIMPLE_ACTION(g_action_map_lookup_action(G_ACTION_MAP(app),"redo"));
    s->wrap_action=add_toggle_action(s,"word-wrap",s->config.wordwrap);s->numbers_action=add_toggle_action(s,"line-numbers",s->config.show_line_numbers);
    s->highlight_action=add_toggle_action(s,"current-line",s->config.highlight_current_line);s->status_action=add_toggle_action(s,"statusbar",s->config.show_statusbar);
    add_action(s,"fullscreen",G_CALLBACK(action_fullscreen));add_action(s,"increase-font",G_CALLBACK(action_inc_font));add_action(s,"decrease-font",G_CALLBACK(action_dec_font));
    gslate_key_bindings_apply(app,&s->config);
    g_signal_connect(gslate_editor_get_buffer(s->editor),"changed",G_CALLBACK(on_buffer_changed),s);
    g_signal_connect(gslate_editor_get_buffer(s->editor),"mark-set",G_CALLBACK(on_mark_set),s);
    g_signal_connect(s->window,"close-request",G_CALLBACK(on_close_request),s);
    update_status(s);update_title(s);
    if(initial_file){GFile*f=g_file_new_for_commandline_arg(initial_file);load_file(s,f);g_object_unref(f);}
    return s;
}

void gslate_main_window_present(GSlateMainWindow *s) { gtk_window_present(s->window); }

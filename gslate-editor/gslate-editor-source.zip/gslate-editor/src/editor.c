#include "editor.h"
#include "editor_gutter.h"
#include "clipboard.h"
#include <pango/pangocairo.h>
#include <string.h>

struct _GSlateEditor {
    GtkWidget *frame;
    GtkWidget *scroller;
    GtkTextView *view;
    GtkTextBuffer *buffer;
    GtkWidget *gutter;
    GtkTextTag *line_height_tag;
    GtkTextTag *current_line_tag;
    GtkCssProvider *css;
    GdkDisplay *display;
    GSlateConfig config;
};

static void update_inserted_format(GtkTextBuffer *buffer, const GtkTextIter *location,
                                   gchar *text, gint len, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gint chars = (len < 0) ? (gint)g_utf8_strlen(text, -1) : (gint)g_utf8_strlen(text, len);
    GtkTextIter end = *location, start = *location;
    if (chars > 0 && gtk_text_iter_backward_chars(&start, chars))
        gtk_text_buffer_apply_tag(buffer, e->line_height_tag, &start, &end);
}

static void on_mark_set(GtkTextBuffer *buffer, const GtkTextIter *location,
                        GtkTextMark *mark, gpointer user_data)
{
    GSlateEditor *e = user_data;
    if (mark == gtk_text_buffer_get_insert(buffer))
        gslate_editor_refresh_highlight(e);
    gslate_gutter_queue_draw(e);
    (void)location;
}

static void on_buffer_changed(GtkTextBuffer *buffer, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gslate_editor_refresh_gutter(e);
    gslate_editor_refresh_highlight(e);
    (void)buffer;
}

static void on_copy_signal(GtkTextView *view, gpointer user_data)
{
    gslate_editor_copy(user_data);
    g_signal_stop_emission_by_name(view, "copy-clipboard");
}

static void on_cut_signal(GtkTextView *view, gpointer user_data)
{
    gslate_editor_cut(user_data);
    g_signal_stop_emission_by_name(view, "cut-clipboard");
}

static void on_paste_signal(GtkTextView *view, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gslate_editor_paste(e);
    g_signal_stop_emission_by_name(view, "paste-clipboard");
}

static void apply_css(GSlateEditor *e)
{
    gchar *css = g_strdup_printf(
        ".slate-editor-frame { border-style: solid; border-radius: 0; border-width: %dpx; border-color: %s; padding: 0; }\n"
        ".gslate-text-view, .gslate-text-view text { background-color: %s; color: %s; font-family: \"%s\"; font-size: %dpt; }\n"
        ".gslate-gutter { background-color: %s; color: %s; }\n",
        e->config.border_size, e->config.border_color, e->config.background_color,
        e->config.text_color, e->config.font_family, e->config.font_size,
        e->config.gutter_background_color, e->config.line_number_color);
    gtk_css_provider_load_from_string(e->css, css);
    g_free(css);
}

GSlateEditor *
gslate_editor_new(const GSlateConfig *config)
{
    GSlateEditor *e = g_new0(GSlateEditor, 1);
    gslate_config_init_defaults(&e->config);
    gslate_editor_apply_config(e, config);

    e->buffer = gtk_text_buffer_new(NULL);
    gtk_text_buffer_set_enable_undo(e->buffer, TRUE);
    e->view = GTK_TEXT_VIEW(gtk_text_view_new_with_buffer(e->buffer));
    gtk_text_view_set_monospace(e->view, TRUE);
    gtk_text_view_set_wrap_mode(e->view, e->config.wordwrap ? GTK_WRAP_WORD_CHAR : GTK_WRAP_NONE);
    gtk_widget_add_css_class(GTK_WIDGET(e->view), "gslate-text-view");
    gtk_text_view_set_left_margin(e->view, 8);
    gtk_text_view_set_right_margin(e->view, 8);

    e->line_height_tag = gtk_text_buffer_create_tag(e->buffer, "gslate-line-height", NULL);
    e->current_line_tag = gtk_text_buffer_create_tag(e->buffer, "gslate-current-line", NULL);
    e->frame = gtk_frame_new(NULL);
    gtk_widget_add_css_class(e->frame, "slate-editor-frame");
    e->scroller = gtk_scrolled_window_new();
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(e->scroller), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(e->scroller), GTK_WIDGET(e->view));
    gtk_frame_set_child(GTK_FRAME(e->frame), e->scroller);
    gtk_widget_set_hexpand(e->frame, TRUE); gtk_widget_set_vexpand(e->frame, TRUE);

    e->gutter = gslate_gutter_new(e);
    gtk_widget_add_css_class(e->gutter, "gslate-gutter");
    gtk_text_view_set_gutter(e->view, GTK_TEXT_WINDOW_LEFT, e->gutter);
    gtk_widget_set_visible(e->gutter, e->config.show_line_numbers);

    e->display = g_object_ref(gtk_widget_get_display(GTK_WIDGET(e->view)));
    e->css = gtk_css_provider_new();
    gtk_style_context_add_provider_for_display(e->display,
        GTK_STYLE_PROVIDER(e->css), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    apply_css(e);
    g_signal_connect_after(e->buffer, "insert-text", G_CALLBACK(update_inserted_format), e);
    g_signal_connect(e->buffer, "mark-set", G_CALLBACK(on_mark_set), e);
    g_signal_connect(e->buffer, "changed", G_CALLBACK(on_buffer_changed), e);
    g_signal_connect(e->view, "copy-clipboard", G_CALLBACK(on_copy_signal), e);
    g_signal_connect(e->view, "cut-clipboard", G_CALLBACK(on_cut_signal), e);
    g_signal_connect(e->view, "paste-clipboard", G_CALLBACK(on_paste_signal), e);
    gslate_editor_apply_config(e, config);
    return e;
}

void
gslate_editor_free(GSlateEditor *e)
{
    if (!e) return;
    if (e->css && e->view) {
        gtk_style_context_remove_provider_for_display(e->display, GTK_STYLE_PROVIDER(e->css));
        g_object_unref(e->css);
    }
    g_clear_object(&e->display);
    gslate_config_clear(&e->config);
    g_free(e);
}

GtkWidget *gslate_editor_get_widget(GSlateEditor *e) { return e->frame; }
GtkTextView *gslate_editor_get_view(GSlateEditor *e) { return e->view; }
GtkTextBuffer *gslate_editor_get_buffer(GSlateEditor *e) { return e->buffer; }
const GSlateConfig *gslate_editor_get_config(GSlateEditor *e) { return &e->config; }
GtkWidget *gslate_editor_get_gutter(GSlateEditor *e) { return e->gutter; }

guint
gslate_editor_get_line_count(GSlateEditor *e)
{
    return (guint)gtk_text_buffer_get_line_count(e->buffer);
}

void
gslate_editor_refresh_gutter(GSlateEditor *e)
{
    if (e && e->gutter) gslate_gutter_queue_draw(e);
}

void
gslate_editor_refresh_highlight(GSlateEditor *e)
{
    GtkTextIter start, end, line_start, line_end;
    if (!e) return;
    gtk_text_buffer_get_bounds(e->buffer, &start, &end);
    gtk_text_buffer_remove_tag(e->buffer, e->current_line_tag, &start, &end);
    if (!e->config.highlight_current_line) return;
    gtk_text_buffer_get_iter_at_mark(e->buffer, &line_start, gtk_text_buffer_get_insert(e->buffer));
    line_start = line_start; gtk_text_iter_set_line_offset(&line_start, 0);
    line_end = line_start;
    gtk_text_iter_forward_to_line_end(&line_end);
    /* Include the line terminator so the paragraph background reaches its end. */
    if (!gtk_text_iter_is_end(&line_end)) gtk_text_iter_forward_char(&line_end);
    if (!gtk_text_iter_equal(&line_start, &line_end))
        gtk_text_buffer_apply_tag(e->buffer, e->current_line_tag, &line_start, &line_end);
}

void
gslate_editor_apply_config(GSlateEditor *e, const GSlateConfig *c)
{
    if (!e || !c) return;
    /* Copy fields; configuration owns its own strings. */
    e->config.wordwrap = c->wordwrap; e->config.block_cursor = c->block_cursor;
    e->config.show_line_numbers = c->show_line_numbers; e->config.highlight_current_line = c->highlight_current_line;
    e->config.show_statusbar = c->show_statusbar; e->config.border_size = c->border_size;
    e->config.font_size = c->font_size; e->config.pixels_above = c->pixels_above;
    e->config.pixels_below = c->pixels_below; e->config.line_distance = c->line_distance; e->config.line_height = c->line_height;
#define COPY_FIELD(f) do { g_free(e->config.f); e->config.f = g_strdup(c->f); } while (0)
    COPY_FIELD(border_color); COPY_FIELD(background_color); COPY_FIELD(gutter_background_color); COPY_FIELD(current_line_color);
    COPY_FIELD(line_number_color); COPY_FIELD(text_color); COPY_FIELD(font_family);
#undef COPY_FIELD
    if (e->view) {
        gtk_text_view_set_monospace(e->view, TRUE);
        gtk_text_view_set_wrap_mode(e->view, e->config.wordwrap ? GTK_WRAP_WORD_CHAR : GTK_WRAP_NONE);
        gtk_text_view_set_pixels_above_lines(e->view, e->config.pixels_above);
        gtk_text_view_set_pixels_below_lines(e->view, e->config.pixels_below);
        gtk_text_view_set_pixels_inside_wrap(e->view, e->config.line_distance);
        GdkRGBA highlight;
        if (gdk_rgba_parse(&highlight, e->config.current_line_color))
            g_object_set(e->current_line_tag, "paragraph-background-rgba", &highlight, NULL);
        g_object_set(e->line_height_tag, "line-height", (gfloat)e->config.line_height, NULL);
        GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
        if (!gtk_text_iter_equal(&a, &b)) gtk_text_buffer_apply_tag(e->buffer, e->line_height_tag, &a, &b);
        gtk_widget_set_visible(e->gutter, e->config.show_line_numbers);
        apply_css(e);
        gslate_editor_refresh_gutter(e);
        gslate_editor_refresh_highlight(e);
    }
}

void
gslate_editor_set_text(GSlateEditor *e, const gchar *text)
{
    /* A newly loaded/replaced document is a fresh undo baseline. Toggling
     * native undo off clears any history belonging to the previous document. */
    gtk_text_buffer_set_enable_undo(e->buffer, FALSE);
    gtk_text_buffer_set_text(e->buffer, text ? text : "", -1);
    GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
    if (!gtk_text_iter_equal(&a, &b)) gtk_text_buffer_apply_tag(e->buffer, e->line_height_tag, &a, &b);
    gslate_editor_refresh_highlight(e);
    gslate_editor_refresh_gutter(e);
    gtk_text_buffer_set_modified(e->buffer, FALSE);
    gtk_text_buffer_set_enable_undo(e->buffer, TRUE);
}

gchar *
gslate_editor_dup_text(GSlateEditor *e)
{
    GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
    return gtk_text_buffer_get_text(e->buffer, &a, &b, TRUE);
}

void gslate_editor_copy(GSlateEditor *e) { gslate_clipboard_copy(e->view, e->buffer); }
void gslate_editor_cut(GSlateEditor *e) { gslate_clipboard_cut(e->view, e->buffer); }
void gslate_editor_paste(GSlateEditor *e) { gslate_clipboard_paste(e->view, e->buffer); }

void
gslate_editor_goto_line(GSlateEditor *e, guint n)
{
    GtkTextIter iter;
    guint count = gslate_editor_get_line_count(e);
    if (n < 1 || n > count) return;
    gtk_text_buffer_get_iter_at_line(e->buffer, &iter, (gint)n - 1);
    gtk_text_buffer_place_cursor(e->buffer, &iter);
    gtk_text_view_scroll_to_iter(e->view, &iter, 0.15, FALSE, 0, 0);
}

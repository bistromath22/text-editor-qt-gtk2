# gSlate Editor — Technical Design

## Document model

One `GtkTextBuffer` is authoritative for the one active document. `GtkTextView` supplies GTK's normal cursor, selection, editing, accessibility and scrolling behaviour. Native buffer undo is enabled and no parallel undo stack is maintained.

## UTF-8 and newline handling

GIO loads the complete file. A leading UTF-8 BOM is stripped, UTF-8 is validated, then a single-pass normalizer maps CRLF and lone CR to LF. This order prevents CRLF from becoming two line breaks. Save extracts plain buffer text and uses `g_file_replace_contents()` so the destination is safely replaced. Invalid UTF-8 is rejected on either boundary.

## Clipboard

Copy writes selected text through `GdkClipboard` as text only. Cut writes the same representation and deletes the selection inside one buffer user action. Paste reads clipboard text asynchronously, creates temporary marks to preserve the cursor/selection region, normalizes newlines, replaces the selected range, and groups insertion into one user action. Temporary marks and references are released in the completion callback.

## Undo and modified state

`gtk_text_buffer_set_enable_undo()` enables GTK's native undo history. Cut/paste use begin/end user-action boundaries. Loading uses `gtk_text_buffer_set_text()` and resets the modified flag after the new text is installed. Saving clears the modified flag only after GIO reports success. Styling is implemented through tags and CSS rather than inserting markup into the buffer.

## Typography and paragraphs

A reusable text tag applies GTK's `line-height` property to document text, including text inserted later. TextView paragraph properties provide spacing above/below paragraphs and between wrapped visual rows. The line height is proportional rather than a fixed pixel height. GTK/Pango font fallback remains responsible for Unicode glyph coverage.

## Line-number gutter

A `GtkDrawingArea` is attached to `GtkTextView`'s native left gutter. The draw callback locates the first visible logical line and uses the text iterator's actual layout rectangle to place its number at the first visual row. It does not multiply a line number by a guessed height, and wrapped visual rows do not receive additional numbers. Gutter width is adjusted as the document's line count crosses digit boundaries.

## Current-line highlighting

A reusable `GtkTextTag` with paragraph background styling is applied to the logical paragraph at the insertion mark. The tag is removed/reapplied on cursor and document updates. Tag operations affect presentation only and are not serialized.

## Border and widget layout

The main vertical box contains a `GtkPopoverMenuBar`, an expanding editor frame, and an optional status row. The frame owns the configured border through a dedicated GTK CSS class/provider; the text view and gutter own their own colours. The configured editor border does not affect the desktop environment's title bar or window-manager frame.

## Actions and configuration

Commands are application-level `GSimpleAction`s referenced by GMenu models. Accelerators are installed with `gtk_application_set_accels_for_action()`. Configuration is parsed from INI-style `GKeyFile` data using one defaults structure; absent keys retain defaults, invalid values are bounded or replaced safely. Reload constructs a fresh defaults-based configuration and reapplies it to live widgets/actions without replacing the document buffer.

## GTK-specific adaptation

The optional block cursor is a non-interactive `GtkDrawingArea` added with `gtk_text_view_add_overlay()`. Its position is derived from `gtk_text_view_get_cursor_locations()` in buffer coordinates, and its width uses the next glyph's layout advance (with a Pango monospace-cell fallback at paragraph ends). Because the child is attached to the text view's text window, it scrolls with the document without a second adjustment or coordinate conversion. The native insertion mark and GTK editing/input-method pipeline remain authoritative. **`GtkTextView:cursor-visible` is deliberately kept `TRUE` even while the block overlay is enabled.** GTK's `GtkTextView::move-cursor` key binding moves the viewport, rather than the insertion mark, when the cursor is not visible; hiding the native cursor therefore breaks arrow-key, Home/End, and PageUp/PageDown navigation. The custom overlay supplies the block-cursor appearance without taking ownership of keyboard navigation. The overlay is shown while the editor has focus. It is steady (non-blinking) by default. The `[editor]` option `block_cursor_blink=true` enables blinking; when enabled, GTK's `gtk-cursor-blink-time` setting supplies the cycle duration. The application does not inherit GTK's `gtk-cursor-blink` on/off preference, because the application configuration explicitly controls whether the block caret blinks. GTK's native window decorations are likewise intentionally outside the application's border configuration.

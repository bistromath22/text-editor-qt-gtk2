# gSlate Editor

A lightweight, native Linux plain-text editor written in C17 with GTK4. The application keeps one active UTF-8 document and uses `GtkTextView` / `GtkTextBuffer` for native editing, selection, accessibility, scrolling, and undo/redo.

## Current implementation

- C17, GTK 4.16+, GLib/GIO, Pango, Cairo, Meson and Ninja.
- Single-document window with File, Edit and View menus.
- UTF-8 file loading, optional BOM removal, CRLF/CR-to-LF normalization, and safe GIO replacement on save.
- Native `GtkTextBuffer` undo/redo; multiline clipboard paste uses one buffer user action.
- Configurable dark palette, font family/size, proportional line height, paragraph spacing, word wrap, line numbers, current-line presentation and editor border.
- Native TextView gutter used for logical line numbers.
- Optional scrolling block cursor, toggled from View or with Ctrl+B; non-blinking by default, with optional blinking configured in `config.ini`.
- Search, Find Next, Go to Line, full screen, status row and unsaved-change prompts.
- Human-readable `GKeyFile` configuration and live reload.
- Command-line config inspection, version output, and opening one text file.

This is a focused text editor, not an IDE. It intentionally has no tabs, split views, syntax highlighting, terminal, project browser, plugins or rich-text document format.

## Dependencies on Ubuntu 26.04 LTS

```bash
sudo apt update
sudo apt install \
    build-essential \
    gcc \
    meson \
    ninja-build \
    pkg-config \
    libgtk-4-dev
```

GTK 4.16 or newer is required for `GtkTextBuffer`'s native undo/redo API. No Qt or C++ toolchain is required.

## Build

```bash
meson setup build --buildtype=release
meson compile -C build
```

Debug build:

```bash
meson setup build-debug --buildtype=debug
meson compile -C build-debug
```

Run automated tests:

```bash
meson test -C build --print-errorlogs
```

Install:

```bash
sudo meson install -C build
```

For packaging/staging, Meson honours `--prefix` and `DESTDIR`:

```bash
meson configure build --prefix=/usr
DESTDIR="$PWD/stage" meson install -C build
```

## Run

```bash
gslate
gslate notes.txt
gslate --config /path/to/config.ini notes.txt
```

Only one document is active. When more than one path is supplied, the first existing non-directory path is opened and a warning explains that additional files are unsupported.

## Command-line options

```text
gslate --help
gslate --version
gslate --print-config
gslate --print-config-paths
gslate --config PATH [FILE...]
```

`--print-config` prints the effective values after loading the selected configuration, or built-in defaults when no usable file is present. `--print-config-paths` lists the discovery order.

## Configuration

The file name is `config.ini`. Discovery order:

1. `./config.ini`
2. `$XDG_CONFIG_HOME/gslate-editor/config.ini` (normally `~/.config/gslate-editor/config.ini`)
3. `/etc/gslate-editor/config.ini`
4. Built-in defaults

`--config PATH` overrides discovery. A missing/unreadable/invalid explicit configuration is reported and the application falls back to built-in defaults. Partial files override only keys they contain. Copy `config.example.ini` to one of the locations above and edit it.

The editor's configured border surrounds the text editor widget. It does **not** recolour the Ubuntu title bar, native window frame or other window-manager decorations. Those remain controlled by the desktop environment.

## Default shortcuts

| Action | Shortcut |
|---|---|
| New / Open / Save / Save As / Quit | Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S / Ctrl+Q |
| Undo / Redo | Ctrl+Z / Ctrl+Y |
| Cut / Copy / Paste | Ctrl+X / Ctrl+C / Ctrl+V |
| Find / Find Next / Go to Line | Ctrl+F / F3 / Ctrl+G |
| Reload Config | Ctrl+R |
| Toggle Word Wrap | Ctrl+W |
| Toggle Block Cursor | Ctrl+B |
| Increase / Decrease Font | Ctrl++ / Ctrl+- |
| Full Screen | F11 |
| Show Line Numbers | Ctrl+L |
| Highlight Current Line | Ctrl+H |
| Show Status Bar | Ctrl+Shift+B |

Shortcuts use GTK accelerator syntax, for example `<Primary><Shift>s`.

## Text and file policy

The document is UTF-8 plain text. On load, an optional UTF-8 BOM is removed and CRLF / CR line endings are normalized to LF. Invalid UTF-8 is rejected instead of being silently altered. Saves contain UTF-8 with LF endings and no presentation markup. Text tags, colours and paragraph layout are never serialized. Empty lines and leading/trailing LF characters are retained by the text buffer representation.

## Architecture

- `main.c`: command-line parsing and GTK application startup.
- `main_window.c`: application window, GActions/GMenu, dialogs, file workflow and status.
- `editor.c`: GtkTextView/GtkTextBuffer, formatting, current-line tag, scrolling block-cursor overlay, document text and editor frame.
- `editor_gutter.c`: GtkTextView native gutter and logical line-number drawing.
- `clipboard.c`: explicit plain-text copy/cut and asynchronous normalized paste.
- `config_manager.c`: canonical defaults, GKeyFile loading, validation and serialization.
- `key_bindings.c`: GTK accelerator validation and GAction accelerator installation.
- `file_manager.c`: UTF-8 file operations through GIO.
- `text_normalization.c`: standalone newline normalization.

## GTK-specific decisions and limitations

- `GtkTextBuffer` is the document model; GTK native undo/redo replaces Qt's undo framework.
- The gutter is attached to the text view's native left gutter rather than a separately scrolling widget.
- GTK CSS styles the editor frame; it cannot override the native window-manager decoration.
- The optional block cursor is a custom, translucent GTK drawing overlay attached to the `GtkTextView` at the insertion mark. It follows text scrolling and uses the active text colour. It is non-blinking by default. Set `block_cursor_blink=true` in `[editor]` in `config.ini` to enable blinking; the desktop GTK cursor blink time controls the blink period. Toggle the block cursor with **View → Block Cursor** or **Ctrl+B**. GTK's native insertion cursor remains enabled while the overlay is active: this is important because GTK routes arrow, Home/End, and PageUp/PageDown navigation through its native cursor-visible state. The overlay changes only the caret's visual appearance; GTK continues to handle keyboard navigation and text input.

Example for a steady block cursor:

```ini
[editor]
block_cursor=true
block_cursor_blink=false
```
- GTK's `GtkFileDialog` and `GtkAlertDialog` are used, requiring GTK 4.10+; the project baseline is 4.16+.

## Troubleshooting

- **GTK version error:** verify `pkg-config --modversion gtk4` reports 4.16 or newer.
- **Meson cannot find GTK:** install `libgtk-4-dev` and `pkg-config`.
- **Configuration warning:** invalid values fall back to safe defaults; consult the terminal output.
- **File will not open:** invalid UTF-8 is intentionally rejected; convert the source file to UTF-8.
- **Border does not affect title bar:** this is intentional; window decorations belong to the desktop environment.

## Test coverage

The GLib test executable checks newline normalization, UTF-8/BOM handling, file round trips, GtkTextBuffer newline/undo/redo behaviour, canonical defaults, serialization, and partial configuration loading. See `VERIFICATION.md` for the environment-specific build/test status of this source package. Display-dependent manual checks (window sizing, gutter alignment, visual border verification, full-screen behaviour, clipboard interaction and high-DPI rendering) must be performed on a GTK desktop session. A successful test run should be reported only after running `meson test` on a machine with the required GTK development packages.

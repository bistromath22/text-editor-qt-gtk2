#include <glib.h>
#include <gtk/gtk.h>
#include <gio/gio.h>
#include "text_normalization.h"
#include "file_manager.h"
#include "config_manager.h"
#include <string.h>
#include <glib/gstdio.h>

static void test_newlines(void)
{
    struct { const gchar *input; const gchar *expected; } cases[] = {
        {"a\nb", "a\nb"}, {"a\r\nb", "a\nb"}, {"a\rb", "a\nb"},
        {"\r\n\rX\n", "\n\nX\n"}, {"", ""}, {"\n", "\n"},
        {"a\n\n\n", "a\n\n\n"}, {"\r\n\r\n", "\n\n"}
    };
    for (guint i=0;i<G_N_ELEMENTS(cases);i++) {
        gchar *actual=gslate_normalize_newlines(cases[i].input,-1);
        g_assert_cmpstr(actual,==,cases[i].expected);g_free(actual);
    }
}

static void test_file_roundtrip(void)
{
    GError *error=NULL;
    gchar *dir=g_dir_make_tmp("gslate-test-XXXXXX",&error);g_assert_no_error(error);
    gchar *path=g_build_filename(dir,"sample.txt",NULL);
    GFile *file=g_file_new_for_path(path);
    const gchar source[]="\nalpha\r\nbeta\r\n\n";
    g_assert_true(g_file_set_contents(path,source,sizeof source-1,&error));g_assert_no_error(error);
    gchar *loaded=gslate_file_load_text(file,&error);g_assert_no_error(error);
    g_assert_cmpstr(loaded,==,"\nalpha\nbeta\n\n");
    g_assert_true(gslate_file_save_text(file,loaded,strlen(loaded),&error));g_assert_no_error(error);
    gchar *saved=NULL;gsize length=0;g_assert_true(g_file_load_contents(file,NULL,&saved,&length,NULL,&error));g_assert_no_error(error);
    g_assert_cmpmem(saved,length,loaded,strlen(loaded));
    g_free(saved);g_free(loaded);g_object_unref(file);g_remove(path);g_rmdir(dir);g_free(path);g_free(dir);
}

static void test_bom_and_invalid_utf8(void)
{
    GError *error=NULL; gchar *dir=g_dir_make_tmp("gslate-utf8-XXXXXX",&error);g_assert_no_error(error);
    gchar *path=g_build_filename(dir,"bom.txt",NULL);GFile *file=g_file_new_for_path(path);
    const gchar bom_text[]="\xEF\xBB\xBFhello\rworld";
    g_assert_true(g_file_set_contents(path,bom_text,sizeof bom_text-1,&error));g_assert_no_error(error);
    gchar *text=gslate_file_load_text(file,&error);g_assert_no_error(error);g_assert_cmpstr(text,==,"hello\nworld");g_free(text);
    const gchar invalid[]={(gchar)0xFF,(gchar)0xFE,0};g_assert_true(g_file_set_contents(path,invalid,2,&error));g_assert_no_error(error);
    text=gslate_file_load_text(file,&error);g_assert_null(text);g_assert_error(error,G_CONVERT_ERROR,G_CONVERT_ERROR_ILLEGAL_SEQUENCE);g_clear_error(&error);
    g_object_unref(file);g_remove(path);g_rmdir(dir);g_free(path);g_free(dir);
}


static gchar *buffer_dup_text(GtkTextBuffer *buffer)
{
    GtkTextIter start, end;
    gtk_text_buffer_get_bounds(buffer, &start, &end);
    return gtk_text_buffer_get_text(buffer, &start, &end, TRUE);
}

static void test_buffer_newline_and_undo(void)
{
    GtkTextBuffer *buffer = gtk_text_buffer_new(NULL);
    gtk_text_buffer_set_enable_undo(buffer, TRUE);
    /* Loading a document must clear the previous undo baseline. */
    gtk_text_buffer_set_enable_undo(buffer, FALSE);
    gtk_text_buffer_set_text(buffer, "first\nsecond\n", -1);
    gtk_text_buffer_set_enable_undo(buffer, TRUE);
    g_assert_false(gtk_text_buffer_get_can_undo(buffer));
    gchar *initial = buffer_dup_text(buffer);
    g_assert_cmpstr(initial, ==, "first\nsecond\n");
    g_assert_cmpint(gtk_text_buffer_get_line_count(buffer), ==, 3);

    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_begin_user_action(buffer);
    gtk_text_buffer_insert(buffer, &end, "emoji 😀\ncombining é", -1);
    gtk_text_buffer_end_user_action(buffer);
    gchar *edited = buffer_dup_text(buffer);
    g_assert_true(g_utf8_validate(edited, -1, NULL));
    g_assert_true(g_str_has_prefix(edited, initial));
    g_assert_true(gtk_text_buffer_get_can_undo(buffer));

    gtk_text_buffer_undo(buffer);
    gchar *undone = buffer_dup_text(buffer);
    g_assert_cmpstr(undone, ==, initial);
    g_assert_true(gtk_text_buffer_get_can_redo(buffer));

    gtk_text_buffer_redo(buffer);
    gchar *redone = buffer_dup_text(buffer);
    g_assert_cmpstr(redone, ==, edited);

    g_free(initial); g_free(edited); g_free(undone); g_free(redone);
    g_object_unref(buffer);
}

static void test_config_defaults(void)
{
    GSlateConfig cfg;gslate_config_init_defaults(&cfg);
    g_assert_true(cfg.wordwrap);g_assert_false(cfg.block_cursor_blink);
    g_assert_cmpint(cfg.border_size,==,8);g_assert_cmpint(cfg.font_size,==,12);
    g_assert_cmpfloat_with_epsilon(cfg.line_height,1.4,0.00001);
    g_assert_cmpstr(cfg.background_color,==,"#1e1e2e");g_assert_cmpstr(cfg.text_color,==,"#cdd6f4");
    g_assert_cmpstr(cfg.shortcuts[15],==,"<Primary>b");
    gsize len=0;gchar *serialized=gslate_config_to_data(&cfg,&len);
    g_assert_nonnull(strstr(serialized,"border_size=8"));g_assert_nonnull(strstr(serialized,"show_line_numbers=true"));
    g_assert_nonnull(strstr(serialized,"toggle_block_cursor=<Primary>b"));
    g_assert_nonnull(strstr(serialized,"block_cursor_blink=false"));
    g_assert_cmpuint(len,>,0);g_free(serialized);gslate_config_clear(&cfg);
}

static void test_partial_config(void)
{
    GError *error=NULL;gchar *dir=g_dir_make_tmp("gslate-config-XXXXXX",&error);g_assert_no_error(error);
    gchar *path=g_build_filename(dir,"config.ini",NULL);
    g_assert_true(g_file_set_contents(path,"[editor]\nfont_size=16\nwordwrap=false\nblock_cursor=true\nblock_cursor_blink=true\n",-1,&error));g_assert_no_error(error);
    GSlateConfig cfg;gslate_config_init_defaults(&cfg);g_assert_true(gslate_config_load(&cfg,path,&error));g_assert_no_error(error);
    g_assert_cmpint(cfg.font_size,==,16);g_assert_false(cfg.wordwrap);
    g_assert_true(cfg.block_cursor);g_assert_true(cfg.block_cursor_blink);
    g_assert_cmpint(cfg.border_size,==,8);
    gslate_config_clear(&cfg);g_remove(path);g_rmdir(dir);g_free(path);g_free(dir);
}

int main(int argc,char **argv)
{
    g_test_init(&argc,&argv,NULL);
    g_test_add_func("/text/newline-normalization",test_newlines);
    g_test_add_func("/file/roundtrip",test_file_roundtrip);
    g_test_add_func("/file/bom-invalid-utf8",test_bom_and_invalid_utf8);
    g_test_add_func("/editor/buffer-newline-undo-redo",test_buffer_newline_and_undo);
    g_test_add_func("/config/defaults",test_config_defaults);
    g_test_add_func("/config/partial",test_partial_config);
    return g_test_run();
}

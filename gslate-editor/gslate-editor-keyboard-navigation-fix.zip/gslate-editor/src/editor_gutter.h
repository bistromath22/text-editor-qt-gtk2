#ifndef GSLATE_EDITOR_GUTTER_H
#define GSLATE_EDITOR_GUTTER_H
#include <gtk/gtk.h>
typedef struct _GSlateEditor GSlateEditor;
GtkWidget *gslate_gutter_new(GSlateEditor *editor);
void gslate_gutter_queue_draw(GSlateEditor *editor);
#endif

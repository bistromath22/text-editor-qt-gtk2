#include "config_manager.h"
#include <math.h>
#include <gdk/gdk.h>
#include <string.h>

static const gchar *shortcut_names[] = {
    "new_file", "open", "save", "save_as", "quit", "undo", "redo", "cut", "copy", "paste",
    "find", "find_next", "goto_line", "reload_config", "toggle_wordwrap", "toggle_block_cursor",
    "increase_font", "decrease_font", "fullscreen", "toggle_line_numbers", "toggle_current_line", "toggle_statusbar"
};
static const gchar *shortcut_defaults[] = {
    "<Primary>n", "<Primary>o", "<Primary>s", "<Primary><Shift>s", "<Primary>q",
    "<Primary>z", "<Primary>y", "<Primary>x", "<Primary>c", "<Primary>v",
    "<Primary>f", "F3", "<Primary>g", "<Primary>r", "<Primary>w", "<Primary>b",
    "<Primary>plus", "<Primary>minus", "F11", "<Primary>l", "<Primary>h", "<Primary><Shift>b"
};

const gchar *gslate_config_shortcut_name(guint i) { return i < G_N_ELEMENTS(shortcut_names) ? shortcut_names[i] : NULL; }
const gchar *gslate_config_shortcut_default(guint i) { return i < G_N_ELEMENTS(shortcut_defaults) ? shortcut_defaults[i] : NULL; }

void
gslate_config_init_defaults(GSlateConfig *c)
{
    memset(c, 0, sizeof *c);
    c->wordwrap = TRUE; c->block_cursor = FALSE; c->block_cursor_blink = FALSE; c->show_line_numbers = TRUE;
    c->highlight_current_line = TRUE; c->show_statusbar = TRUE;
    c->border_size = 8; c->font_size = 12; c->line_height = 1.4;
    c->pixels_above = 0; c->pixels_below = 0; c->line_distance = 0;
    c->border_color = g_strdup("#313244");
    c->background_color = g_strdup("#1e1e2e");
    c->gutter_background_color = g_strdup("#313244");
    c->current_line_color = g_strdup("#313244");
    c->line_number_color = g_strdup("#6c7086");
    c->text_color = g_strdup("#cdd6f4");
    c->font_family = g_strdup("Monospace");
    for (guint i = 0; i < G_N_ELEMENTS(shortcut_names); i++)
        c->shortcuts[i] = g_strdup(shortcut_defaults[i]);
}

void
gslate_config_clear(GSlateConfig *c)
{
    if (!c) return;
    g_free(c->border_color); g_free(c->background_color); g_free(c->gutter_background_color); g_free(c->current_line_color);
    g_free(c->line_number_color); g_free(c->text_color); g_free(c->font_family);
    for (guint i = 0; i < G_N_ELEMENTS(shortcut_names); i++) g_free(c->shortcuts[i]);
    g_free(c->config_path);
    memset(c, 0, sizeof *c);
}

static void replace_string(GKeyFile *kf, const gchar *group, const gchar *key, gchar **dst)
{
    if (!g_key_file_has_key(kf, group, key, NULL)) return;
    GError *e = NULL; gchar *v = g_key_file_get_string(kf, group, key, &e);
    if (!e && v) { g_free(*dst); *dst = v; }
    else { g_warning("Invalid [%s] %s; retaining its default", group, key); g_clear_error(&e); g_free(v); }
}
static void read_bool(GKeyFile *kf, const gchar *key, gboolean *dst)
{
    if (!g_key_file_has_key(kf, "editor", key, NULL)) return;
    GError *e = NULL; gboolean v = g_key_file_get_boolean(kf, "editor", key, &e);
    if (!e) *dst = v; else { g_warning("Invalid [editor] %s; retaining its default", key); g_clear_error(&e); }
}
static void read_int(GKeyFile *kf, const gchar *key, gint *dst)
{
    if (!g_key_file_has_key(kf, "editor", key, NULL)) return;
    GError *e = NULL; gint v = g_key_file_get_integer(kf, "editor", key, &e);
    if (!e) *dst = v; else { g_warning("Invalid [editor] %s; retaining its default", key); g_clear_error(&e); }
}
static void read_double(GKeyFile *kf, const gchar *key, gdouble *dst)
{
    if (!g_key_file_has_key(kf, "editor", key, NULL)) return;
    GError *e = NULL; gdouble v = g_key_file_get_double(kf, "editor", key, &e);
    if (!e) *dst = v; else { g_warning("Invalid [editor] %s; retaining its default", key); g_clear_error(&e); }
}

static gboolean valid_color(const gchar *s)
{
    GdkRGBA rgba;
    return s && gdk_rgba_parse(&rgba, s);
}

static gboolean
valid_font_family(const gchar *family)
{
    if (!family || !*family || !g_utf8_validate(family, -1, NULL))
        return FALSE;
    for (const gchar *p = family; *p; p = g_utf8_next_char(p)) {
        gunichar ch = g_utf8_get_char(p);
        if (g_unichar_iscntrl(ch) || ch == '\"' || ch == '\\')
            return FALSE;
    }
    return TRUE;
}

gboolean
gslate_config_validate(GSlateConfig *c, GError **error)
{
    gchar **colors[] = {&c->border_color, &c->background_color,
        &c->gutter_background_color, &c->current_line_color,
        &c->line_number_color, &c->text_color};
    const gchar *fallbacks[] = {"#313244", "#1e1e2e", "#313244", "#313244", "#6c7086", "#cdd6f4"};
    for (guint i = 0; i < G_N_ELEMENTS(colors); i++) {
        if (!valid_color(*colors[i])) { g_free(*colors[i]); *colors[i] = g_strdup(fallbacks[i]);
            g_warning("Invalid colour in configuration; using %s", fallbacks[i]); }
    }
    if (c->font_size < 6 || c->font_size > 72) { g_warning("font_size must be 6..72; using 12"); c->font_size = 12; }
    if (c->border_size < 0 || c->border_size > 64) { g_warning("border_size must be 0..64; using 8"); c->border_size = 8; }
    if (!isfinite(c->line_height) || c->line_height < 0.5 || c->line_height > 5.0) { g_warning("line_height must be 0.5..5.0; using 1.4"); c->line_height = 1.4; }
    if (c->pixels_above < 0 || c->pixels_above > 128) { g_warning("pixels_above out of range; using 0"); c->pixels_above = 0; }
    if (c->pixels_below < 0 || c->pixels_below > 128) { g_warning("pixels_below out of range; using 0"); c->pixels_below = 0; }
    if (c->line_distance < 0 || c->line_distance > 64) { g_warning("line_distance out of range; using 0"); c->line_distance = 0; }
    if (!valid_font_family(c->font_family)) {
        g_warning("Invalid font family; using Monospace"); g_free(c->font_family); c->font_family = g_strdup("Monospace");
    }
    (void)error;
    return TRUE;
}

gchar *
gslate_config_discover_path(const gchar *explicit_path)
{
    if (explicit_path) return g_strdup(explicit_path);
    if (g_file_test("config.ini", G_FILE_TEST_IS_REGULAR)) return g_strdup("config.ini");
    const gchar *xdg = g_get_user_config_dir();
    gchar *user = g_build_filename(xdg, "gslate-editor", "config.ini", NULL);
    if (g_file_test(user, G_FILE_TEST_IS_REGULAR)) return user;
    g_free(user);
    if (g_file_test("/etc/gslate-editor/config.ini", G_FILE_TEST_IS_REGULAR))
        return g_strdup("/etc/gslate-editor/config.ini");
    return NULL;
}

gboolean
gslate_config_load(GSlateConfig *c, const gchar *path, GError **error)
{
    GKeyFile *kf = g_key_file_new();
    if (!g_key_file_load_from_file(kf, path, G_KEY_FILE_NONE, error)) { g_key_file_unref(kf); return FALSE; }
    read_bool(kf, "wordwrap", &c->wordwrap); read_bool(kf, "block_cursor", &c->block_cursor);
    read_bool(kf, "block_cursor_blink", &c->block_cursor_blink);
    read_bool(kf, "show_line_numbers", &c->show_line_numbers); read_bool(kf, "highlight_current_line", &c->highlight_current_line);
    read_bool(kf, "show_statusbar", &c->show_statusbar);
    read_int(kf, "border_size", &c->border_size); read_int(kf, "font_size", &c->font_size);
    read_int(kf, "pixels_above", &c->pixels_above); read_int(kf, "pixels_below", &c->pixels_below); read_int(kf, "line_distance", &c->line_distance);
    read_double(kf, "line_height", &c->line_height);
    replace_string(kf, "editor", "border_color", &c->border_color); replace_string(kf, "editor", "background_color", &c->background_color);
    replace_string(kf, "editor", "gutter_background_color", &c->gutter_background_color);
    replace_string(kf, "editor", "current_line_color", &c->current_line_color); replace_string(kf, "editor", "line_number_color", &c->line_number_color);
    replace_string(kf, "editor", "text_color", &c->text_color); replace_string(kf, "editor", "font_family", &c->font_family);
    for (guint i = 0; i < G_N_ELEMENTS(shortcut_names); i++) replace_string(kf, "shortcuts", shortcut_names[i], &c->shortcuts[i]);
    g_key_file_unref(kf);
    if (!gslate_config_validate(c, error)) return FALSE;
    g_free(c->config_path); c->config_path = g_strdup(path);
    return TRUE;
}

gchar *
gslate_config_to_data(const GSlateConfig *c, gsize *length)
{
    GKeyFile *k = g_key_file_new();
    g_key_file_set_boolean(k,"editor","wordwrap",c->wordwrap); g_key_file_set_integer(k,"editor","border_size",c->border_size);
    g_key_file_set_string(k,"editor","border_color",c->border_color); g_key_file_set_string(k,"editor","background_color",c->background_color);
    g_key_file_set_string(k,"editor","gutter_background_color",c->gutter_background_color);
    g_key_file_set_string(k,"editor","current_line_color",c->current_line_color); g_key_file_set_string(k,"editor","line_number_color",c->line_number_color);
    g_key_file_set_string(k,"editor","text_color",c->text_color); g_key_file_set_boolean(k,"editor","block_cursor",c->block_cursor);
    g_key_file_set_boolean(k,"editor","block_cursor_blink",c->block_cursor_blink);
    g_key_file_set_string(k,"editor","font_family",c->font_family); g_key_file_set_integer(k,"editor","font_size",c->font_size);
    g_key_file_set_double(k,"editor","line_height",c->line_height); g_key_file_set_integer(k,"editor","pixels_above",c->pixels_above);
    g_key_file_set_integer(k,"editor","pixels_below",c->pixels_below); g_key_file_set_integer(k,"editor","line_distance",c->line_distance);
    g_key_file_set_boolean(k,"editor","show_line_numbers",c->show_line_numbers); g_key_file_set_boolean(k,"editor","highlight_current_line",c->highlight_current_line);
    g_key_file_set_boolean(k,"editor","show_statusbar",c->show_statusbar);
    for (guint i=0;i<G_N_ELEMENTS(shortcut_names);i++) if (c->shortcuts[i] && *c->shortcuts[i]) g_key_file_set_string(k,"shortcuts",shortcut_names[i],c->shortcuts[i]);
    gchar *data = g_key_file_to_data(k,length,NULL); g_key_file_unref(k); return data;
}

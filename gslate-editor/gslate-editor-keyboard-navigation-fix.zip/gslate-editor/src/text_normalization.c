#include "text_normalization.h"
#include <string.h>

/* A single pass avoids turning CRLF into two line breaks. */
gchar *
gslate_normalize_newlines(const gchar *text, gssize length)
{
    GString *out;
    gsize n;

    g_return_val_if_fail(text != NULL || length == 0, NULL);
    n = (length < 0) ? strlen(text) : (gsize)length;
    out = g_string_sized_new(n + 1);

    for (gsize i = 0; i < n; i++) {
        if (text[i] == '\r') {
            g_string_append_c(out, '\n');
            if (i + 1 < n && text[i + 1] == '\n')
                i++;
        } else {
            g_string_append_c(out, text[i]);
        }
    }
    return g_string_free(out, FALSE);
}

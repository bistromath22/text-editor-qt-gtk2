#ifndef GSLATE_KEY_BINDINGS_H
#define GSLATE_KEY_BINDINGS_H
#include <gtk/gtk.h>
#include "config_manager.h"
void gslate_key_bindings_apply(GtkApplication *app, const GSlateConfig *config);
#endif

#ifndef GSLATE_MAIN_WINDOW_H
#define GSLATE_MAIN_WINDOW_H
#include <gtk/gtk.h>
#include "config_manager.h"

typedef struct _GSlateMainWindow GSlateMainWindow;
GSlateMainWindow *gslate_main_window_new(GtkApplication *app, const GSlateConfig *config,
                                        const gchar *config_path, const gchar *initial_file);
void gslate_main_window_present(GSlateMainWindow *self);
#endif

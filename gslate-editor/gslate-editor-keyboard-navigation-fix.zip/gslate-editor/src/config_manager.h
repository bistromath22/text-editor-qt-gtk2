#ifndef GSLATE_CONFIG_MANAGER_H
#define GSLATE_CONFIG_MANAGER_H
#include <glib.h>

typedef struct {
    gboolean wordwrap, block_cursor, block_cursor_blink, show_line_numbers, highlight_current_line, show_statusbar;
    gint border_size, font_size, pixels_above, pixels_below, line_distance;
    gdouble line_height;
    gchar *border_color, *background_color, *gutter_background_color, *current_line_color;
    gchar *line_number_color, *text_color, *font_family;
    gchar *shortcuts[22];
    gchar *config_path;
} GSlateConfig;

void gslate_config_init_defaults(GSlateConfig *cfg);
void gslate_config_clear(GSlateConfig *cfg);
gboolean gslate_config_load(GSlateConfig *cfg, const gchar *path, GError **error);
gchar *gslate_config_discover_path(const gchar *explicit_path);
gchar *gslate_config_to_data(const GSlateConfig *cfg, gsize *length);
const gchar *gslate_config_shortcut_name(guint index);
const gchar *gslate_config_shortcut_default(guint index);
gboolean gslate_config_validate(GSlateConfig *cfg, GError **error);
#endif

#include "file_manager.h"
#include "text_normalization.h"
#include <string.h>

#define UTF8_BOM "\xEF\xBB\xBF"

gchar *
gslate_file_load_text(GFile *file, GError **error)
{
    gchar *contents = NULL;
    gsize length = 0;
    gchar *normalized;
    const gchar *payload;
    gsize payload_len;

    g_return_val_if_fail(G_IS_FILE(file), NULL);
    if (!g_file_load_contents(file, NULL, &contents, &length, NULL, error))
        return NULL;

    payload = contents;
    payload_len = length;
    if (payload_len >= 3 && memcmp(payload, UTF8_BOM, 3) == 0) {
        payload += 3;
        payload_len -= 3;
    }
    if (!g_utf8_validate(payload, (gssize)payload_len, NULL)) {
        g_set_error_literal(error, G_CONVERT_ERROR, G_CONVERT_ERROR_ILLEGAL_SEQUENCE,
                            "The file is not valid UTF-8 text.");
        g_free(contents);
        return NULL;
    }
    normalized = gslate_normalize_newlines(payload, (gssize)payload_len);
    g_free(contents);
    return normalized;
}

gboolean
gslate_file_save_text(GFile *file, const gchar *text, gsize length, GError **error)
{
    g_return_val_if_fail(G_IS_FILE(file), FALSE);
    g_return_val_if_fail(text != NULL || length == 0, FALSE);
    if (!g_utf8_validate(text ? text : "", (gssize)length, NULL)) {
        g_set_error_literal(error, G_CONVERT_ERROR, G_CONVERT_ERROR_ILLEGAL_SEQUENCE,
                            "Refusing to save invalid UTF-8 text.");
        return FALSE;
    }
    /* GIO replaces the destination safely instead of truncating it first. */
    return g_file_replace_contents(file, text ? text : "", length, NULL, FALSE,
                                   G_FILE_CREATE_REPLACE_DESTINATION, NULL, NULL, error);
}

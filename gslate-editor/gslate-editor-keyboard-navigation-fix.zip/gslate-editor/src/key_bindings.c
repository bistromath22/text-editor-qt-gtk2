#include "key_bindings.h"
#include <string.h>

static const gchar *actions[] = {
    "app.new", "app.open", "app.save", "app.save-as", "app.quit",
    "app.undo", "app.redo", "app.cut", "app.copy", "app.paste",
    "app.find", "app.find-next", "app.goto-line", "app.reload-config",
    "app.word-wrap", "app.block-cursor", "app.increase-font", "app.decrease-font", "app.fullscreen",
    "app.line-numbers", "app.current-line", "app.statusbar"
};

void
gslate_key_bindings_apply(GtkApplication *app, const GSlateConfig *cfg)
{
    GHashTable *used = g_hash_table_new(g_str_hash, g_str_equal);
    for (guint i = 0; i < G_N_ELEMENTS(actions); i++) {
        const gchar *accel;
        const gchar *list[2];
        guint key = 0; GdkModifierType mods = 0;
        accel = cfg->shortcuts[i] ? cfg->shortcuts[i] : "";
        if (*accel && !gtk_accelerator_parse(accel, &key, &mods)) {
            g_warning("Invalid shortcut '%s' for %s; using no shortcut", accel, actions[i]);
            accel = "";
        }
        if (*accel && g_hash_table_contains(used, accel)) {
            g_warning("Duplicate shortcut '%s'; disabling the later binding for %s", accel, actions[i]);
            accel = "";
        }
        if (*accel) g_hash_table_add(used, (gpointer)accel);
        if (*accel) { list[0] = accel; list[1] = NULL; }
        else { list[0] = NULL; }
        gtk_application_set_accels_for_action(app, actions[i], list);
    }
    g_hash_table_unref(used);
}

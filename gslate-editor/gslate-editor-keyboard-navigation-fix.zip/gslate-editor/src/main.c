#include <gtk/gtk.h>
#include "main_window.h"
#include "config_manager.h"
#include <string.h>
#include <stdio.h>

#ifndef GSLATE_VERSION
#define GSLATE_VERSION "0.1.0"
#endif

typedef struct {
    GSlateConfig config;
    gchar *config_path;
    gchar *initial_file;
} AppState;

static void activate(GtkApplication *app, gpointer data)
{
    AppState *state = data;
    GSlateMainWindow *window = gslate_main_window_new(app, &state->config,
                                                       state->config_path,
                                                       state->initial_file);
    gslate_main_window_present(window);
}

static void print_config_paths(void)
{
    gchar *cwd_dir = g_get_current_dir();
    gchar *cwd = g_build_filename(cwd_dir, "config.ini", NULL);
    gchar *user = g_build_filename(g_get_user_config_dir(), "gslate-editor", "config.ini", NULL);
    g_print("Configuration search order:\n  1. %s\n  2. %s\n  3. /etc/gslate-editor/config.ini\n", cwd, user);
    g_free(cwd_dir); g_free(cwd); g_free(user);
}

int main(int argc, char **argv)
{
    gchar *config_arg = NULL;
    gboolean print_config = FALSE, print_paths = FALSE, show_version = FALSE;
    gchar **files = NULL;
    GOptionEntry options[] = {
        {"config", 'c', 0, G_OPTION_ARG_FILENAME, &config_arg, "Use this configuration file", "PATH"},
        {"print-config", 0, 0, G_OPTION_ARG_NONE, &print_config, "Print the effective configuration", NULL},
        {"print-config-paths", 0, 0, G_OPTION_ARG_NONE, &print_paths, "Print configuration search paths", NULL},
        {"version", 0, 0, G_OPTION_ARG_NONE, &show_version, "Print version", NULL},
        {G_OPTION_REMAINING, 0, 0, G_OPTION_ARG_FILENAME_ARRAY, &files, "Text file to open", "FILE"},
        {NULL}
    };
    GOptionContext *context = g_option_context_new("[FILE...]");
    g_option_context_set_summary(context, "A lightweight native GTK4 plain-text editor.");
    g_option_context_add_main_entries(context, options, NULL);
    GError *error = NULL;
    if (!g_option_context_parse(context, &argc, &argv, &error)) {
        g_printerr("gslate: %s\n", error->message); g_error_free(error);
        g_option_context_free(context); return 2;
    }
    g_option_context_free(context);

    if (show_version) { g_print("gSlate Editor %s\n", GSLATE_VERSION); g_strfreev(files); g_free(config_arg); return 0; }
    if (print_paths) { print_config_paths(); g_strfreev(files); g_free(config_arg); return 0; }

    AppState state = {0};
    gslate_config_init_defaults(&state.config);
    state.config_path = gslate_config_discover_path(config_arg);
    if (state.config_path && !gslate_config_load(&state.config, state.config_path, &error)) {
        g_printerr("gslate: cannot load configuration '%s': %s\nUsing built-in defaults.\n",
                   state.config_path, error->message);
        g_clear_error(&error);
        /* Keep an explicit/discovered path so Reload Config retries the same
         * source instead of silently switching to a different precedence tier. */
    }
    if (print_config) {
        gsize len = 0; gchar *data = gslate_config_to_data(&state.config, &len);
        fwrite(data, 1, len, stdout); g_free(data);
        gslate_config_clear(&state.config); g_free(state.config_path); g_free(config_arg); g_strfreev(files);
        return 0;
    }

    if (files && files[0]) {
        guint count = g_strv_length(files);
        if (count > 1) g_printerr("gslate: this version supports one active document; additional paths are ignored.\n");
        for (guint i = 0; i < count; i++) {
            if (g_file_test(files[i], G_FILE_TEST_EXISTS) && !g_file_test(files[i], G_FILE_TEST_IS_DIR)) {
                state.initial_file = g_strdup(files[i]);
                break;
            }
        }
        if (!state.initial_file) state.initial_file = g_strdup(files[0]);
    }

    GtkApplication *app = gtk_application_new("org.gslate.Editor", G_APPLICATION_NON_UNIQUE);
    g_signal_connect(app, "activate", G_CALLBACK(activate), &state);
    gchar *run_argv[] = {argv[0], NULL};
    int status = g_application_run(G_APPLICATION(app), 1, run_argv);

    g_object_unref(app);
    gslate_config_clear(&state.config);
    g_free(state.config_path); g_free(state.initial_file);
    g_free(config_arg); g_strfreev(files);
    return status;
}

#ifndef GSLATE_EDITOR_H
#define GSLATE_EDITOR_H
#include <gtk/gtk.h>
#include "config_manager.h"

typedef struct _GSlateEditor GSlateEditor;
GSlateEditor *gslate_editor_new(const GSlateConfig *config);
void gslate_editor_free(GSlateEditor *editor);
GtkWidget *gslate_editor_get_widget(GSlateEditor *editor);
GtkTextView *gslate_editor_get_view(GSlateEditor *editor);
GtkTextBuffer *gslate_editor_get_buffer(GSlateEditor *editor);
const GSlateConfig *gslate_editor_get_config(GSlateEditor *editor);
GtkWidget *gslate_editor_get_gutter(GSlateEditor *editor);
void gslate_editor_apply_config(GSlateEditor *editor, const GSlateConfig *config);
void gslate_editor_set_text(GSlateEditor *editor, const gchar *text);
gchar *gslate_editor_dup_text(GSlateEditor *editor);
void gslate_editor_copy(GSlateEditor *editor);
void gslate_editor_cut(GSlateEditor *editor);
void gslate_editor_paste(GSlateEditor *editor);
void gslate_editor_goto_line(GSlateEditor *editor, guint line_1based);
void gslate_editor_refresh_gutter(GSlateEditor *editor);
void gslate_editor_refresh_highlight(GSlateEditor *editor);
guint gslate_editor_get_line_count(GSlateEditor *editor);
#endif

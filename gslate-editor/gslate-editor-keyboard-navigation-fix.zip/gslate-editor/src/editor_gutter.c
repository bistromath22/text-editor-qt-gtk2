#include "editor_gutter.h"
#include "editor.h"
#include <pango/pangocairo.h>

static void draw_gutter(GtkDrawingArea *area, cairo_t *cr, int width, int height, gpointer data)
{
    GSlateEditor *editor = data;
    GtkTextView *view = gslate_editor_get_view(editor);
    GtkTextBuffer *buffer = gslate_editor_get_buffer(editor);
    const GSlateConfig *cfg = gslate_editor_get_config(editor);
    GtkTextIter iter;
    GdkRGBA fg;
    PangoLayout *layout;
    PangoFontDescription *font;
    GdkRGBA bg;

    if (!cfg->show_line_numbers) return;
    if (!gdk_rgba_parse(&fg, cfg->line_number_color)) gdk_rgba_parse(&fg, "#6c7086");
    if (!gdk_rgba_parse(&bg, cfg->gutter_background_color)) gdk_rgba_parse(&bg, "#313244");
    cairo_set_source_rgba(cr, bg.red, bg.green, bg.blue, bg.alpha);
    cairo_paint(cr);
    cairo_set_source_rgba(cr, fg.red, fg.green, fg.blue, fg.alpha);

    layout = pango_cairo_create_layout(cr);
    font = pango_font_description_new();
    pango_font_description_set_family(font, cfg->font_family);
    pango_font_description_set_size(font, MAX(7, cfg->font_size - 2) * PANGO_SCALE);
    pango_layout_set_font_description(layout, font);

    GtkTextIter first;
    GdkRectangle visible;
    gtk_text_view_get_visible_rect(view, &visible);
    gint line_top = 0;
    gtk_text_view_get_line_at_y(view, &first, visible.y, &line_top);
    (void)line_top;
    /* Number each logical paragraph at its first visual row, even when the
     * paragraph wraps across several display rows. */
    gtk_text_iter_set_line_offset(&first, 0);
    iter = first;
    gint logical_line = gtk_text_iter_get_line(&iter);
    while (logical_line < gtk_text_buffer_get_line_count(buffer)) {
        GdkRectangle location;
        gint wx = 0, wy = 0;
        gchar number[32];
        gint tw = 0, th = 0;
        gtk_text_view_get_iter_location(view, &iter, &location);
        gtk_text_view_buffer_to_window_coords(view, GTK_TEXT_WINDOW_LEFT,
                                               location.x, location.y, &wx, &wy);
        (void)wx;
        if (wy > height) break;
        g_snprintf(number, sizeof number, "%d", logical_line + 1);
        pango_layout_set_text(layout, number, -1);
        pango_layout_get_pixel_size(layout, &tw, &th);
        cairo_move_to(cr, MAX(2, width - tw - 7), wy + MAX(0, (location.height - th) / 2));
        pango_cairo_show_layout(cr, layout);
        if (!gtk_text_iter_forward_line(&iter)) break;
        logical_line++;
    }

    pango_font_description_free(font);
    g_object_unref(layout);
    (void)area;
}

GtkWidget *
gslate_gutter_new(GSlateEditor *editor)
{
    GtkWidget *area = gtk_drawing_area_new();
    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(area), draw_gutter, editor, NULL);
    gtk_widget_set_size_request(area, 38, -1);
    gtk_widget_set_hexpand(area, FALSE);
    return area;
}

void
gslate_gutter_queue_draw(GSlateEditor *editor)
{
    GtkWidget *gutter;
    GtkTextBuffer *buffer;
    const GSlateConfig *cfg;
    guint count, digits = 1;
    gint width;
    if (!editor) return;
    gutter = gslate_editor_get_gutter(editor);
    if (!gutter) return;
    buffer = gslate_editor_get_buffer(editor);
    cfg = gslate_editor_get_config(editor);
    count = (guint)gtk_text_buffer_get_line_count(buffer);
    while (count >= 10) { digits++; count /= 10; }
    width = MAX(30, (gint)(digits * cfg->font_size * 0.72) + 14);
    gtk_widget_set_size_request(gutter, width, -1);
    gtk_widget_queue_draw(gutter);
}

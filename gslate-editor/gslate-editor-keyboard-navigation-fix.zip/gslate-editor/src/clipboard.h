#ifndef GSLATE_CLIPBOARD_H
#define GSLATE_CLIPBOARD_H
#include <gtk/gtk.h>
void gslate_clipboard_copy(GtkTextView *view, GtkTextBuffer *buffer);
void gslate_clipboard_cut(GtkTextView *view, GtkTextBuffer *buffer);
void gslate_clipboard_paste(GtkTextView *view, GtkTextBuffer *buffer);
#endif

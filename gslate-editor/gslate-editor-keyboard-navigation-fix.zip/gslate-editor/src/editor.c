#include "editor.h"
#include "editor_gutter.h"
#include "clipboard.h"
#include <pango/pangocairo.h>
#include <string.h>

struct _GSlateEditor {
    GtkWidget *frame;
    GtkWidget *scroller;
    GtkTextView *view;
    GtkTextBuffer *buffer;
    GtkWidget *gutter;
    GtkWidget *cursor_overlay;
    guint cursor_tick_id;
    gboolean cursor_blink_on;
    gint64 cursor_blink_start_us;
    GtkTextTag *line_height_tag;
    GtkTextTag *current_line_tag;
    GtkCssProvider *css;
    GdkDisplay *display;
    GSlateConfig config;
};


static void
cursor_draw(GtkDrawingArea *area, cairo_t *cr, gint width, gint height, gpointer user_data)
{
    GSlateEditor *e = user_data;
    GdkRGBA color;

    (void)area;
    if (!e->config.block_cursor || !e->cursor_blink_on || width <= 0 || height <= 0)
        return;
    if (!gdk_rgba_parse(&color, e->config.text_color))
        return;

    /* A translucent fill keeps the character beneath the block readable;
     * the outline makes the insertion cell visible against either palette. */
    cairo_save(cr);
    cairo_set_source_rgba(cr, color.red, color.green, color.blue, 0.48);
    cairo_rectangle(cr, 0.5, 0.5, MAX(1, width - 1), MAX(1, height - 1));
    cairo_fill_preserve(cr);
    cairo_set_source_rgba(cr, color.red, color.green, color.blue, 0.95);
    cairo_set_line_width(cr, 1.0);
    cairo_stroke(cr);
    cairo_restore(cr);
}

static gint
cursor_fallback_cell_width(GSlateEditor *e)
{
    PangoContext *context = gtk_widget_get_pango_context(GTK_WIDGET(e->view));
    const PangoFontDescription *description = pango_context_get_font_description(context);
    PangoFontMetrics *metrics = pango_context_get_metrics(
        context, description, pango_context_get_language(context));
    gint width = (pango_font_metrics_get_approximate_char_width(metrics) + PANGO_SCALE - 1)
                 / PANGO_SCALE;
    pango_font_metrics_unref(metrics);
    return MAX(width, 4);
}

static void
stop_cursor_blink(GSlateEditor *e)
{
    if (e->cursor_tick_id != 0) {
        gtk_widget_remove_tick_callback(GTK_WIDGET(e->view), e->cursor_tick_id);
        e->cursor_tick_id = 0;
    }
    e->cursor_blink_on = TRUE;
    if (e->cursor_overlay)
        gtk_widget_queue_draw(e->cursor_overlay);
}

static void
hide_block_cursor(GSlateEditor *e)
{
    stop_cursor_blink(e);
    if (e->cursor_overlay)
        gtk_widget_set_visible(e->cursor_overlay, FALSE);
}

static gboolean
cursor_tick(GtkWidget *widget, GdkFrameClock *clock, gpointer user_data)
{
    GSlateEditor *e = user_data;
    GtkSettings *settings = gtk_widget_get_settings(widget);
    gint cycle_ms = 1200;
    gboolean visible;

    if (!e->config.block_cursor || !e->config.block_cursor_blink ||
        !gtk_widget_has_focus(widget))
        return G_SOURCE_CONTINUE;

    /* The application's config controls whether the custom block cursor
     * blinks. GTK's desktop setting is used only for the blink period. */
    if (settings)
        g_object_get(settings, "gtk-cursor-blink-time", &cycle_ms, NULL);

    gint64 elapsed = MAX((gint64)0,
        gdk_frame_clock_get_frame_time(clock) - e->cursor_blink_start_us);
    gint64 half_cycle_us = (gint64)MAX(cycle_ms / 2, 50) * 1000;
    visible = ((elapsed / half_cycle_us) % 2) == 0;

    if (visible != e->cursor_blink_on) {
        e->cursor_blink_on = visible;
        gtk_widget_queue_draw(e->cursor_overlay);
    }
    return G_SOURCE_CONTINUE;
}

static void
start_cursor_blink(GSlateEditor *e)
{
    GdkFrameClock *clock;

    if (!e->config.block_cursor || !e->config.block_cursor_blink ||
        !gtk_widget_has_focus(GTK_WIDGET(e->view))) {
        stop_cursor_blink(e);
        return;
    }

    clock = gtk_widget_get_frame_clock(GTK_WIDGET(e->view));
    e->cursor_blink_start_us = clock
        ? gdk_frame_clock_get_frame_time(clock)
        : g_get_monotonic_time();
    e->cursor_blink_on = TRUE;
    if (e->cursor_tick_id == 0) {
        e->cursor_tick_id = gtk_widget_add_tick_callback(
            GTK_WIDGET(e->view), cursor_tick, e, NULL);
    }
}

static void
refresh_block_cursor(GSlateEditor *e)
{
    GtkTextIter iter;
    GdkRectangle caret;
    gint width;

    if (!e || !e->view || !e->cursor_overlay)
        return;

    /* Keep GtkTextView's insertion cursor logically visible even when the
     * custom block-cursor overlay is active. GtkTextView's built-in
     * move-cursor key bindings (arrows, Home/End, PageUp/PageDown, etc.)
     * move the viewport instead of the insertion mark when cursor-visible
     * is FALSE. The overlay supplies the block-cursor appearance; it must
     * never disable GTK's native caret/navigation pipeline. */
    gtk_text_view_set_cursor_visible(e->view, TRUE);
    if (!e->config.block_cursor || !gtk_widget_has_focus(GTK_WIDGET(e->view))) {
        hide_block_cursor(e);
        return;
    }

    gtk_text_buffer_get_iter_at_mark(e->buffer, &iter,
                                     gtk_text_buffer_get_insert(e->buffer));
    gtk_text_view_get_cursor_locations(e->view, &iter, &caret, NULL);

    /* Use the actual glyph advance when a character follows the insertion
     * mark. At EOL/EOF or before a paragraph separator, use Pango's
     * approximate monospace cell width instead. */
    width = cursor_fallback_cell_width(e);
    if (!gtk_text_iter_is_end(&iter)) {
        gunichar next_char = gtk_text_iter_get_char(&iter);
        if (next_char != '\n' && next_char != '\r') {
            GdkRectangle glyph;
            gtk_text_view_get_iter_location(e->view, &iter, &glyph);
            if (glyph.width > 0)
                width = glyph.width;
        }
    }

    if (caret.height <= 0) {
        gint line_top = 0, line_height = 0;
        gtk_text_view_get_line_yrange(e->view, &iter, &line_top, &line_height);
        caret.y = line_top;
        caret.height = MAX(line_height, 1);
    }
    caret.height = MAX(caret.height, 1);
    width = CLAMP(width, 1, 128);

    gtk_widget_set_size_request(e->cursor_overlay, width, caret.height);
    gtk_text_view_move_overlay(e->view, e->cursor_overlay, caret.x, caret.y);
    gtk_widget_set_visible(e->cursor_overlay, TRUE);
    gtk_widget_queue_draw(e->cursor_overlay);
    if (e->config.block_cursor_blink)
        start_cursor_blink(e);
    else
        stop_cursor_blink(e);
}

static void
on_view_focus_enter(GtkEventControllerFocus *controller, gpointer user_data)
{
    GSlateEditor *e = user_data;
    start_cursor_blink(e);
    refresh_block_cursor(e);
    (void)controller;
}

static void
on_view_focus_leave(GtkEventControllerFocus *controller, gpointer user_data)
{
    GSlateEditor *e = user_data;
    hide_block_cursor(e);
    (void)controller;
}

static void
on_view_mapped(GtkWidget *widget, gpointer user_data)
{
    refresh_block_cursor(user_data);
    (void)widget;
}

static void
on_view_geometry_changed(GObject *object, GParamSpec *pspec, gpointer user_data)
{
    refresh_block_cursor(user_data);
    (void)object;
    (void)pspec;
}

static void update_inserted_format(GtkTextBuffer *buffer, const GtkTextIter *location,
                                   gchar *text, gint len, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gint chars = (len < 0) ? (gint)g_utf8_strlen(text, -1) : (gint)g_utf8_strlen(text, len);
    GtkTextIter end = *location, start = *location;
    if (chars > 0 && gtk_text_iter_backward_chars(&start, chars))
        gtk_text_buffer_apply_tag(buffer, e->line_height_tag, &start, &end);
}

static void on_mark_set(GtkTextBuffer *buffer, const GtkTextIter *location,
                        GtkTextMark *mark, gpointer user_data)
{
    GSlateEditor *e = user_data;
    if (mark == gtk_text_buffer_get_insert(buffer)) {
        gslate_editor_refresh_highlight(e);
        refresh_block_cursor(e);
    }
    gslate_gutter_queue_draw(e);
    (void)location;
}

static void on_buffer_changed(GtkTextBuffer *buffer, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gslate_editor_refresh_gutter(e);
    gslate_editor_refresh_highlight(e);
    refresh_block_cursor(e);
    (void)buffer;
}

static void on_copy_signal(GtkTextView *view, gpointer user_data)
{
    gslate_editor_copy(user_data);
    g_signal_stop_emission_by_name(view, "copy-clipboard");
}

static void on_cut_signal(GtkTextView *view, gpointer user_data)
{
    gslate_editor_cut(user_data);
    g_signal_stop_emission_by_name(view, "cut-clipboard");
}

static void on_paste_signal(GtkTextView *view, gpointer user_data)
{
    GSlateEditor *e = user_data;
    gslate_editor_paste(e);
    g_signal_stop_emission_by_name(view, "paste-clipboard");
}

static void apply_css(GSlateEditor *e)
{
    gchar *css = g_strdup_printf(
        ".slate-editor-frame { border-style: solid; border-radius: 0; border-width: %dpx; border-color: %s; padding: 0; }\n"
        ".gslate-text-view, .gslate-text-view text { background-color: %s; color: %s; font-family: \"%s\"; font-size: %dpt; }\n"
        ".gslate-gutter { background-color: %s; color: %s; }\n",
        e->config.border_size, e->config.border_color, e->config.background_color,
        e->config.text_color, e->config.font_family, e->config.font_size,
        e->config.gutter_background_color, e->config.line_number_color);
    gtk_css_provider_load_from_string(e->css, css);
    g_free(css);
}

GSlateEditor *
gslate_editor_new(const GSlateConfig *config)
{
    GSlateEditor *e = g_new0(GSlateEditor, 1);
    gslate_config_init_defaults(&e->config);
    gslate_editor_apply_config(e, config);

    e->buffer = gtk_text_buffer_new(NULL);
    gtk_text_buffer_set_enable_undo(e->buffer, TRUE);
    e->view = GTK_TEXT_VIEW(gtk_text_view_new_with_buffer(e->buffer));
    gtk_text_view_set_monospace(e->view, TRUE);
    gtk_text_view_set_wrap_mode(e->view, e->config.wordwrap ? GTK_WRAP_WORD_CHAR : GTK_WRAP_NONE);
    gtk_widget_add_css_class(GTK_WIDGET(e->view), "gslate-text-view");
    gtk_text_view_set_left_margin(e->view, 8);
    gtk_text_view_set_right_margin(e->view, 8);

    e->line_height_tag = gtk_text_buffer_create_tag(e->buffer, "gslate-line-height", NULL);
    e->current_line_tag = gtk_text_buffer_create_tag(e->buffer, "gslate-current-line", NULL);
    e->frame = gtk_frame_new(NULL);
    gtk_widget_add_css_class(e->frame, "slate-editor-frame");
    e->scroller = gtk_scrolled_window_new();
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(e->scroller), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(e->scroller), GTK_WIDGET(e->view));
    gtk_frame_set_child(GTK_FRAME(e->frame), e->scroller);
    gtk_widget_set_hexpand(e->frame, TRUE); gtk_widget_set_vexpand(e->frame, TRUE);

    e->gutter = gslate_gutter_new(e);
    gtk_widget_add_css_class(e->gutter, "gslate-gutter");
    gtk_text_view_set_gutter(e->view, GTK_TEXT_WINDOW_LEFT, e->gutter);
    gtk_widget_set_visible(e->gutter, e->config.show_line_numbers);

    /* GtkTextView overlays use buffer coordinates and scroll with the text,
     * so the custom block caret stays attached to its insertion position. */
    e->cursor_overlay = gtk_drawing_area_new();
    gtk_widget_set_can_target(e->cursor_overlay, FALSE);
    gtk_widget_set_focusable(e->cursor_overlay, FALSE);
    gtk_widget_set_halign(e->cursor_overlay, GTK_ALIGN_START);
    gtk_widget_set_valign(e->cursor_overlay, GTK_ALIGN_START);
    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(e->cursor_overlay),
                                   cursor_draw, e, NULL);
    gtk_widget_set_visible(e->cursor_overlay, FALSE);
    gtk_text_view_add_overlay(e->view, e->cursor_overlay, 0, 0);

    GtkEventController *focus = gtk_event_controller_focus_new();
    g_signal_connect(focus, "enter", G_CALLBACK(on_view_focus_enter), e);
    g_signal_connect(focus, "leave", G_CALLBACK(on_view_focus_leave), e);
    gtk_widget_add_controller(GTK_WIDGET(e->view), focus);
    g_signal_connect(e->view, "map", G_CALLBACK(on_view_mapped), e);
    g_signal_connect(e->view, "notify::width", G_CALLBACK(on_view_geometry_changed), e);

    e->display = g_object_ref(gtk_widget_get_display(GTK_WIDGET(e->view)));
    e->css = gtk_css_provider_new();
    gtk_style_context_add_provider_for_display(e->display,
        GTK_STYLE_PROVIDER(e->css), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    apply_css(e);
    g_signal_connect_after(e->buffer, "insert-text", G_CALLBACK(update_inserted_format), e);
    g_signal_connect(e->buffer, "mark-set", G_CALLBACK(on_mark_set), e);
    g_signal_connect(e->buffer, "changed", G_CALLBACK(on_buffer_changed), e);
    g_signal_connect(e->view, "copy-clipboard", G_CALLBACK(on_copy_signal), e);
    g_signal_connect(e->view, "cut-clipboard", G_CALLBACK(on_cut_signal), e);
    g_signal_connect(e->view, "paste-clipboard", G_CALLBACK(on_paste_signal), e);
    gslate_editor_apply_config(e, config);
    return e;
}

void
gslate_editor_free(GSlateEditor *e)
{
    if (!e) return;
    if (e->css && e->view) {
        gtk_style_context_remove_provider_for_display(e->display, GTK_STYLE_PROVIDER(e->css));
        g_object_unref(e->css);
    }
    g_clear_object(&e->display);
    gslate_config_clear(&e->config);
    g_free(e);
}

GtkWidget *gslate_editor_get_widget(GSlateEditor *e) { return e->frame; }
GtkTextView *gslate_editor_get_view(GSlateEditor *e) { return e->view; }
GtkTextBuffer *gslate_editor_get_buffer(GSlateEditor *e) { return e->buffer; }
const GSlateConfig *gslate_editor_get_config(GSlateEditor *e) { return &e->config; }
GtkWidget *gslate_editor_get_gutter(GSlateEditor *e) { return e->gutter; }

guint
gslate_editor_get_line_count(GSlateEditor *e)
{
    return (guint)gtk_text_buffer_get_line_count(e->buffer);
}

void
gslate_editor_refresh_gutter(GSlateEditor *e)
{
    if (e && e->gutter) gslate_gutter_queue_draw(e);
}

void
gslate_editor_refresh_highlight(GSlateEditor *e)
{
    GtkTextIter start, end, line_start, line_end;
    if (!e) return;
    gtk_text_buffer_get_bounds(e->buffer, &start, &end);
    gtk_text_buffer_remove_tag(e->buffer, e->current_line_tag, &start, &end);
    if (!e->config.highlight_current_line) return;
    gtk_text_buffer_get_iter_at_mark(e->buffer, &line_start, gtk_text_buffer_get_insert(e->buffer));
    line_start = line_start; gtk_text_iter_set_line_offset(&line_start, 0);
    line_end = line_start;
    gtk_text_iter_forward_to_line_end(&line_end);
    /* Include the line terminator so the paragraph background reaches its end. */
    if (!gtk_text_iter_is_end(&line_end)) gtk_text_iter_forward_char(&line_end);
    if (!gtk_text_iter_equal(&line_start, &line_end))
        gtk_text_buffer_apply_tag(e->buffer, e->current_line_tag, &line_start, &line_end);
}

void
gslate_editor_apply_config(GSlateEditor *e, const GSlateConfig *c)
{
    if (!e || !c) return;
    /* Copy fields; configuration owns its own strings. */
    e->config.wordwrap = c->wordwrap; e->config.block_cursor = c->block_cursor;
    e->config.block_cursor_blink = c->block_cursor_blink;
    e->config.show_line_numbers = c->show_line_numbers; e->config.highlight_current_line = c->highlight_current_line;
    e->config.show_statusbar = c->show_statusbar; e->config.border_size = c->border_size;
    e->config.font_size = c->font_size; e->config.pixels_above = c->pixels_above;
    e->config.pixels_below = c->pixels_below; e->config.line_distance = c->line_distance; e->config.line_height = c->line_height;
#define COPY_FIELD(f) do { g_free(e->config.f); e->config.f = g_strdup(c->f); } while (0)
    COPY_FIELD(border_color); COPY_FIELD(background_color); COPY_FIELD(gutter_background_color); COPY_FIELD(current_line_color);
    COPY_FIELD(line_number_color); COPY_FIELD(text_color); COPY_FIELD(font_family);
#undef COPY_FIELD
    if (e->view) {
        gtk_text_view_set_monospace(e->view, TRUE);
        gtk_text_view_set_wrap_mode(e->view, e->config.wordwrap ? GTK_WRAP_WORD_CHAR : GTK_WRAP_NONE);
        gtk_text_view_set_pixels_above_lines(e->view, e->config.pixels_above);
        gtk_text_view_set_pixels_below_lines(e->view, e->config.pixels_below);
        gtk_text_view_set_pixels_inside_wrap(e->view, e->config.line_distance);
        GdkRGBA highlight;
        if (gdk_rgba_parse(&highlight, e->config.current_line_color))
            g_object_set(e->current_line_tag, "paragraph-background-rgba", &highlight, NULL);
        g_object_set(e->line_height_tag, "line-height", (gfloat)e->config.line_height, NULL);
        GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
        if (!gtk_text_iter_equal(&a, &b)) gtk_text_buffer_apply_tag(e->buffer, e->line_height_tag, &a, &b);
        gtk_widget_set_visible(e->gutter, e->config.show_line_numbers);
        apply_css(e);
        gslate_editor_refresh_gutter(e);
        gslate_editor_refresh_highlight(e);
        refresh_block_cursor(e);
    }
}

void
gslate_editor_set_text(GSlateEditor *e, const gchar *text)
{
    /* A newly loaded/replaced document is a fresh undo baseline. Toggling
     * native undo off clears any history belonging to the previous document. */
    gtk_text_buffer_set_enable_undo(e->buffer, FALSE);
    gtk_text_buffer_set_text(e->buffer, text ? text : "", -1);
    GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
    if (!gtk_text_iter_equal(&a, &b)) gtk_text_buffer_apply_tag(e->buffer, e->line_height_tag, &a, &b);
    gslate_editor_refresh_highlight(e);
    gslate_editor_refresh_gutter(e);
    refresh_block_cursor(e);
    gtk_text_buffer_set_modified(e->buffer, FALSE);
    gtk_text_buffer_set_enable_undo(e->buffer, TRUE);
}

gchar *
gslate_editor_dup_text(GSlateEditor *e)
{
    GtkTextIter a, b; gtk_text_buffer_get_bounds(e->buffer, &a, &b);
    return gtk_text_buffer_get_text(e->buffer, &a, &b, TRUE);
}

void gslate_editor_copy(GSlateEditor *e) { gslate_clipboard_copy(e->view, e->buffer); }
void gslate_editor_cut(GSlateEditor *e) { gslate_clipboard_cut(e->view, e->buffer); }
void gslate_editor_paste(GSlateEditor *e) { gslate_clipboard_paste(e->view, e->buffer); }

void
gslate_editor_goto_line(GSlateEditor *e, guint n)
{
    GtkTextIter iter;
    guint count = gslate_editor_get_line_count(e);
    if (n < 1 || n > count) return;
    gtk_text_buffer_get_iter_at_line(e->buffer, &iter, (gint)n - 1);
    gtk_text_buffer_place_cursor(e->buffer, &iter);
    gtk_text_view_scroll_to_iter(e->view, &iter, 0.15, FALSE, 0, 0);
}

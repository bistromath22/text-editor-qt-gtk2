#include "clipboard.h"
#include "text_normalization.h"

typedef struct {
    GtkTextView *view;
    GtkTextBuffer *buffer;
    GtkTextMark *start;
    GtkTextMark *end;
} PasteRequest;

static GdkClipboard *get_clipboard(GtkTextView *view)
{
    GdkDisplay *display = gtk_widget_get_display(GTK_WIDGET(view));
    return gdk_display_get_clipboard(display);
}

void
gslate_clipboard_copy(GtkTextView *view, GtkTextBuffer *buffer)
{
    GtkTextIter a, b;
    if (!gtk_text_buffer_get_selection_bounds(buffer, &a, &b)) return;
    gchar *text = gtk_text_buffer_get_text(buffer, &a, &b, TRUE);
    gdk_clipboard_set_text(get_clipboard(view), text);
    g_free(text);
}

void
gslate_clipboard_cut(GtkTextView *view, GtkTextBuffer *buffer)
{
    GtkTextIter a, b;
    if (!gtk_text_buffer_get_selection_bounds(buffer, &a, &b)) return;
    gchar *text = gtk_text_buffer_get_text(buffer, &a, &b, TRUE);
    gdk_clipboard_set_text(get_clipboard(view), text);
    g_free(text);
    gtk_text_buffer_begin_user_action(buffer);
    gtk_text_buffer_delete(buffer, &a, &b);
    gtk_text_buffer_end_user_action(buffer);
}

static void paste_finished(GObject *source, GAsyncResult *result, gpointer user_data)
{
    PasteRequest *request = user_data;
    GError *error = NULL;
    gchar *clipboard_text = gdk_clipboard_read_text_finish(GDK_CLIPBOARD(source), result, &error);
    if (clipboard_text) {
        gchar *normalized = gslate_normalize_newlines(clipboard_text, -1);
        GtkTextIter start, end;
        gtk_text_buffer_get_iter_at_mark(request->buffer, &start, request->start);
        gtk_text_buffer_get_iter_at_mark(request->buffer, &end, request->end);
        gtk_text_buffer_begin_user_action(request->buffer);
        if (!gtk_text_iter_equal(&start, &end))
            gtk_text_buffer_delete(request->buffer, &start, &end);
        gtk_text_buffer_insert(request->buffer, &start, normalized, -1);
        gtk_text_buffer_place_cursor(request->buffer, &start);
        gtk_text_buffer_end_user_action(request->buffer);
        gtk_text_view_scroll_to_iter(request->view, &start, 0.15, FALSE, 0, 0);
        g_free(normalized);
        g_free(clipboard_text);
    } else if (error) {
        g_warning("Clipboard paste failed: %s", error->message);
        g_error_free(error);
    }
    gtk_text_buffer_delete_mark(request->buffer, request->start);
    gtk_text_buffer_delete_mark(request->buffer, request->end);
    g_object_unref(request->buffer);
    g_object_unref(request->view);
    g_free(request);
}

void
gslate_clipboard_paste(GtkTextView *view, GtkTextBuffer *buffer)
{
    GtkTextIter start, end;
    PasteRequest *request = g_new0(PasteRequest, 1);
    if (gtk_text_buffer_get_selection_bounds(buffer, &start, &end)) {
        request->start = gtk_text_buffer_create_mark(buffer, NULL, &start, TRUE);
        request->end = gtk_text_buffer_create_mark(buffer, NULL, &end, FALSE);
    } else {
        gtk_text_buffer_get_iter_at_mark(buffer, &start, gtk_text_buffer_get_insert(buffer));
        request->start = gtk_text_buffer_create_mark(buffer, NULL, &start, TRUE);
        request->end = gtk_text_buffer_create_mark(buffer, NULL, &start, FALSE);
    }
    request->view = g_object_ref(view);
    request->buffer = g_object_ref(buffer);
    gdk_clipboard_read_text_async(get_clipboard(view), NULL, paste_finished, request);
}

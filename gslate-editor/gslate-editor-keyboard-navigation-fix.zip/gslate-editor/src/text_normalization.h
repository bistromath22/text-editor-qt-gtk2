#ifndef GSLATE_TEXT_NORMALIZATION_H
#define GSLATE_TEXT_NORMALIZATION_H
#include <glib.h>

/* Returns newly allocated UTF-8 with CRLF and CR converted to LF. */
gchar *gslate_normalize_newlines(const gchar *text, gssize length);

#endif

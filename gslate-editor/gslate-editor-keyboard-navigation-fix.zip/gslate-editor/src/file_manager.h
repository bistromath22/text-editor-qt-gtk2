#ifndef GSLATE_FILE_MANAGER_H
#define GSLATE_FILE_MANAGER_H
#include <gio/gio.h>

gchar *gslate_file_load_text(GFile *file, GError **error);
gboolean gslate_file_save_text(GFile *file, const gchar *text, gsize length, GError **error);
#endif

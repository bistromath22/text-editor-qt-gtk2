#!/usr/bin/env bash
# Installs the build dependencies for wedit on Ubuntu 26.04 LTS (idempotent).
#
# Policy for other systems: apt is never run on non-Ubuntu distributions. The
# script exits with an error unless WEDIT_ALLOW_NON_UBUNTU=1 is set, in which
# case it only *verifies* that wx-config/STC are already usable. Other Ubuntu
# releases get a warning and the install proceeds.
set -Eeuo pipefail

die() { echo "install_deps.sh: error: $*" >&2; exit 1; }
warn() { echo "install_deps.sh: warning: $*" >&2; }
info() { echo "==> $*"; }

verify_wx() {
    command -v wx-config >/dev/null 2>&1 || die "wx-config not found after installation"
    local version
    version="$(wx-config --version)"
    info "wxWidgets version: ${version}"
    case "${version}" in
        3.2.*) ;;
        *) die "wedit needs wxWidgets 3.2.x, but wx-config reports '${version}'" ;;
    esac
    wx-config --cxxflags >/dev/null || die "'wx-config --cxxflags' failed"
    local libs
    libs="$(wx-config --libs std,stc 2>/dev/null)" || die "'wx-config --libs std,stc' failed: the STC component is missing"
    case "${libs}" in
        *stc*) ;;
        *) die "'wx-config --libs std,stc' returned no STC library flags: ${libs}" ;;
    esac
    info "STC link flags: ${libs}"
}

# --- distribution check ------------------------------------------------------
[ -r /etc/os-release ] || die "/etc/os-release not found; cannot identify the distribution"
# shellcheck disable=SC1091
. /etc/os-release
if [ "${ID:-}" != "ubuntu" ]; then
    if [ "${WEDIT_ALLOW_NON_UBUNTU:-0}" = "1" ]; then
        warn "'${PRETTY_NAME:-unknown}' is not Ubuntu; skipping apt and only verifying wxWidgets."
        verify_wx
        exit 0
    fi
    die "unsupported distribution '${PRETTY_NAME:-unknown}'. Ubuntu 26.04 is the target. Install wxWidgets 3.2.x (with STC), CMake, a C++17 compiler, zip and unzip yourself, or set WEDIT_ALLOW_NON_UBUNTU=1 to only verify."
fi
if [ "${VERSION_ID:-}" != "26.04" ]; then
    warn "this script targets Ubuntu 26.04; found ${VERSION_ID:-unknown}. Continuing."
fi

# --- privileges --------------------------------------------------------------
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        SUDO="sudo"
    else
        die "must run as root or have sudo available"
    fi
fi

export DEBIAN_FRONTEND=noninteractive

info "Updating package index"
${SUDO} apt-get update || die "apt-get update failed"

REQUIRED_PACKAGES=(build-essential cmake pkg-config libwxgtk3.2-dev zip unzip)
OPTIONAL_PACKAGES=(xvfb xauth desktop-file-utils)   # test/validation helpers only

info "Installing required packages: ${REQUIRED_PACKAGES[*]}"
if ! ${SUDO} apt-get install -y "${REQUIRED_PACKAGES[@]}"; then
    cat >&2 <<'EOF'
install_deps.sh: error: package installation failed.
  libwxgtk3.2-dev is in Ubuntu's 'universe' repository. If apt cannot locate it,
  enable universe (sudo add-apt-repository universe) and re-run this script.
EOF
    exit 1
fi

for pkg in "${OPTIONAL_PACKAGES[@]}"; do
    if apt-cache show "${pkg}" >/dev/null 2>&1; then
        ${SUDO} apt-get install -y "${pkg}" || warn "optional package ${pkg} could not be installed"
    else
        warn "optional package ${pkg} is not available; skipping"
    fi
done

info "Verifying the installation"
verify_wx

cat <<'EOF'

Dependencies are ready. Next:

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --parallel
    ctest --test-dir build --output-on-failure
    ./package.sh
EOF

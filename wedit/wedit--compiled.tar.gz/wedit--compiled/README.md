# wedit

A lightweight, keyboard-friendly, distraction-free **plain-text editor** for
Ubuntu 26.04 LTS (secondary target: Windows 10/11 64-bit).

* Language: C++17 · GUI: wxWidgets 3.2.x · Editor control: `wxStyledTextCtrl`
  (wxSTC / Scintilla) · Build: CMake · Document type: UTF-8 plain text
* One window, one document. No tabs, panes, plugins, syntax highlighting,
  toolbar, terminal or network access.

> **Verification status of this source drop.** The toolkit-free core (config,
> UTF-8, newlines, file I/O, shortcuts, editor logic, CLI parsing) is compiled
> and covered by CTest. The wxWidgets GUI sources (`MainFrame`, `EditorControl`,
> `ClipboardManager`, `main.cpp`) were written against the wxWidgets 3.2 API but
> **had not been compiled or run** when this archive was produced, because no
> wxWidgets was available in the build sandbox. Build them with the steps below
> and see "Manual GUI checklist".

## Architecture

* `wxFrame` (`MainFrame`) with a menu bar (File / Edit / View), a vertical sizer
  and one central `EditorControl` (a `wxStyledTextCtrl`).
* The Scintilla document is the only text model. The lexer is `wxSTC_LEX_NULL`,
  the code page is UTF-8, the EOL mode is LF; Scintilla is used purely for its
  line-number margin, caret line, caret style, wrapping and undo engine.
* The toolkit-free `wedit_core` static library holds everything testable
  without a display: `ConfigManager`, `ShortcutParser`, `AppActions`,
  `TextNormalization`, `Utf8Utils`, `FileIO`, `EditorLogic`, `Cli`.
* All commands (menu, accelerators) reach one `MainFrame::Dispatch`.

See `docs/DESIGN.md` for details.

## Dependencies (Ubuntu 26.04)

```
./install_deps.sh
```

installs `build-essential cmake pkg-config libwxgtk3.2-dev zip unzip` (plus the
optional helpers `xvfb xauth desktop-file-utils`) and verifies
`wx-config --version`, `--cxxflags` and `--libs std,stc`. `libwxgtk3.2-dev` is in
Ubuntu's *universe* repository. The script refuses to run apt on non-Ubuntu
systems (`WEDIT_ALLOW_NON_UBUNTU=1` makes it only verify).

## Build, test, run

```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/wedit [FILE]
```

Debug build:

```
cmake -S . -B build-debug -DCMAKE_BUILD_TYPE=Debug
cmake --build build-debug --parallel
```

Core library and tests only (no wxWidgets needed): add `-DWEDIT_BUILD_GUI=OFF`.
With the GUI enabled, configuration **fails** if wxWidgets 3.2.x core/base/stc is
missing; there is no `wxTextCtrl` fallback.

Install / uninstall:

```
cmake --install build --prefix "$HOME/.local"
xargs rm -v < build/install_manifest.txt     # uninstall
```

The installer never writes or overwrites a `config.ini`.

Source archive: `./package.sh` builds, tests and produces `wedit-source.zip`
(one top-level `wedit/` directory, no build output), then verifies it and prints
size and SHA-256. `WEDIT_CORE_ONLY=1 ./package.sh` packages from a machine
without wxWidgets and states that the GUI was not built.

## Command line

```
wedit [FILE ...]
wedit --config PATH [FILE ...]
wedit --print-config
wedit --print-config-paths
wedit --help
wedit --version
```

Text-only modes run before wxWidgets starts (no display needed).
`--config PATH` is exact: if the file is unusable wedit exits with status 2 and
never falls back to another file. With several FILEs only the first is opened;
the rest are reported on stderr. If the first file cannot be opened, wedit stays
on an empty document (no later file is substituted).
`--print-config` prints the canonical defaults (including the built-in
`toggle_block_cursor`). `--print-config-paths` lists candidates, their
exists/readable state and the active source.

## Configuration

Discovery order, first existing readable file wins:

| Linux | Windows |
|---|---|
| `--config PATH` (exact) | `--config PATH` (exact) |
| `./config.ini` | `./config.ini` |
| `$XDG_CONFIG_HOME/wedit/config.ini` or `~/.config/wedit/config.ini` | `%APPDATA%/wedit/config.ini` |
| `/etc/wedit/config.ini` | — |
| built-in defaults | built-in defaults |

`Ctrl+R` re-runs the same policy. A candidate is parsed and validated completely
before it replaces the live configuration; if it cannot be loaded the previous
settings stay active. Text, path, caret, selection, undo history and modified
state are untouched by a reload.

Parser rules: `[editor]`/`[shortcuts]` sections, `key=value`, whitespace trimmed,
full-line `#`/`;` comments (a `#` inside a value such as a colour is kept),
booleans `true/false/yes/no/1/0` (any case), strict numbers, duplicate keys →
last wins + diagnostic, unknown keys/sections → warning, invalid values → that
key's default + diagnostic (never clamped silently). Diagnostics go to stderr.

`[editor]` keys (defaults copied from the supplied `config.ini`; `config.example.ini`
lists them all):

| Key | Default | Valid |
|---|---|---|
| wordwrap | true | bool |
| border_size | 20 | 0..128 (DIP) |
| border_color, background_color, gutter_background_color, current_line_color, line_number_color, text_color | #313244, #1e1e2e, #313244, #313244, #6c7086, #cdd6f4 | `#RRGGBB` |
| block_cursor / block_cursor_blink | true / false | bool |
| font_family | Monaco | non-empty |
| font_size | 18 | 6..96 (points) |
| line_height | 1.4 | 0.5..5.0 |
| pixels_above / pixels_below / line_distance | 0 | 0..100 |
| show_line_numbers | false | bool |
| highlight_current_line | true | bool |
| show_statusbar | false | bool |

If Monaco (or any configured face) is not an installed fixed-width font, wedit
falls back to `Monospace`, then wxWidgets' teletype family, and logs requested
and resolved names on stderr.

## Keyboard shortcuts

Spelling is GTK-style (`<Primary>` = Ctrl, `<Shift>`, `<Alt>`, `F1`–`F24`,
letters, digits, `plus`, `minus`).

| Action | Default | Action | Default |
|---|---|---|---|
| New | Ctrl+N | Find Next | F3 |
| Open | Ctrl+O | Go to Line | Ctrl+G |
| Save | Ctrl+S | Reload Config | Ctrl+R |
| Save As | Ctrl+Shift+S | Toggle Word Wrap | Ctrl+W |
| Quit | Ctrl+Q | Increase / Decrease Font | Ctrl+Plus / Ctrl+Minus |
| Undo / Redo | Ctrl+Z / Ctrl+Y | Full Screen | F11 |
| Cut / Copy / Paste | Ctrl+X / C / V | Toggle Line Numbers | Ctrl+L |
| Find | Ctrl+F | Toggle Current-Line | Ctrl+H |
| Toggle Block Cursor (built-in extra) | Ctrl+B | Toggle Status Bar | Ctrl+Shift+B |

Invalid spellings keep the default. Duplicate bindings: the first action in the
table keeps the key; a later one falls back to its own default if free,
otherwise stays unbound (still reachable from the menu); all of it is logged.
Ctrl+Plus is accepted as `Ctrl+'+'`, `Ctrl+Shift+'+'`, `Ctrl+'='` and
`Ctrl+Numpad +`; Ctrl+Minus as `Ctrl+'-'` and `Ctrl+Numpad -`. Scintilla's own
bindings for the edit keys and for every configured shortcut are released so
each key has exactly one path (the frame's command dispatcher).

## Files, encoding and newlines

* Files are read as bytes, one leading UTF-8 BOM is stripped (and never
  written back), invalid UTF-8 and embedded NUL are rejected with a message and
  the current document is left untouched.
* CRLF → LF, remaining CR → LF; leading, repeated and trailing newlines are
  preserved; nothing is appended on save. Saved files are UTF-8 with LF.
* Save writes a temp file in the destination directory, fsyncs, and atomically
  replaces the target (POSIX `rename`, Windows `MoveFileExW`). POSIX mode bits of
  an existing file are preserved; ownership/ACLs/xattrs are not.
* The status bar column is a 1-based **Unicode code-point** column (combining
  marks count separately), not a byte offset.

## Clipboard and undo

Copy/Cut/Paste use plain text only. Cut removes the selection only after the
clipboard accepted it. Paste normalises newlines and is one undo step. Undo
history is Scintilla's own; loading a document clears it; Save sets the save
point; appearance changes never touch it.

## Known wxWidgets / Scintilla limitations

* `line_height` is a global approximation using extra ascent/descent computed
  from the natural line height each time (values < 1.0 use the natural height).
* `pixels_above`, `pixels_below` and `line_distance` cannot be honoured
  per-paragraph / per-subline; non-zero values are preserved, reported on
  stderr and not applied.
* Case-insensitive Find folds ASCII only.
* The block caret is Scintilla's filled block, drawn by Scintilla.
* The window-manager title bar is not recoloured; `border_color` colours wedit's
  own surround.
* On Linux, file names are converted through UTF-8; locales that use a different
  file-name encoding are not specially handled.

## Windows notes

Use a wxWidgets 3.2.x build for x64 that includes `stc`, then
`cmake -S . -B build -A x64 -DwxWidgets_ROOT_DIR=<wx> -DwxWidgets_LIB_DIR=<wx>/lib/vc_x64_lib`
and `cmake --build build --config Release`. The Windows file-replacement and path
code is written but **has not been compiled or run**.

## Manual GUI checklist

Not automated: 900×600 / minimum size / maximized / full screen / resize / HiDPI;
border 0 and 20 and custom colour; gutter, status bar and wrap on/off; small and
large fonts; long documents and long unwrapped lines; large multi-line paste;
all shortcuts with the editor focused (no double dispatch); caret, selection and
emoji/combining marks not clipped by line spacing; no bottom strip when the
status bar is hidden.

## Troubleshooting

* *CMake: wxWidgets not found* — run `./install_deps.sh`; check `wx-config --libs std,stc`.
* *A font looks wrong* — see stderr for requested vs resolved font family.
* *A shortcut does nothing* — see stderr for shortcut diagnostics; run
  `wedit --print-config-paths` to see which config is active.

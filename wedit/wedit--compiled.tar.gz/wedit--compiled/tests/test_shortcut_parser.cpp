#include <map>
#include <string>

#include "AppActions.h"
#include "ShortcutParser.h"
#include "TestHarness.h"

using namespace wedit;

WTEST(every_supplied_spelling_parses_and_labels) {
    struct Row { const char* spelling; const char* label; };
    const Row rows[] = {
        {"<Primary>n", "Ctrl+N"}, {"<Primary>o", "Ctrl+O"}, {"<Primary>s", "Ctrl+S"},
        {"<Primary><Shift>s", "Ctrl+Shift+S"}, {"<Primary>q", "Ctrl+Q"},
        {"<Primary>z", "Ctrl+Z"}, {"<Primary>y", "Ctrl+Y"}, {"<Primary>x", "Ctrl+X"},
        {"<Primary>c", "Ctrl+C"}, {"<Primary>v", "Ctrl+V"}, {"<Primary>f", "Ctrl+F"},
        {"F3", "F3"}, {"<Primary>g", "Ctrl+G"}, {"<Primary>r", "Ctrl+R"},
        {"<Primary>w", "Ctrl+W"}, {"<Primary>plus", "Ctrl++"}, {"<Primary>minus", "Ctrl+-"},
        {"F11", "F11"}, {"<Primary>l", "Ctrl+L"}, {"<Primary>h", "Ctrl+H"},
        {"<Primary><Shift>b", "Ctrl+Shift+B"}, {"<Primary>b", "Ctrl+B"},
    };
    for (const auto& r : rows) {
        const auto p = parseShortcut(r.spelling);
        CHECK(p.ok);
        CHECK_EQ(p.shortcut.label(), std::string(r.label));
        CHECK(p.shortcut.ctrl == (std::string(r.spelling).find("<Primary>") != std::string::npos));
    }
}
WTEST(modifier_flags_and_kinds) {
    const auto a = parseShortcut("<Primary><Shift>s").shortcut;
    CHECK(a.ctrl && a.shift && !a.alt);
    CHECK(a.kind == KeyKind::Char);
    CHECK_EQ(a.value, static_cast<int>('S'));
    CHECK(parseShortcut("F11").shortcut.kind == KeyKind::Function);
    CHECK_EQ(parseShortcut("F11").shortcut.value, 11);
    CHECK(parseShortcut("<Primary>plus").shortcut.kind == KeyKind::Plus);
    CHECK(parseShortcut("<Primary>minus").shortcut.kind == KeyKind::Minus);
    CHECK(parseShortcut("<Primary>plus").shortcut.isPlusOrMinus());
    CHECK(parseShortcut("<Alt>x").shortcut.alt);
    CHECK(parseShortcut("<Control>X").shortcut.ctrl);
    CHECK(parseShortcut("F24").ok);
}
WTEST(invalid_spellings_rejected) {
    CHECK(!parseShortcut("").ok);
    CHECK(!parseShortcut("<Primary>").ok);
    CHECK(!parseShortcut("<Primary").ok);
    CHECK(!parseShortcut("<Hyper>x").ok);
    CHECK(!parseShortcut("<Primary>nn").ok);
    CHECK(!parseShortcut("F25").ok);
    CHECK(!parseShortcut("F0").ok);
    CHECK(!parseShortcut("<Primary>!").ok);
    CHECK(!parseShortcut("Fx").ok);
}
WTEST(action_registry_matches_supplied_config_and_extra) {
    const auto& all = allActions();
    CHECK_EQ(all.size(), static_cast<size_t>(22));
    int supplied = 0;
    for (const auto& a : all) {
        if (a.inSuppliedConfig) ++supplied;
        CHECK(parseShortcut(a.defaultShortcut).ok);
    }
    CHECK_EQ(supplied, 21);
    CHECK_EQ(std::string(all.back().configName), std::string("toggle_block_cursor"));
    CHECK_EQ(std::string(all.back().defaultShortcut), std::string("<Primary>b"));
    CHECK(findActionByConfigName("goto_line") != nullptr);
    CHECK(findActionByConfigName("nope") == nullptr);
    for (size_t i = 0; i < all.size(); ++i) CHECK_EQ(actionIndex(all[i].action), static_cast<int>(i));
}
WTEST(defaults_resolve_without_diagnostics_and_unique) {
    const ResolvedShortcuts r = resolveShortcuts({});
    CHECK(r.diagnostics.empty());
    CHECK_EQ(r.bindings.size(), static_cast<size_t>(22));
    CHECK_EQ(r.find(Action::Save)->label(), std::string("Ctrl+S"));
    CHECK_EQ(r.find(Action::ToggleBlockCursor)->label(), std::string("Ctrl+B"));
    CHECK_EQ(r.find(Action::ToggleStatusBar)->label(), std::string("Ctrl+Shift+B"));
}
WTEST(invalid_config_shortcut_keeps_default) {
    const ResolvedShortcuts r = resolveShortcuts({{"save", "<Primary>!!"}});
    CHECK(!r.diagnostics.empty());
    CHECK_EQ(r.find(Action::Save)->label(), std::string("Ctrl+S"));
}
WTEST(override_changes_binding_and_label) {
    const ResolvedShortcuts r = resolveShortcuts({{"save", "<Primary><Shift>k"}});
    CHECK(r.diagnostics.empty());
    CHECK_EQ(r.find(Action::Save)->label(), std::string("Ctrl+Shift+K"));
}
WTEST(duplicate_binding_is_deterministic_and_reported) {
    // find (table order 10) takes Ctrl+S that save (order 2) already owns.
    const ResolvedShortcuts r = resolveShortcuts({{"find", "<Primary>s"}});
    CHECK(!r.diagnostics.empty());
    CHECK_EQ(r.find(Action::Save)->label(), std::string("Ctrl+S"));
    // Later action falls back to its own free default (Ctrl+F).
    CHECK(r.find(Action::Find) != nullptr);
    CHECK_EQ(r.find(Action::Find)->label(), std::string("Ctrl+F"));
    const ResolvedShortcuts r2 = resolveShortcuts({{"find", "<Primary>s"}});
    CHECK(r.diagnostics == r2.diagnostics);  // deterministic
}
WTEST(duplicate_with_taken_default_leaves_action_unbound) {
    // save -> Ctrl+O (open's default is also Ctrl+O and comes earlier? open is order 1, save 2)
    // open keeps Ctrl+O; save wants Ctrl+O; save's default Ctrl+S is free -> falls back.
    const ResolvedShortcuts a = resolveShortcuts({{"save", "<Primary>o"}});
    CHECK_EQ(a.find(Action::Save)->label(), std::string("Ctrl+S"));
    // Now also steal Ctrl+S for open's neighbour so the fallback is taken as well.
    const ResolvedShortcuts b = resolveShortcuts({{"open", "<Primary>s"}, {"save", "<Primary>s"}});
    CHECK_EQ(b.find(Action::Open)->label(), std::string("Ctrl+S"));
    CHECK(b.find(Action::Save) == nullptr);  // unbound, still reachable from the menu
}
WTEST(labels_derive_from_parsed_representation) {
    const auto p = parseShortcut("<Shift><Primary>a");  // modifier order irrelevant
    CHECK_EQ(p.shortcut.label(), std::string("Ctrl+Shift+A"));
}

TEST_MAIN()

#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>

#include "AppActions.h"
#include "Cli.h"
#include "ConfigManager.h"
#include "TestHarness.h"

namespace fs = std::filesystem;
using namespace wedit;

namespace {

// Verbatim copy of the user's supplied config.ini.
const char* kSupplied =
    "[editor]\nwordwrap=true\nborder_size=20\nborder_color=#313244\n"
    "background_color=#1e1e2e\ngutter_background_color=#313244\n"
    "current_line_color=#313244\nline_number_color=#6c7086\ntext_color=#cdd6f4\n"
    "block_cursor=true\nblock_cursor_blink=false\nfont_family=Monaco\nfont_size=18\n"
    "line_height=1.4\npixels_above=0\npixels_below=0\nline_distance=0\n"
    "show_line_numbers=false\nhighlight_current_line=true\nshow_statusbar=false\n\n"
    "[shortcuts]\nnew_file=<Primary>n\nopen=<Primary>o\nsave=<Primary>s\n"
    "save_as=<Primary><Shift>s\nquit=<Primary>q\nundo=<Primary>z\nredo=<Primary>y\n"
    "cut=<Primary>x\ncopy=<Primary>c\npaste=<Primary>v\nfind=<Primary>f\nfind_next=F3\n"
    "goto_line=<Primary>g\nreload_config=<Primary>r\ntoggle_wordwrap=<Primary>w\n"
    "increase_font=<Primary>plus\ndecrease_font=<Primary>minus\nfullscreen=F11\n"
    "toggle_line_numbers=<Primary>l\ntoggle_current_line=<Primary>h\n"
    "toggle_statusbar=<Primary><Shift>b\n";

struct TempDir {
    fs::path path;
    TempDir() {
        path = fs::temp_directory_path() /
               ("wedit-test-" + std::to_string(reinterpret_cast<uintptr_t>(this)) + "-" +
                std::to_string(std::rand()));
        fs::create_directories(path);
    }
    ~TempDir() {
        std::error_code ec;
        fs::remove_all(path, ec);
    }
    std::string file(const std::string& name) const { return (path / name).string(); }
};

void writeText(const std::string& p, const std::string& s) {
    std::ofstream(p, std::ios::binary) << s;
}

bool hasDiag(const ParseResult& r, const std::string& needle) {
    for (const auto& d : r.diagnostics)
        if (d.find(needle) != std::string::npos) return true;
    return false;
}

}  // namespace

WTEST(exact_supplied_defaults) {
    const Config c = makeDefaults();
    CHECK(c.wordwrap);
    CHECK_EQ(c.border_size, 20);
    CHECK_EQ(c.border_color, std::string("#313244"));
    CHECK_EQ(c.background_color, std::string("#1e1e2e"));
    CHECK_EQ(c.gutter_background_color, std::string("#313244"));
    CHECK_EQ(c.current_line_color, std::string("#313244"));
    CHECK_EQ(c.line_number_color, std::string("#6c7086"));
    CHECK_EQ(c.text_color, std::string("#cdd6f4"));
    CHECK(c.block_cursor);
    CHECK(!c.block_cursor_blink);
    CHECK_EQ(c.font_family, std::string("Monaco"));
    CHECK_EQ(c.font_size, 18);
    CHECK_EQ(c.line_height, 1.4);
    CHECK_EQ(c.pixels_above, 0.0);
    CHECK_EQ(c.pixels_below, 0.0);
    CHECK_EQ(c.line_distance, 0.0);
    CHECK(!c.show_line_numbers);
    CHECK(c.highlight_current_line);
    CHECK(!c.show_statusbar);
    CHECK_EQ(c.shortcuts.at("save_as"), std::string("<Primary><Shift>s"));
    CHECK_EQ(c.shortcuts.at("increase_font"), std::string("<Primary>plus"));
    CHECK_EQ(c.shortcuts.at("find_next"), std::string("F3"));
    CHECK_EQ(c.shortcuts.at("toggle_block_cursor"), std::string("<Primary>b"));
    CHECK_EQ(c.shortcuts.size(), static_cast<size_t>(22));
}

WTEST(supplied_file_parses_to_defaults_without_diagnostics) {
    const ParseResult r = parseConfigText(kSupplied);
    CHECK(r.diagnostics.empty());
    CHECK(r.config == makeDefaults());  // built-in toggle_block_cursor is inherited
}

WTEST(example_ini_matches_defaults) {
    std::ifstream f(std::string(WEDIT_SOURCE_DIR) + "/config.example.ini");
    CHECK(f.good());
    std::stringstream ss;
    ss << f.rdbuf();
    const ParseResult r = parseConfigText(ss.str());
    CHECK(r.diagnostics.empty());
    CHECK(r.config == makeDefaults());
    // Every canonical key is physically present in the example file.
    for (const auto& a : allActions()) {
        CHECK(ss.str().find(std::string(a.configName) + "=") != std::string::npos);
    }
}

WTEST(serialize_roundtrip_equals_defaults) {
    const std::string text = serializeConfig(makeDefaults());
    const ParseResult r = parseConfigText(text);
    CHECK(r.diagnostics.empty());
    CHECK(r.config == makeDefaults());
    CHECK(text.find("line_height=1.4\n") != std::string::npos);
    CHECK(text.find("toggle_block_cursor=<Primary>b\n") != std::string::npos);
    CHECK(text.find("border_color=#313244\n") != std::string::npos);
}

WTEST(partial_and_empty_config_inherit_defaults) {
    const ParseResult r = parseConfigText("[editor]\nfont_size=24\n");
    CHECK(r.diagnostics.empty());
    Config expect = makeDefaults();
    expect.font_size = 24;
    CHECK(r.config == expect);
    CHECK(parseConfigText("").config == makeDefaults());
    CHECK(parseConfigText("\n\n   \n").config == makeDefaults());
}

WTEST(whitespace_comments_and_hash_colours) {
    const ParseResult r = parseConfigText(
        "# comment\n; also comment\n[ editor ]\n  text_color =  #ABCDEF  \r\n"
        "   # indented comment\nfont_size\t=\t20\n");
    CHECK(r.diagnostics.empty());
    CHECK_EQ(r.config.text_color, std::string("#ABCDEF"));
    CHECK_EQ(r.config.font_size, 20);
}

WTEST(boolean_variants) {
    const ParseResult r = parseConfigText(
        "[editor]\nwordwrap=FALSE\nblock_cursor=No\nblock_cursor_blink=YES\n"
        "show_statusbar=1\nshow_line_numbers=True\nhighlight_current_line=0\n");
    CHECK(r.diagnostics.empty());
    CHECK(!r.config.wordwrap);
    CHECK(!r.config.block_cursor);
    CHECK(r.config.block_cursor_blink);
    CHECK(r.config.show_statusbar);
    CHECK(r.config.show_line_numbers);
    CHECK(!r.config.highlight_current_line);
}

WTEST(invalid_values_fall_back_with_diagnostics) {
    const ParseResult r = parseConfigText(
        "[editor]\nborder_size=999\nfont_size=5\nfont_size_extra=1\nborder_color=red\n"
        "text_color=#12345\nfont_family=\nwordwrap=maybe\nline_height=0.1\n");
    const Config d = makeDefaults();
    CHECK_EQ(r.config.border_size, d.border_size);
    CHECK_EQ(r.config.font_size, d.font_size);
    CHECK_EQ(r.config.border_color, d.border_color);
    CHECK_EQ(r.config.text_color, d.text_color);
    CHECK_EQ(r.config.font_family, d.font_family);
    CHECK_EQ(r.config.wordwrap, d.wordwrap);
    CHECK_EQ(r.config.line_height, d.line_height);
    CHECK(hasDiag(r, "border_size"));
    CHECK(hasDiag(r, "font_size"));
    CHECK(hasDiag(r, "unknown key 'font_size_extra'"));
    CHECK(hasDiag(r, "border_color"));
    CHECK(hasDiag(r, "text_color"));
    CHECK(hasDiag(r, "font_family"));
    CHECK(hasDiag(r, "wordwrap"));
    CHECK(hasDiag(r, "line_height"));
}

WTEST(numeric_edge_cases) {
    const char* bad[] = {"nan", "inf", "-inf", "1e999", "1.4x", "1,4", "0x10", "", " ", "--1", "1e", "."};
    for (const char* v : bad) {
        const ParseResult r = parseConfigText(std::string("[editor]\nline_height=") + v + "\n");
        CHECK_EQ(r.config.line_height, 1.4);
        CHECK(!r.diagnostics.empty());
    }
    const char* badInt[] = {"18.5", "1e1", "99999999999999999999", "18pt", "", "abc"};
    for (const char* v : badInt) {
        const ParseResult r = parseConfigText(std::string("[editor]\nfont_size=") + v + "\n");
        CHECK_EQ(r.config.font_size, 18);
        CHECK(!r.diagnostics.empty());
    }
    // Boundaries are inclusive.
    CHECK_EQ(parseConfigText("[editor]\nfont_size=6\n").config.font_size, 6);
    CHECK_EQ(parseConfigText("[editor]\nfont_size=96\n").config.font_size, 96);
    CHECK_EQ(parseConfigText("[editor]\nborder_size=0\n").config.border_size, 0);
    CHECK_EQ(parseConfigText("[editor]\nborder_size=128\n").config.border_size, 128);
    CHECK_EQ(parseConfigText("[editor]\nline_height=0.5\n").config.line_height, 0.5);
    CHECK_EQ(parseConfigText("[editor]\nline_height=5\n").config.line_height, 5.0);
    CHECK_EQ(parseConfigText("[editor]\npixels_above=100\n").config.pixels_above, 100.0);
    CHECK(!parseConfigText("[editor]\npixels_below=100.5\n").diagnostics.empty());
    CHECK(!parseConfigText("[editor]\nline_distance=-1\n").diagnostics.empty());
}

WTEST(malformed_lines_sections_duplicates_unknowns) {
    const ParseResult r = parseConfigText(
        "[editor]\nthis line has no equals\n=novalue\nfont_size=20\nfont_size=22\n"
        "[bogus]\nfoo=bar\n[editor\nwordwrap=false\n[shortcuts]\nsave=<Primary>!\n"
        "nonsense=<Primary>q\nstray_after=1\n");
    CHECK_EQ(r.config.font_size, 22);  // last occurrence wins
    CHECK(hasDiag(r, "malformed line"));
    CHECK(hasDiag(r, "duplicate key 'font_size'"));
    CHECK(hasDiag(r, "unknown section [bogus]"));
    CHECK(hasDiag(r, "malformed section header"));
    CHECK(r.config.wordwrap);  // key under the malformed header was ignored
    CHECK(hasDiag(r, "invalid shortcut for 'save'"));
    CHECK_EQ(r.config.shortcuts.at("save"), std::string("<Primary>s"));
    CHECK(hasDiag(r, "unknown key 'nonsense'"));
    CHECK(hasDiag(r, "line 3"));  // line numbers are reported
}

WTEST(key_outside_section_is_reported) {
    const ParseResult r = parseConfigText("font_size=30\n[editor]\n");
    CHECK(hasDiag(r, "outside any section"));
    CHECK_EQ(r.config.font_size, 18);
}

WTEST(shortcut_override_is_applied) {
    const ParseResult r = parseConfigText("[shortcuts]\ntoggle_block_cursor=<Primary><Shift>k\n");
    CHECK(r.diagnostics.empty());
    CHECK_EQ(r.config.shortcuts.at("toggle_block_cursor"), std::string("<Primary><Shift>k"));
}

WTEST(candidate_order_linux_and_windows) {
    Env e;
    e.cwd = "/work";
    e.home = "/home/u";
    auto p = candidatePaths(e, false);
    CHECK_EQ(p.size(), static_cast<size_t>(3));
    CHECK_EQ(p[0], std::string("/work/config.ini"));
    CHECK_EQ(p[1], std::string("/home/u/.config/wedit/config.ini"));
    CHECK_EQ(p[2], std::string("/etc/wedit/config.ini"));
    e.xdgConfigHome = "/xdg";
    p = candidatePaths(e, false);
    CHECK_EQ(p[1], std::string("/xdg/wedit/config.ini"));
    Env w;
    w.cwd = "C:/work";
    w.appData = "C:/Users/u/AppData/Roaming";
    p = candidatePaths(w, true);
    CHECK_EQ(p.size(), static_cast<size_t>(2));
    CHECK_EQ(p[0], std::string("C:/work/config.ini"));
    CHECK_EQ(p[1], std::string("C:/Users/u/AppData/Roaming/wedit/config.ini"));
}

WTEST(discovery_precedence_and_active_source) {
    TempDir cwd, xdg;
    fs::create_directories(xdg.path / "wedit");
    Env e;
    e.cwd = cwd.path.string();
    e.xdgConfigHome = xdg.path.string();

    // Nothing present: built-in defaults.
    LoadResult none = loadConfig(std::nullopt, e, false);
    CHECK(none.ok);
    CHECK(none.usingDefaults);
    CHECK(none.config == makeDefaults());

    // XDG file only.
    writeText((xdg.path / "wedit" / "config.ini").string(), "[editor]\nfont_size=21\n");
    LoadResult viaXdg = loadConfig(std::nullopt, e, false);
    CHECK(viaXdg.ok && !viaXdg.usingDefaults);
    CHECK_EQ(viaXdg.config.font_size, 21);

    // ./config.ini beats XDG.
    writeText((cwd.path / "config.ini").string(), "[editor]\nfont_size=22\n");
    LoadResult viaCwd = loadConfig(std::nullopt, e, false);
    CHECK_EQ(viaCwd.config.font_size, 22);
    CHECK_EQ(viaCwd.sourcePath, (cwd.path / "config.ini").string());

    // Explicit path beats both and is exact.
    TempDir other;
    writeText(other.file("my.ini"), "[editor]\nfont_size=30\n");
    LoadResult viaExplicit = loadConfig(other.file("my.ini"), e, false);
    CHECK(viaExplicit.ok);
    CHECK_EQ(viaExplicit.config.font_size, 30);

    const std::string report = describeConfigSources(other.file("my.ini"), e, false);
    CHECK(report.find("1. --config") != std::string::npos);
    CHECK(report.find("Active source: " + other.file("my.ini")) != std::string::npos);
    CHECK(report.find("built-in canonical defaults") != std::string::npos);
    const std::string report2 = describeConfigSources(std::nullopt, e, false);
    CHECK(report2.find("[exists, readable]") != std::string::npos);
    CHECK(report2.find("[missing, not readable]") != std::string::npos);
}

WTEST(explicit_missing_path_fails_without_fallback) {
    TempDir cwd;
    writeText((cwd.path / "config.ini").string(), "[editor]\nfont_size=22\n");
    Env e;
    e.cwd = cwd.path.string();
    LoadResult r = loadConfig((cwd.path / "nope.ini").string(), e, false);
    CHECK(!r.ok);
    CHECK(!r.error.empty());
    // A directory is not a usable config either.
    CHECK(!loadConfig(cwd.path.string(), e, false).ok);
}

WTEST(reload_is_atomic_and_failure_keeps_live_config) {
    TempDir d;
    const std::string path = d.file("c.ini");
    writeText(path, "[editor]\nfont_size=24\nwordwrap=false\n");
    Env e;
    e.cwd = d.path.string();
    ConfigManager mgr(path, e, false);
    CHECK(mgr.live() == makeDefaults());  // nothing loaded yet

    std::vector<std::string> diags;
    std::string err;
    CHECK(mgr.reload(&diags, &err));
    CHECK_EQ(mgr.live().font_size, 24);
    CHECK(!mgr.live().wordwrap);
    CHECK_EQ(mgr.activeSource(), path);
    const Config before = mgr.live();

    fs::remove(path);  // explicit file vanished: reload must fail, live untouched
    CHECK(!mgr.reload(&diags, &err));
    CHECK(!err.empty());
    CHECK(mgr.live() == before);
    CHECK_EQ(mgr.activeSource(), path);

    // Invalid value inside a readable file: applied with defaults for that key.
    writeText(path, "[editor]\nfont_size=2000\nwordwrap=true\n");
    CHECK(mgr.reload(&diags, &err));
    CHECK_EQ(mgr.live().font_size, 18);
    CHECK(!diags.empty());
}

WTEST(cli_parsing) {
    CliOptions o = parseCli({});
    CHECK(o.action == CliAction::Run && o.files.empty() && o.warnings.empty());

    o = parseCli({"a.txt"});
    CHECK(o.action == CliAction::Run);
    CHECK_EQ(o.files.size(), static_cast<size_t>(1));

    o = parseCli({"--config", "x.ini", "a.txt", "b.txt"});
    CHECK(o.configPath && *o.configPath == "x.ini");
    CHECK_EQ(o.files.size(), static_cast<size_t>(2));
    CHECK_EQ(o.warnings.size(), static_cast<size_t>(1));  // extra file reported, not silent

    o = parseCli({"--config=y.ini"});
    CHECK(o.configPath && *o.configPath == "y.ini");

    CHECK(parseCli({"--help"}).action == CliAction::Help);
    CHECK(parseCli({"--version"}).action == CliAction::Version);
    CHECK(parseCli({"--print-config"}).action == CliAction::PrintConfig);
    CHECK(parseCli({"--print-config-paths"}).action == CliAction::PrintConfigPaths);
    CHECK(parseCli({"--config"}).action == CliAction::Error);
    CHECK(parseCli({"--bogus"}).action == CliAction::Error);
    o = parseCli({"--", "--weird-name.txt"});
    CHECK(o.action == CliAction::Run);
    CHECK_EQ(o.files[0], std::string("--weird-name.txt"));

    CHECK(helpText().find("--print-config-paths") != std::string::npos);
    CHECK(versionText("3.2.9").find("wxWidgets 3.2.9") != std::string::npos);
    CHECK(versionText("").find("wedit ") == 0);
}

TEST_MAIN()

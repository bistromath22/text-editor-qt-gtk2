// Tiny dependency-free test harness.
#pragma once

#include <cstdio>
#include <functional>
#include <sstream>
#include <string>
#include <vector>

namespace wtest {

struct Case {
    const char* name;
    std::function<void()> fn;
};

inline std::vector<Case>& cases() {
    static std::vector<Case> c;
    return c;
}
inline int& failures() {
    static int f = 0;
    return f;
}
inline int& checks() {
    static int c = 0;
    return c;
}
struct Registrar {
    Registrar(const char* n, std::function<void()> f) { cases().push_back({n, std::move(f)}); }
};

template <class T>
std::string show(const T& v) {
    std::ostringstream os;
    os << v;
    return os.str();
}
inline std::string show(bool v) { return v ? "true" : "false"; }

inline int runAll() {
    for (auto& c : cases()) {
        const int before = failures();
        c.fn();
        std::printf("[%s] %s\n", failures() == before ? " OK " : "FAIL", c.name);
    }
    std::printf("%d checks, %d failure(s)\n", checks(), failures());
    return failures() == 0 ? 0 : 1;
}

}  // namespace wtest

#define WTEST(name)                                                      \
    static void name();                                                  \
    static wtest::Registrar registrar_##name(#name, name);               \
    static void name()

#define CHECK(cond)                                                              \
    do {                                                                         \
        ++wtest::checks();                                                       \
        if (!(cond)) {                                                           \
            ++wtest::failures();                                                 \
            std::printf("  CHECK failed %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        }                                                                        \
    } while (0)

#define CHECK_EQ(a, b)                                                                 \
    do {                                                                               \
        ++wtest::checks();                                                             \
        const auto va = (a);                                                           \
        const auto vb = (b);                                                           \
        if (!(va == vb)) {                                                             \
            ++wtest::failures();                                                       \
            std::printf("  CHECK_EQ failed %s:%d: %s == %s (got '%s' vs '%s')\n",      \
                        __FILE__, __LINE__, #a, #b, wtest::show(va).c_str(),           \
                        wtest::show(vb).c_str());                                      \
        }                                                                              \
    } while (0)

#define TEST_MAIN() \
    int main() { return wtest::runAll(); }

#include <string>

#include "TestHarness.h"
#include "Utf8Utils.h"

using namespace wedit;

WTEST(valid_ascii) { CHECK(isValidUtf8("plain ASCII 123")); }
WTEST(valid_multibyte) {
    CHECK(isValidUtf8("caf\xC3\xA9"));                              // accented Latin
    CHECK(isValidUtf8("\xE6\x97\xA5\xE6\x9C\xAC\xE8\xAA\x9E"));     // CJK
    CHECK(isValidUtf8("\xE0\xA4\xA8\xE0\xA4\xAE\xE0\xA4\xB8"));     // Devanagari
}
WTEST(valid_combining_and_emoji) {
    CHECK(isValidUtf8("e\xCC\x81"));                                // e + combining acute
    CHECK(isValidUtf8("\xF0\x9F\x98\x80"));                         // U+1F600
    CHECK(isValidUtf8("\xE2\x9D\xA4\xEF\xB8\x8F"));                 // heart + VS16
}
WTEST(bom_stripped_only_at_start) {
    const std::string withBom = "\xEF\xBB\xBF" "abc";
    CHECK(hasUtf8Bom(withBom));
    CHECK_EQ(std::string(stripUtf8Bom(withBom)), std::string("abc"));
    const std::string inner = "abc\xEF\xBB\xBF";
    CHECK(!hasUtf8Bom(inner));
    CHECK_EQ(std::string(stripUtf8Bom(inner)), inner);
    // Only one BOM is removed.
    const std::string two = "\xEF\xBB\xBF\xEF\xBB\xBF" "x";
    CHECK_EQ(std::string(stripUtf8Bom(two)), std::string("\xEF\xBB\xBF" "x"));
}
WTEST(invalid_continuation_bytes) {
    size_t bad = 99;
    CHECK(!isValidUtf8("ab\x80" "c", &bad));
    CHECK_EQ(bad, static_cast<size_t>(2));
    CHECK(!isValidUtf8("\xC3\x28"));       // bad second byte
    CHECK(!isValidUtf8("\xE2\x82\x28"));   // bad third byte
}
WTEST(truncated_sequences) {
    CHECK(!isValidUtf8("\xC3"));
    CHECK(!isValidUtf8("ok\xE2\x82"));
    CHECK(!isValidUtf8("\xF0\x9F\x98"));
}
WTEST(overlong_and_invalid_encodings) {
    CHECK(!isValidUtf8("\xC0\xAF"));            // overlong '/'
    CHECK(!isValidUtf8("\xC1\xBF"));
    CHECK(!isValidUtf8("\xE0\x80\xAF"));        // overlong 3-byte
    CHECK(!isValidUtf8("\xF0\x80\x80\xAF"));    // overlong 4-byte
    CHECK(!isValidUtf8("\xED\xA0\x80"));        // surrogate U+D800
    CHECK(!isValidUtf8("\xF4\x90\x80\x80"));    // > U+10FFFF
    CHECK(!isValidUtf8("\xF5\x80\x80\x80"));
    CHECK(!isValidUtf8("\xFF"));
    CHECK(isValidUtf8("\xF4\x8F\xBF\xBF"));     // U+10FFFF is fine
}
WTEST(nul_policy) {
    CHECK(containsNul(std::string("a\0b", 3)));
    CHECK(!containsNul("abc"));
}
WTEST(column_count_vs_byte_length) {
    const std::string s = "\xE6\x97\xA5\xE6\x9C\xAC" "ab";  // 2 CJK + 2 ASCII = 4 cps, 8 bytes
    CHECK_EQ(s.size(), static_cast<size_t>(8));
    CHECK_EQ(countCodePoints(s), static_cast<size_t>(4));
    // Combining marks count as separate code points (documented policy).
    CHECK_EQ(countCodePoints("e\xCC\x81"), static_cast<size_t>(2));
    CHECK_EQ(countCodePoints("\xF0\x9F\x98\x80"), static_cast<size_t>(1));
    CHECK_EQ(countCodePoints(""), static_cast<size_t>(0));
}
WTEST(positions_never_split_code_points) {
    const std::string s = "a\xE6\x97\xA5" "b";  // a, U+65E5 (3 bytes), b -> bytes: 0 | 1 2 3 | 4
    CHECK(isCodePointBoundary(s, 0));
    CHECK(isCodePointBoundary(s, 1));
    CHECK(!isCodePointBoundary(s, 2));
    CHECK(!isCodePointBoundary(s, 3));
    CHECK(isCodePointBoundary(s, 4));
    CHECK(isCodePointBoundary(s, 5));
    CHECK(!isCodePointBoundary(s, 6));
    CHECK_EQ(floorToBoundary(s, 3), static_cast<size_t>(1));
    CHECK_EQ(ceilToBoundary(s, 2), static_cast<size_t>(4));
    CHECK_EQ(floorToBoundary(s, 99), s.size());
    CHECK_EQ(byteOffsetOfCodePoint(s, 0), static_cast<size_t>(0));
    CHECK_EQ(byteOffsetOfCodePoint(s, 2), static_cast<size_t>(4));
    CHECK_EQ(byteOffsetOfCodePoint(s, 99), s.size());
    for (size_t n = 0; n <= countCodePoints(s); ++n) {
        CHECK(isCodePointBoundary(s, byteOffsetOfCodePoint(s, n)));
    }
}

TEST_MAIN()

#include <string>

#include "TestHarness.h"
#include "TextNormalization.h"

using wedit::normalizeNewlines;

WTEST(lf_unchanged) { CHECK_EQ(normalizeNewlines("a\nb\n"), std::string("a\nb\n")); }
WTEST(crlf_becomes_one_lf) { CHECK_EQ(normalizeNewlines("a\r\nb"), std::string("a\nb")); }
WTEST(cr_becomes_lf) { CHECK_EQ(normalizeNewlines("a\rb"), std::string("a\nb")); }
WTEST(mixed_endings) {
    CHECK_EQ(normalizeNewlines("1\r\n2\r3\n4\r\r\n5"), std::string("1\n2\n3\n4\n\n5"));
}
WTEST(cr_cr_lf_is_two_newlines) { CHECK_EQ(normalizeNewlines("\r\r\n"), std::string("\n\n")); }
WTEST(leading_newline_preserved) {
    CHECK_EQ(normalizeNewlines("\nabc"), std::string("\nabc"));
    CHECK_EQ(normalizeNewlines("\r\nabc"), std::string("\nabc"));
}
WTEST(trailing_newline_preserved) {
    CHECK_EQ(normalizeNewlines("abc\n"), std::string("abc\n"));
    CHECK_EQ(normalizeNewlines("abc\r\n"), std::string("abc\n"));
    CHECK(normalizeNewlines("abc") != normalizeNewlines("abc\n"));
}
WTEST(consecutive_blank_lines_preserved) {
    CHECK_EQ(normalizeNewlines("a\r\n\r\n\r\nb"), std::string("a\n\n\nb"));
}
WTEST(empty_input) { CHECK_EQ(normalizeNewlines(""), std::string("")); }
WTEST(large_input_not_truncated) {
    std::string in;
    for (int i = 0; i < 200000; ++i) in += "line of text\r\n";
    const std::string out = normalizeNewlines(in);
    CHECK_EQ(out.size(), static_cast<size_t>(200000) * 13);
    CHECK(out.find('\r') == std::string::npos);
}
WTEST(non_ascii_bytes_untouched) {
    const std::string s = "h\xC3\xA9llo\r\n\xE6\x97\xA5";
    CHECK_EQ(normalizeNewlines(s), std::string("h\xC3\xA9llo\n\xE6\x97\xA5"));
}

TEST_MAIN()

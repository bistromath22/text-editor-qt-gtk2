#include <unistd.h>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>

#include "FileIO.h"
#include "TestHarness.h"

namespace fs = std::filesystem;
using namespace wedit;

namespace {

struct TempDir {
    fs::path path;
    TempDir() {
        path = fs::temp_directory_path() /
               ("wedit-io-" + std::to_string(reinterpret_cast<uintptr_t>(this)) + "-" +
                std::to_string(std::rand()));
        fs::create_directories(path);
    }
    ~TempDir() {
        std::error_code ec;
        fs::permissions(path, fs::perms::owner_all, ec);
        fs::remove_all(path, ec);
    }
    std::string file(const std::string& n) const { return (path / n).string(); }
    size_t entryCount() const {
        size_t n = 0;
        for (auto it = fs::directory_iterator(path); it != fs::directory_iterator(); ++it) ++n;
        return n;
    }
};

void put(const std::string& p, const std::string& s) { std::ofstream(p, std::ios::binary) << s; }
std::string slurp(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

// load -> save -> compare bytes (for LF/UTF-8 input the file must be identical)
void roundTrip(const std::string& bytesIn, const std::string& expectedOut) {
    TempDir d;
    put(d.file("in.txt"), bytesIn);
    ReadResult r = readTextFile(d.file("in.txt"));
    CHECK(r.ok);
    CHECK(writeFileAtomic(d.file("out.txt"), r.text).ok);
    CHECK_EQ(slurp(d.file("out.txt")), expectedOut);
}

}  // namespace

WTEST(roundtrip_edge_documents) {
    roundTrip("", "");
    roundTrip("one line", "one line");
    roundTrip("ends with newline\n", "ends with newline\n");
    roundTrip("\nleading newline", "\nleading newline");
    roundTrip("a\n\n\n\nb\n", "a\n\n\n\nb\n");
    roundTrip("\xE6\x97\xA5\xE6\x9C\xAC\n", "\xE6\x97\xA5\xE6\x9C\xAC\n");
    roundTrip("e\xCC\x81 \xF0\x9F\x98\x80 \xE2\x9D\xA4\xEF\xB8\x8F\n",
              "e\xCC\x81 \xF0\x9F\x98\x80 \xE2\x9D\xA4\xEF\xB8\x8F\n");
}

WTEST(empty_and_trailing_newline_stay_different) {
    TempDir d;
    put(d.file("empty"), "");
    put(d.file("nl"), "\n");
    CHECK(readTextFile(d.file("empty")).text != readTextFile(d.file("nl")).text);
}

WTEST(newline_normalisation_on_load) {
    TempDir d;
    put(d.file("crlf"), "a\r\nb\r\n");
    put(d.file("cr"), "a\rb\r");
    put(d.file("mixed"), "a\r\nb\rc\nd");
    CHECK_EQ(readTextFile(d.file("crlf")).text, std::string("a\nb\n"));
    CHECK_EQ(readTextFile(d.file("cr")).text, std::string("a\nb\n"));
    CHECK_EQ(readTextFile(d.file("mixed")).text, std::string("a\nb\nc\nd"));
}

WTEST(bom_policy_strip_on_load_never_written) {
    TempDir d;
    put(d.file("bom"), "\xEF\xBB\xBF" "hello\n");
    ReadResult r = readTextFile(d.file("bom"));
    CHECK(r.ok && r.hadBom);
    CHECK_EQ(r.text, std::string("hello\n"));
    CHECK(writeFileAtomic(d.file("out"), r.text).ok);
    CHECK_EQ(slurp(d.file("out")), std::string("hello\n"));
}

WTEST(invalid_utf8_and_nul_rejected) {
    TempDir d;
    put(d.file("bad"), "ok\xFF\xFE");
    ReadResult r = readTextFile(d.file("bad"));
    CHECK(!r.ok);
    CHECK(r.error.find("not valid UTF-8") != std::string::npos);
    put(d.file("nul"), std::string("a\0b", 3));
    CHECK(!readTextFile(d.file("nul")).ok);
}

WTEST(load_failure_leaves_active_document_unchanged) {
    TempDir d;
    put(d.file("good"), "new text\n");
    put(d.file("bad"), "\xC3\x28");
    DocumentFile doc{"/old/path.txt", false};
    std::string text = "unsaved edits";
    CHECK(!loadDocument(doc, text, d.file("bad")).ok);
    CHECK_EQ(text, std::string("unsaved edits"));
    CHECK_EQ(doc.path, std::string("/old/path.txt"));
    CHECK(!doc.clean);
    CHECK(!loadDocument(doc, text, d.file("missing")).ok);
    CHECK_EQ(text, std::string("unsaved edits"));
    CHECK(loadDocument(doc, text, d.file("good")).ok);
    CHECK_EQ(text, std::string("new text\n"));
    CHECK_EQ(doc.path, d.file("good"));
    CHECK(doc.clean);
}

WTEST(missing_directory_and_invalid_paths) {
    TempDir d;
    CHECK(!readTextFile(d.file("nope")).ok);
    CHECK(!readTextFile(d.path.string()).ok);  // directory
    CHECK(!readTextFile("").ok);
    CHECK(!writeFileAtomic(d.file("no/such/dir/f.txt"), "x").ok);
    CHECK(!writeFileAtomic("", "x").ok);
    CHECK_EQ(d.entryCount(), static_cast<size_t>(0));  // no stray temp files
}

WTEST(failed_save_keeps_original_and_cleans_temp) {
    TempDir d;
    // Destination is a directory: the final rename must fail after the temp
    // file was written; the temp file has to be removed.
    fs::create_directories(d.path / "dest");
    const size_t before = d.entryCount();
    WriteResult w = writeFileAtomic(d.file("dest"), "payload");
    CHECK(!w.ok);
    CHECK(fs::is_directory(d.path / "dest"));
    CHECK_EQ(d.entryCount(), before);
}

WTEST(failed_save_does_not_change_document_state) {
    TempDir d;
    put(d.file("orig.txt"), "original");
    DocumentFile doc{d.file("orig.txt"), false};
    WriteResult w = saveDocument(doc, d.file("missing_dir/new.txt"), "content");
    CHECK(!w.ok);
    CHECK_EQ(doc.path, d.file("orig.txt"));  // Save As failure: name unchanged
    CHECK(!doc.clean);                        // still dirty
    CHECK_EQ(slurp(d.file("orig.txt")), std::string("original"));
}

WTEST(successful_save_commits_state_and_replaces_file) {
    TempDir d;
    put(d.file("a.txt"), "old contents that are longer");
    DocumentFile doc{"", false};
    WriteResult w = saveDocument(doc, d.file("a.txt"), "new");
    CHECK(w.ok);
    CHECK_EQ(slurp(d.file("a.txt")), std::string("new"));
    CHECK_EQ(doc.path, d.file("a.txt"));
    CHECK(doc.clean);
    CHECK_EQ(d.entryCount(), static_cast<size_t>(1));  // temp file gone
}

WTEST(permissions_preserved_and_new_file_mode) {
    TempDir d;
    put(d.file("p.txt"), "x");
    fs::permissions(d.file("p.txt"), fs::perms::owner_read | fs::perms::owner_write |
                                         fs::perms::owner_exec | fs::perms::group_read);
    CHECK(writeFileAtomic(d.file("p.txt"), "y").ok);
    const auto perms = fs::status(d.file("p.txt")).permissions();
    CHECK((perms & fs::perms::owner_exec) != fs::perms::none);
    CHECK((perms & fs::perms::group_read) != fs::perms::none);
    CHECK((perms & fs::perms::others_read) == fs::perms::none);
    CHECK(writeFileAtomic(d.file("fresh.txt"), "z").ok);
    CHECK((fs::status(d.file("fresh.txt")).permissions() & fs::perms::owner_write) !=
          fs::perms::none);
}

WTEST(read_only_directory_save_fails_cleanly) {
    if (geteuid() == 0) {
        std::printf("  SKIPPED (not verified): running as root, permission bits are not enforced\n");
        return;
    }
    TempDir d;
    put(d.file("keep.txt"), "keep");
    fs::permissions(d.path, fs::perms::owner_read | fs::perms::owner_exec);
    CHECK(!writeFileAtomic(d.file("keep.txt"), "changed").ok);
    fs::permissions(d.path, fs::perms::owner_all);
    CHECK_EQ(slurp(d.file("keep.txt")), std::string("keep"));
}

WTEST(large_file_roundtrip) {
    TempDir d;
    std::string big;
    for (int i = 0; i < 300000; ++i) big += "line \xE6\x97\xA5 " + std::to_string(i) + "\n";
    put(d.file("big.txt"), big);
    ReadResult r = readTextFile(d.file("big.txt"));
    CHECK(r.ok);
    CHECK_EQ(r.text.size(), big.size());
    CHECK(writeFileAtomic(d.file("big2.txt"), r.text).ok);
    CHECK(slurp(d.file("big2.txt")) == big);
}

TEST_MAIN()

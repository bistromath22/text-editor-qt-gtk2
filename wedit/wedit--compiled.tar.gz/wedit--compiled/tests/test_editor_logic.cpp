#include <string>

#include "EditorLogic.h"
#include "TestHarness.h"
#include "TextNormalization.h"

using namespace wedit;

WTEST(unicode_column_is_codepoints_not_bytes) {
    CHECK_EQ(unicodeColumn(""), 1);
    CHECK_EQ(unicodeColumn("abcd"), 5);
    CHECK_EQ(unicodeColumn("\xE6\x97\xA5\xE6\x9C\xAC"), 3);          // 2 CJK chars, 6 bytes
    CHECK_EQ(unicodeColumn("\xF0\x9F\x98\x80x"), 3);                  // emoji + x
    CHECK_EQ(unicodeColumn("e\xCC\x81"), 3);                          // combining mark counts
}

WTEST(logical_line_counting_ignores_wrapping) {
    CHECK_EQ(countLogicalLines(""), 1);
    CHECK_EQ(countLogicalLines("one"), 1);
    CHECK_EQ(countLogicalLines("one\n"), 2);
    CHECK_EQ(countLogicalLines("a\n\n\nb"), 4);
    // A very long single line is one logical line however it wraps visually.
    CHECK_EQ(countLogicalLines(std::string(10000, 'x')), 1);
}

WTEST(enter_semantics_one_lf_per_press) {
    // Models "Enter inserts exactly one LF" on the normalised text model.
    std::string t = "ab";
    t.insert(1, "\n");               // middle
    CHECK_EQ(t, std::string("a\nb"));
    t.insert(t.size(), "\n");        // end
    t.insert(0, "\n");               // start
    CHECK_EQ(t, std::string("\na\nb\n"));
    CHECK_EQ(countLogicalLines(t), 4);
    t = "x\n\ny";                    // repeated blank lines survive normalisation
    CHECK_EQ(normalizeNewlines("x\r\n\r\ny"), t);
}

WTEST(margin_digits_and_width_growth) {
    CHECK_EQ(digitCount(1), 1);
    CHECK_EQ(digitCount(9), 1);
    CHECK_EQ(digitCount(10), 2);
    CHECK_EQ(digitCount(99), 2);
    CHECK_EQ(digitCount(100), 3);
    CHECK_EQ(digitCount(999), 3);
    CHECK_EQ(digitCount(1000), 4);
    CHECK_EQ(digitCount(0), 1);
    const int w1 = lineNumberMarginWidth(9, 10, 4);
    const int w2 = lineNumberMarginWidth(10, 10, 4);
    const int w3 = lineNumberMarginWidth(99, 10, 4);
    const int w4 = lineNumberMarginWidth(100, 10, 4);
    const int w5 = lineNumberMarginWidth(999, 10, 4);
    const int w6 = lineNumberMarginWidth(1000, 10, 4);
    CHECK_EQ(w1, 18);
    CHECK(w2 > w1);
    CHECK_EQ(w2, w3);
    CHECK(w4 > w3);
    CHECK_EQ(w4, w5);
    CHECK(w6 > w5);
    CHECK_EQ(lineNumberMarginWidth(1, 10, 4), w1);
}

WTEST(line_spacing_recomputed_from_zero_baseline) {
    // Default line_height=1.4 with a 20px natural height -> 28px desired -> 8 extra.
    LineSpacing s = computeLineSpacing(20, 1.4);
    CHECK_EQ(s.above, 4);
    CHECK_EQ(s.below, 4);
    CHECK(!s.compressionUnsupported);
    // Odd extra pixel goes deterministically below.
    s = computeLineSpacing(21, 1.4);  // round(29.4)=29 -> 8 extra
    CHECK_EQ(s.above + s.below, 8);
    s = computeLineSpacing(25, 1.4);  // 35 -> 10
    CHECK_EQ(s.above + s.below, 10);
    s = computeLineSpacing(10, 1.5);  // 15 -> 5 -> 2 above, 3 below
    CHECK_EQ(s.above, 2);
    CHECK_EQ(s.below, 3);
    // Calling again with the same natural height never accumulates.
    LineSpacing again = computeLineSpacing(10, 1.5);
    CHECK_EQ(again.above, s.above);
    CHECK_EQ(again.below, s.below);
    // line_height 1.0 -> nothing; < 1.0 -> unsupported, natural height used.
    s = computeLineSpacing(20, 1.0);
    CHECK(s.above == 0 && s.below == 0 && !s.compressionUnsupported);
    s = computeLineSpacing(20, 0.8);
    CHECK(s.above == 0 && s.below == 0 && s.compressionUnsupported);
    // Font size change -> new baseline, new result (not additive).
    CHECK(computeLineSpacing(40, 1.4).above > computeLineSpacing(20, 1.4).above);
    s = computeLineSpacing(0, 1.4);
    CHECK(s.above == 0 && s.below == 0);
}

WTEST(goto_line_validation) {
    CHECK(parseGotoLine("1", 5).ok);
    CHECK_EQ(parseGotoLine("5", 5).line, 5);
    CHECK_EQ(parseGotoLine("  3  ", 5).line, 3);
    CHECK(!parseGotoLine("0", 5).ok);
    CHECK(!parseGotoLine("6", 5).ok);
    CHECK(!parseGotoLine("", 5).ok);
    CHECK(!parseGotoLine("   ", 5).ok);
    CHECK(!parseGotoLine("-1", 5).ok);
    CHECK(!parseGotoLine("2x", 5).ok);
    CHECK(!parseGotoLine("1.5", 5).ok);
    CHECK(!parseGotoLine("99999999999999999999", 5).ok);
    CHECK(!parseGotoLine("abc", 5).ok);
    CHECK(!parseGotoLine("1", 5).ok == false);
    CHECK(!parseGotoLine("7", 5).error.empty());
}

WTEST(find_and_find_next_wrap) {
    const std::string doc = "alpha beta gamma beta delta";
    bool wrapped = true;
    size_t p = findText(doc, "beta", 0, false, &wrapped);
    CHECK_EQ(p, static_cast<size_t>(6));
    CHECK(!wrapped);
    p = findText(doc, "beta", p + 4, false, &wrapped);  // Find Next
    CHECK_EQ(p, static_cast<size_t>(17));
    CHECK(!wrapped);
    p = findText(doc, "beta", p + 4, false, &wrapped);  // wraps once
    CHECK_EQ(p, static_cast<size_t>(6));
    CHECK(wrapped);
    CHECK_EQ(findText(doc, "zzz", 0, false, &wrapped), std::string::npos);
    CHECK(!wrapped);
    CHECK_EQ(findText(doc, "", 0, false, &wrapped), std::string::npos);
}

WTEST(find_case_sensitivity_and_utf8_bytes) {
    CHECK_EQ(findText("Hello HELLO", "hello", 0, false, nullptr), static_cast<size_t>(0));
    CHECK_EQ(findText("Hello HELLO", "hello", 0, true, nullptr), std::string::npos);
    CHECK_EQ(findText("Hello HELLO", "HELLO", 0, true, nullptr), static_cast<size_t>(6));
    const std::string u = "\xE6\x97\xA5\xE6\x9C\xAC x";
    CHECK_EQ(findText(u, "x", 0, false, nullptr), static_cast<size_t>(7));  // byte offset
    // Match at the very end is found; start past the end clamps.
    CHECK_EQ(findText("abc", "c", 99, false, nullptr), static_cast<size_t>(2));
    // Needle longer than haystack.
    CHECK_EQ(findText("ab", "abc", 0, false, nullptr), std::string::npos);
}

TEST_MAIN()

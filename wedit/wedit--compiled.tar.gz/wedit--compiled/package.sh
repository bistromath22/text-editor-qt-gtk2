#!/usr/bin/env bash
# Builds, tests and packages wedit into a clean, verified wedit-source.zip.
#
# Environment:
#   WEDIT_CORE_ONLY=1   configure with -DWEDIT_BUILD_GUI=OFF (core library and
#                       tests only). Use this only on machines without
#                       wxWidgets; the script says loudly that the GUI was NOT
#                       built or tested.
set -Eeuo pipefail

die() { echo "package.sh: error: $*" >&2; exit 1; }
info() { echo "==> $*"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "${ROOT}"

CORE_ONLY="${WEDIT_CORE_ONLY:-0}"
ARCHIVE="${ROOT}/wedit-source.zip"
BUILD_DIR="${ROOT}/.package-build"

# --- tools --------------------------------------------------------------------
need() { command -v "$1" >/dev/null 2>&1 || die "required tool '$1' not found"; }
need cmake
need zip
need unzip
need sha256sum
if command -v c++ >/dev/null 2>&1 || command -v g++ >/dev/null 2>&1 || command -v clang++ >/dev/null 2>&1; then :; else
    die "no C++ compiler found"
fi
if [ "${CORE_ONLY}" != "1" ]; then
    need wx-config
fi

# --- clean build dir (only the exact project-local path) -------------------------
case "${BUILD_DIR}" in
    "${ROOT}"/.package-build) ;;
    *) die "refusing to delete unexpected path ${BUILD_DIR}" ;;
esac
rm -rf -- "${BUILD_DIR}"

CMAKE_ARGS=(-S "${ROOT}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release)
if [ "${CORE_ONLY}" = "1" ]; then
    CMAKE_ARGS+=(-DWEDIT_BUILD_GUI=OFF)
    echo "package.sh: NOTICE: WEDIT_CORE_ONLY=1 - the wxWidgets GUI is NOT built or tested." >&2
fi

info "Configuring (Release)"
cmake "${CMAKE_ARGS[@]}"
info "Building"
cmake --build "${BUILD_DIR}" --parallel
info "Running tests"
# The suites are display-free; when xvfb-run exists they run under it anyway
# so any future GUI test is covered. No GUI test executable exists yet.
if command -v xvfb-run >/dev/null 2>&1 && [ "${CORE_ONLY}" != "1" ]; then
    xvfb-run -a ctest --test-dir "${BUILD_DIR}" --output-on-failure
else
    ctest --test-dir "${BUILD_DIR}" --output-on-failure
    echo "package.sh: GUI tests: NOT RUN (no GUI test executable is defined and/or no xvfb-run)." >&2
fi

# --- desktop file ------------------------------------------------------------
if command -v desktop-file-validate >/dev/null 2>&1; then
    info "Validating packaging/wedit.desktop"
    desktop-file-validate "${ROOT}/packaging/wedit.desktop"
else
    echo "package.sh: desktop-file-validate not installed: desktop entry validation SKIPPED (not passed)." >&2
fi

# --- stage the source tree -----------------------------------------------------
STAGE="$(mktemp -d)"
trap 'rm -rf -- "${STAGE}"' EXIT
mkdir -p "${STAGE}/wedit"

INCLUDE=(CMakeLists.txt README.md config.example.ini install_deps.sh package.sh packaging src tests docs)
for item in "${INCLUDE[@]}"; do
    [ -e "${ROOT}/${item}" ] || die "missing required item: ${item}"
    cp -R "${ROOT}/${item}" "${STAGE}/wedit/"
done

# Remove anything that is not source (belt and braces; nothing should match).
find "${STAGE}/wedit" \( -name 'CMakeFiles' -o -name 'CMakeCache.txt' -o -name 'cmake_install.cmake' \
    -o -name 'compile_commands.json' -o -name '.git' -o -name '.hg' -o -name '.svn' -o -name '.idea' \
    -o -name '.vscode' -o -name 'build' -o -name 'build-*' -o -name '.package-build' \
    -o -name '*.o' -o -name '*.a' -o -name '*.so' -o -name '*.swp' -o -name '*~' -o -name '*.log' \
    -o -name '*.tmp' -o -name 'wedit-source.zip' \) -prune -exec rm -rf -- {} +

chmod 755 "${STAGE}/wedit/install_deps.sh" "${STAGE}/wedit/package.sh"

# Deterministic timestamps and ordering.
EPOCH_DATE="${SOURCE_DATE_EPOCH:+@${SOURCE_DATE_EPOCH}}"
EPOCH_DATE="${EPOCH_DATE:-2026-01-01 00:00:00}"
find "${STAGE}/wedit" -exec touch -h -d "${EPOCH_DATE}" {} +

rm -f -- "${ARCHIVE}"
info "Creating ${ARCHIVE}"
( cd "${STAGE}" && find wedit -type f | LC_ALL=C sort | zip -X -q "${ARCHIVE}" -@ ) || die "zip failed"

# --- verify -----------------------------------------------------------------------
info "Verifying archive"
[ -s "${ARCHIVE}" ] || die "archive is missing or empty"
unzip -tq "${ARCHIVE}" >/dev/null || die "unzip -t reported a corrupt archive"
LISTING="$(unzip -Z1 "${ARCHIVE}")"

REQUIRED_FILES=(
    wedit/CMakeLists.txt wedit/README.md wedit/config.example.ini wedit/install_deps.sh
    wedit/package.sh wedit/packaging/wedit.desktop
    wedit/src/main.cpp wedit/src/MainFrame.h wedit/src/MainFrame.cpp
    wedit/src/EditorControl.h wedit/src/EditorControl.cpp
    wedit/src/ConfigManager.h wedit/src/ConfigManager.cpp
    wedit/src/ShortcutParser.h wedit/src/ShortcutParser.cpp
    wedit/src/TextNormalization.h wedit/src/TextNormalization.cpp
    wedit/src/Utf8Utils.h wedit/src/Utf8Utils.cpp
    wedit/src/FileIO.h wedit/src/FileIO.cpp
    wedit/src/ClipboardManager.h wedit/src/ClipboardManager.cpp
    wedit/src/AppActions.h wedit/src/AppActions.cpp
    wedit/tests/CMakeLists.txt wedit/tests/test_text_normalization.cpp
    wedit/tests/test_utf8_utils.cpp wedit/tests/test_config_manager.cpp
    wedit/tests/test_shortcut_parser.cpp wedit/tests/test_file_io.cpp
    wedit/tests/test_editor_logic.cpp wedit/docs/DESIGN.md wedit/docs/PORTING_NOTES.md
)
for f in "${REQUIRED_FILES[@]}"; do
    grep -Fxq -- "${f}" <<<"${LISTING}" || die "archive is missing ${f}"
done
if grep -Eq '(^|/)(build[^/]*|\.package-build|CMakeFiles|\.git|\.idea|\.vscode)/|CMakeCache\.txt|cmake_install\.cmake|compile_commands\.json|\.(o|a|so|swp)$|wedit-source\.zip$' <<<"${LISTING}"; then
    die "archive contains build artifacts or forbidden files"
fi
if grep -qv '^wedit/' <<<"${LISTING}"; then
    die "archive has entries outside the top-level wedit/ directory"
fi

echo
echo "Archive listing:"
unzip -l "${ARCHIVE}"
echo
echo "Archive : ${ARCHIVE}"
echo "Size    : $(wc -c <"${ARCHIVE}") bytes"
echo "SHA-256 : $(sha256sum "${ARCHIVE}" | cut -d' ' -f1)"
if [ "${CORE_ONLY}" = "1" ]; then
    echo "NOTE    : core-only build: the wxWidgets GUI was NOT compiled or tested by this run." >&2
fi

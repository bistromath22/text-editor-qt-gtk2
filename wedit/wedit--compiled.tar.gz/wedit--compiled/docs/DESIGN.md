# wedit design notes

## Layers

```
main.cpp            pre-GUI CLI, config load, wxEntry
MainFrame           wxFrame, menus, sizers, dialogs, file workflow, Dispatch()
EditorControl       wxStyledTextCtrl configured as a plain-text surface
ClipboardManager    plain-text wxClipboard, newline-normalised paste, undo grouping
-------------------------------------------------------------------------------
wedit_core (no wx)  AppActions · ConfigManager · ShortcutParser · TextNormalization
                    Utf8Utils · FileIO · EditorLogic · Cli
```

Anything that can be decided without a widget lives in `wedit_core` so it can be
tested by CTest on a machine with no display.

## Frame, sizers, menus

`MainFrame` owns a vertical root `wxBoxSizer` with two children: the border
panel (stretch 1) and the status panel (stretch 0). The border panel's
background is `border_color`; inside it the `EditorControl` is added with a
`wxALL` border equal to `FromDIP(border_size)`. This keeps four distinct things
separate: the border surround, Scintilla's own text margins, the line-number
margin, and the status row. The status row is hidden with `Show(panel, false)`
on the sizer, so no space is reserved when it is off. `border_size` is in
logical (DIP) pixels. The OS title bar is not touched.

Menus are built from the `Action` registry (`AppActions`). Each item's id is
`wxID_HIGHEST + 100 + actionIndex`, and one `wxEVT_MENU` binding over the id
range routes into `MainFrame::Dispatch`.

## Scintilla document ownership

The Scintilla document in `EditorControl` is the only text model. Strings are
created transiently for file I/O, the clipboard and tests. `GetUtf8()` copies the
bytes out for saving; `LoadUtf8()` replaces the document with undo collection
disabled, then `EmptyUndoBuffer()` and `SetSavePoint()` so the previous
document's history cannot be restored. The modified flag is `GetModify()`,
driven by Scintilla's save point; `wxEVT_STC_SAVEPOINTREACHED/LEFT` refresh the
title.

## UTF-8 positions vs Unicode columns

Scintilla positions are byte offsets. The status column is computed by taking the
bytes from the line start to the caret (`GetTextRangeRaw`) and counting code
points with `Utf8Utils` (`EditorLogic::unicodeColumn`), never `pos - lineStart`.
`Utf8Utils` also offers boundary helpers that never split a sequence. Combining
marks count as separate code points (documented policy).

## Newlines and BOM

Every external text boundary uses `normalizeNewlines` (CRLF→LF first, then lone
CR→LF). File load: bytes → strip one BOM → strict UTF-8 validation → reject NUL
(Scintilla's raw-text API is NUL-terminated) → normalise → only then touch the
editor. Save writes the document bytes unchanged (LF), no BOM, no added newline.

## Clipboard and undo grouping

Paste: read `wxDF_UNICODETEXT` under a `wxClipboardLocker`, convert to UTF-8,
normalise, convert back with a failure check, then inside an RAII `UndoGroup`
(`BeginUndoAction`/`EndUndoAction`) call `ReplaceSelection`, so a multi-line
paste is one undo step on every exit path. Cut copies first and deletes only if
the clipboard accepted the data. Scintilla's native Ctrl+C/X/V/Z/Y bindings are
cleared (`CmdKeyClear`) so those keys reach the frame's accelerators and menu
items, which call the same code as the menu.

## Safe save

`writeFileAtomic`: POSIX uses `mkstemp` in the destination directory, a checked
`write` loop (EINTR/short writes), `fchmod` to the old mode, `fsync`, `close`,
`rename`; the temp file is `unlink`ed on every failure. Windows uses
`CreateFileW(CREATE_NEW)`, `WriteFile` loop, `FlushFileBuffers` and
`MoveFileExW(REPLACE_EXISTING|WRITE_THROUGH)`. Callers change path/dirty state
only after success (`saveDocument` demonstrates and tests this contract).

## Configuration

`makeDefaults()` is the only place defaults exist (member initialisers for the
editor keys, the `AppActions` table for the shortcuts). The INI parser builds a
candidate `Config` with per-key `Field` validators and never throws. `ConfigManager::reload`
loads and validates the whole candidate and swaps it in only on success.
`serializeConfig(makeDefaults())` backs `--print-config`; a test proves
`config.example.ini` parses to exactly the defaults.

## Shortcuts

`parseShortcut` converts GTK-style text into a neutral `Shortcut`
(modifiers + Char/Function/Plus/Minus). `resolveShortcuts` applies the
invalid-spelling and duplicate policies and returns the bindings plus
diagnostics. `MainFrame::RebuildShortcuts` turns bindings into menu accelerator
text (`"\tCtrl+Shift+S"`), and for plus/minus into explicit `wxAcceleratorEntry`
rows (several physical keys), then relabels the items from the same data.

## Gutter, current line, status

Margin 0 is `wxSTC_MARGIN_NUMBER`; its width is
`digits(logicalLines) * TextWidth("9") + 2*inset` and is recomputed on
`wxEVT_STC_CHANGE` only when the line count changes (9→10, 99→100 …) and after
font changes. Width 0 when disabled. The current line uses
`SetCaretLineVisible/Background` (whole logical line). The status text is updated
from `wxEVT_STC_UPDATEUI`.

## Caret and line height

Block caret: `SetCaretStyle(wxSTC_CARETSTYLE_BLOCK)`; steady when blinking is off
(`SetCaretPeriod(0)`). Line height: reset extra ascent/descent to 0, read
`TextHeight(0)`, compute `desired = round(natural * line_height)`, split the
extra pixels (remainder below), apply with `SetExtraAscent/Descent`. Always
recomputed from zero, so reloads and font changes never accumulate. Values below
1.0 fall back to natural height with a warning. `pixels_above`, `pixels_below`
and `line_distance` are reported, not applied.

## Known risk areas to check on a real display

Behaviour that depends on wxWidgets/GTK delivery and could not be verified in the
build sandbox: whether the frame's accelerator table sees Ctrl+Plus/Minus while
the editor has focus, menu-label accelerator parsing of every configured spelling,
and rendering of the block caret with extra line spacing.

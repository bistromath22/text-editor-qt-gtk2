# Porting notes: Slate/gSlate behaviour in wedit

## Which reference files were actually available

The implementation request supplied two files: `config.ini` and the wxWidgets
master prompt. The following references named in that prompt were **not present**
and were therefore not read:

* `wedit_master_ai_prompt.txt` (FLTK specification)
* `wedit_build_prompt--gemini.txt`
* `11--ai-text-prompt--gslate.txt` (gSlate/GTK4 prompt)
* `wedit_FLTK_Ubuntu_26.04_Master_AI_Development_Prompt.txt`

Only requirements stated in the wxWidgets prompt itself, plus the supplied
`config.ini`, were used. No feature is attributed to a reference that was not
read, so the lists below describe how the *behaviours the wxWidgets prompt
spells out* map onto wxWidgets/Scintilla, not a line-by-line comparison with
gSlate.

## Retained as specified

* One window, one document; File/Edit/View menus.
* Unsaved-change protection (Save / Discard / Cancel) before New, Open, Quit and
  window close; failed or cancelled operations never lose the buffer.
* UTF-8 plain-text open/save, strict validation, newline preservation (leading,
  repeated, trailing), no automatic trailing newline.
* Plain-text clipboard, Cut only after the clipboard accepted the data.
* Find / Find Next (wraps once), Go to Line (1-based logical lines).
* Optional line-number gutter, current-line highlight, optional status bar
  (`Ln, Col`), word wrap, block caret, runtime config reload, full screen,
  configurable shortcuts, border surround.
* Every key and value of the supplied `config.ini`.

## Adapted to wxWidgets / Scintilla

* Text model: `wxStyledTextCtrl` document (not a GTK/FLTK buffer).
* Dirty state: Scintilla save point (`GetModify`/`SetSavePoint`).
* Undo/redo: Scintilla's built-in engine; multi-line paste grouped with
  `BeginUndoAction`/`EndUndoAction`.
* Line numbers and current-line highlight: Scintilla's native number margin and
  caret line instead of custom widgets.
* Shortcuts: GTK-style spellings from the config are parsed into wx accelerators.
* Border: an application-owned panel plus a DIP-aware sizer border.
* Columns: Unicode code points, derived from Scintilla's byte positions.

## Cannot be reproduced exactly

* `pixels_above`, `pixels_below`, `line_distance`: Scintilla has only global line
  metrics, so these are parsed, validated, printed and reported but not applied.
* `line_height`: approximated globally via extra ascent/descent; no compression
  below 1.0.
* Case-insensitive search folds ASCII only.
* Native window frame/title bar colour is controlled by the window manager.

## Deliberately excluded

Tabs, multiple documents, split panes, file trees, syntax highlighting, folding,
completion, toolbars, terminals, plugins, rich text, cloud/telemetry/network.

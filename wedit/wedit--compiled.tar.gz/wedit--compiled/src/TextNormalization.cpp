#include "TextNormalization.h"

namespace wedit {

std::string normalizeNewlines(std::string_view input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        const char c = input[i];
        if (c == '\r') {
            out.push_back('\n');
            if (i + 1 < input.size() && input[i + 1] == '\n') {
                ++i;  // CRLF is one newline, never two
            }
        } else {
            out.push_back(c);
        }
    }
    return out;
}

}  // namespace wedit

// Plain-text clipboard operations on a wxStyledTextCtrl. Every paste goes
// through newline normalisation and is one undo transaction.
#pragma once

class wxStyledTextCtrl;

namespace wedit {

class ClipboardManager {
public:
    // Each returns true on success. Cut never deletes text unless the
    // clipboard accepted it; Paste never modifies the document on failure.
    static bool Copy(wxStyledTextCtrl* editor);
    static bool Cut(wxStyledTextCtrl* editor);
    static bool Paste(wxStyledTextCtrl* editor);
};

}  // namespace wedit

#include "EditorLogic.h"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>

#include "Utf8Utils.h"

namespace wedit {

int unicodeColumn(std::string_view linePrefix) {
    return static_cast<int>(countCodePoints(linePrefix)) + 1;
}

int digitCount(int n) {
    int d = 1;
    while (n >= 10) {
        n /= 10;
        ++d;
    }
    return d;
}

int lineNumberMarginWidth(int lineCount, int digitWidth, int inset) {
    return digitCount(std::max(lineCount, 1)) * digitWidth + 2 * inset;
}

int countLogicalLines(std::string_view text) {
    return static_cast<int>(std::count(text.begin(), text.end(), '\n')) + 1;
}

LineSpacing computeLineSpacing(int naturalHeight, double lineHeight) {
    LineSpacing s;
    if (naturalHeight <= 0) return s;
    s.compressionUnsupported = lineHeight < 1.0;
    const double factor = std::max(lineHeight, 1.0);
    const int desired = static_cast<int>(std::lround(naturalHeight * factor));
    const int extra = std::max(0, desired - naturalHeight);
    s.above = extra / 2;
    s.below = extra - s.above;  // odd pixel goes below, deterministically
    return s;
}

GotoResult parseGotoLine(const std::string& text, int lineCount) {
    GotoResult r;
    size_t b = 0, e = text.size();
    while (b < e && std::isspace(static_cast<unsigned char>(text[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(text[e - 1]))) --e;
    const std::string t = text.substr(b, e - b);
    if (t.empty()) {
        r.error = "Enter a line number.";
        return r;
    }
    for (char c : t) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            r.error = "'" + t + "' is not a valid line number.";
            return r;
        }
    }
    errno = 0;
    const long v = std::strtol(t.c_str(), nullptr, 10);
    if (errno == ERANGE || v < 1 || v > lineCount) {
        r.error = "Line number must be between 1 and " + std::to_string(lineCount) + ".";
        return r;
    }
    r.ok = true;
    r.line = static_cast<int>(v);
    return r;
}

namespace {
inline char fold(char c, bool matchCase) {
    return matchCase ? c : static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
}

size_t searchRange(std::string_view h, std::string_view n, size_t from, size_t limit,
                   bool matchCase) {
    // Match start positions in [from, limit].
    if (n.empty() || h.size() < n.size()) return std::string_view::npos;
    const size_t last = std::min(limit, h.size() - n.size());
    for (size_t i = from; i <= last; ++i) {
        size_t k = 0;
        while (k < n.size() && fold(h[i + k], matchCase) == fold(n[k], matchCase)) ++k;
        if (k == n.size()) return i;
    }
    return std::string_view::npos;
}
}  // namespace

size_t findText(std::string_view haystack, std::string_view needle, size_t start, bool matchCase,
                bool* wrapped) {
    if (wrapped) *wrapped = false;
    if (needle.empty()) return std::string_view::npos;
    start = std::min(start, haystack.size());
    size_t pos = searchRange(haystack, needle, start, haystack.size(), matchCase);
    if (pos != std::string_view::npos) return pos;
    pos = searchRange(haystack, needle, 0, start, matchCase);
    if (pos != std::string_view::npos && wrapped) *wrapped = true;
    return pos;
}

}  // namespace wedit

#include "Cli.h"

#ifndef WEDIT_VERSION
#define WEDIT_VERSION "1.0.0"
#endif

namespace wedit {

CliOptions parseCli(const std::vector<std::string>& args) {
    CliOptions o;
    bool endOfOptions = false;
    for (size_t i = 0; i < args.size(); ++i) {
        const std::string& a = args[i];
        if (endOfOptions || a.empty() || a[0] != '-' || a == "-") {
            o.files.push_back(a);
            continue;
        }
        if (a == "--") {
            endOfOptions = true;
        } else if (a == "--help" || a == "-h") {
            o.action = CliAction::Help;
        } else if (a == "--version" || a == "-v") {
            o.action = CliAction::Version;
        } else if (a == "--print-config") {
            o.action = CliAction::PrintConfig;
        } else if (a == "--print-config-paths") {
            o.action = CliAction::PrintConfigPaths;
        } else if (a == "--config") {
            if (i + 1 >= args.size()) {
                o.action = CliAction::Error;
                o.error = "--config requires a PATH argument";
                return o;
            }
            o.configPath = args[++i];
        } else if (a.rfind("--config=", 0) == 0) {
            o.configPath = a.substr(9);
            if (o.configPath->empty()) {
                o.action = CliAction::Error;
                o.error = "--config requires a non-empty PATH";
                return o;
            }
        } else {
            o.action = CliAction::Error;
            o.error = "unknown option '" + a + "' (try --help)";
            return o;
        }
    }
    if (o.files.size() > 1) {
        o.warnings.push_back("wedit edits one document at a time: opening '" + o.files[0] +
                             "' and ignoring " + std::to_string(o.files.size() - 1) +
                             " additional file(s)");
    }
    return o;
}

std::string helpText() {
    return "wedit - lightweight plain-text editor\n"
           "\n"
           "Usage:\n"
           "  wedit [FILE ...]\n"
           "  wedit --config PATH [FILE ...]\n"
           "  wedit --print-config\n"
           "  wedit --print-config-paths\n"
           "  wedit --help\n"
           "  wedit --version\n"
           "\n"
           "Options:\n"
           "  --config PATH         use exactly this config.ini (fails if unusable)\n"
           "  --print-config        print the canonical default settings and shortcuts\n"
           "  --print-config-paths  list config candidates in priority order and the active one\n"
           "  --help                show this help\n"
           "  --version             show version information\n"
           "\n"
           "Only one document is open at a time: when several FILEs are given, the first\n"
           "is opened and the rest are reported as ignored.\n";
}

std::string versionText(const std::string& wxVersion) {
    std::string s = "wedit " WEDIT_VERSION "\n";
    if (!wxVersion.empty()) s += "wxWidgets " + wxVersion + "\n";
    return s;
}

}  // namespace wedit

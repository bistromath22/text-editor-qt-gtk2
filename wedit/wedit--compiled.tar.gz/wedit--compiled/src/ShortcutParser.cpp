#include "ShortcutParser.h"

#include <cctype>
#include <set>

namespace wedit {

namespace {

std::string lowerCopy(const std::string& s) {
    std::string r = s;
    for (char& c : r) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return r;
}

bool parseKeyName(const std::string& name, Shortcut& sc) {
    if (name.empty()) return false;
    const std::string low = lowerCopy(name);
    if (low == "plus") {
        sc.kind = KeyKind::Plus;
        return true;
    }
    if (low == "minus") {
        sc.kind = KeyKind::Minus;
        return true;
    }
    if (name.size() == 1) {
        const unsigned char c = static_cast<unsigned char>(name[0]);
        if (std::isalpha(c)) {
            sc.kind = KeyKind::Char;
            sc.value = std::toupper(c);
            return true;
        }
        if (std::isdigit(c)) {
            sc.kind = KeyKind::Char;
            sc.value = c;
            return true;
        }
        return false;
    }
    if (low.size() >= 2 && low[0] == 'f') {
        int n = 0;
        for (size_t i = 1; i < low.size(); ++i) {
            if (!std::isdigit(static_cast<unsigned char>(low[i]))) return false;
            n = n * 10 + (low[i] - '0');
            if (n > 99) return false;
        }
        if (n >= 1 && n <= 24) {
            sc.kind = KeyKind::Function;
            sc.value = n;
            return true;
        }
    }
    return false;
}

}  // namespace

std::string Shortcut::label() const {
    std::string r;
    if (ctrl) r += "Ctrl+";
    if (alt) r += "Alt+";
    if (shift) r += "Shift+";
    switch (kind) {
        case KeyKind::Char:
            r.push_back(static_cast<char>(value));
            break;
        case KeyKind::Function:
            r += "F" + std::to_string(value);
            break;
        case KeyKind::Plus:
            r += "+";
            break;
        case KeyKind::Minus:
            r += "-";
            break;
        case KeyKind::None:
            break;
    }
    return r;
}

ParseShortcutResult parseShortcut(const std::string& spelling) {
    ParseShortcutResult res;
    Shortcut sc;
    size_t i = 0;
    const size_t n = spelling.size();
    while (i < n && spelling[i] == '<') {
        const size_t close = spelling.find('>', i);
        if (close == std::string::npos) {
            res.error = "unterminated modifier in '" + spelling + "'";
            return res;
        }
        const std::string mod = lowerCopy(spelling.substr(i + 1, close - i - 1));
        if (mod == "primary" || mod == "control" || mod == "ctrl") {
            sc.ctrl = true;
        } else if (mod == "shift") {
            sc.shift = true;
        } else if (mod == "alt") {
            sc.alt = true;
        } else {
            res.error = "unsupported modifier <" + mod + "> in '" + spelling + "'";
            return res;
        }
        i = close + 1;
    }
    if (!parseKeyName(spelling.substr(i), sc)) {
        res.error = "unsupported key '" + spelling.substr(i) + "' in '" + spelling + "'";
        return res;
    }
    res.ok = true;
    res.shortcut = sc;
    return res;
}

const Shortcut* ResolvedShortcuts::find(Action a) const {
    for (const auto& b : bindings) {
        if (b.first == a) return &b.second;
    }
    return nullptr;
}

ResolvedShortcuts resolveShortcuts(const std::map<std::string, std::string>& configured) {
    ResolvedShortcuts out;
    std::map<Shortcut, std::string> owner;  // shortcut -> config name of its owner

    for (const auto& info : allActions()) {
        const std::string name = info.configName;
        const Shortcut def = parseShortcut(info.defaultShortcut).shortcut;
        Shortcut chosen = def;

        auto it = configured.find(name);
        if (it != configured.end()) {
            const ParseShortcutResult r = parseShortcut(it->second);
            if (r.ok) {
                chosen = r.shortcut;
            } else {
                out.diagnostics.push_back("shortcut '" + name + "': " + r.error +
                                          "; using default " + info.defaultShortcut);
            }
        }

        auto clash = owner.find(chosen);
        if (clash != owner.end()) {
            out.diagnostics.push_back("shortcut '" + name + "' (" + chosen.label() +
                                      ") conflicts with '" + clash->second + "'");
            if (!(chosen == def) && owner.find(def) == owner.end()) {
                chosen = def;
                out.diagnostics.push_back("shortcut '" + name + "' falls back to default " +
                                          chosen.label());
            } else {
                out.diagnostics.push_back("shortcut '" + name +
                                          "' left unbound (still available from the menu)");
                continue;
            }
        }
        owner[chosen] = name;
        out.bindings.emplace_back(info.action, chosen);
    }
    return out;
}

}  // namespace wedit

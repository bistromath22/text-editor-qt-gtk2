#include "ConfigManager.h"

#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <functional>
#include <set>
#include <sstream>

#include "AppActions.h"
#include "ShortcutParser.h"

namespace fs = std::filesystem;

namespace wedit {

// ---------------------------------------------------------------- defaults

Config makeDefaults() {
    Config c;  // member initialisers carry the values from the supplied config.ini
    for (const auto& info : allActions()) {
        c.shortcuts[info.configName] = info.defaultShortcut;
    }
    return c;
}

bool Config::operator==(const Config& o) const {
    return wordwrap == o.wordwrap && border_size == o.border_size &&
           border_color == o.border_color && background_color == o.background_color &&
           gutter_background_color == o.gutter_background_color &&
           current_line_color == o.current_line_color &&
           line_number_color == o.line_number_color && text_color == o.text_color &&
           block_cursor == o.block_cursor && block_cursor_blink == o.block_cursor_blink &&
           font_family == o.font_family && font_size == o.font_size &&
           line_height == o.line_height && pixels_above == o.pixels_above &&
           pixels_below == o.pixels_below && line_distance == o.line_distance &&
           show_line_numbers == o.show_line_numbers &&
           highlight_current_line == o.highlight_current_line &&
           show_statusbar == o.show_statusbar && shortcuts == o.shortcuts;
}

// ------------------------------------------------------------- validation

namespace {

std::string trim(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

std::string lowerCopy(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

bool parseBool(const std::string& v, bool& out) {
    const std::string l = lowerCopy(v);
    if (l == "true" || l == "yes" || l == "1") {
        out = true;
        return true;
    }
    if (l == "false" || l == "no" || l == "0") {
        out = false;
        return true;
    }
    return false;
}

bool parseIntStrict(const std::string& v, long& out) {
    if (v.empty()) return false;
    for (char c : v) {
        if (!(std::isdigit(static_cast<unsigned char>(c)) || c == '+' || c == '-')) return false;
    }
    errno = 0;
    char* end = nullptr;
    const long r = std::strtol(v.c_str(), &end, 10);
    if (errno == ERANGE || end != v.c_str() + v.size()) return false;
    out = r;
    return true;
}

bool parseDoubleStrict(const std::string& v, double& out) {
    if (v.empty()) return false;
    for (char c : v) {  // rejects hex floats, "nan", "inf", whitespace, junk
        if (!(std::isdigit(static_cast<unsigned char>(c)) || c == '+' || c == '-' || c == '.' ||
              c == 'e' || c == 'E')) {
            return false;
        }
    }
    errno = 0;
    char* end = nullptr;
    const double r = std::strtod(v.c_str(), &end);
    if (errno == ERANGE || end != v.c_str() + v.size() || !std::isfinite(r)) return false;
    out = r;
    return true;
}

struct Field {
    // Returns an error message, or "" on success.
    std::function<std::string(Config&, const std::string&)> set;
    std::function<void(Config&, const Config&)> reset;
};

Field boolField(bool Config::*m) {
    return {[m](Config& c, const std::string& v) -> std::string {
                bool b = false;
                if (!parseBool(v, b)) return "expected true/false (or yes/no, 1/0), got '" + v + "'";
                c.*m = b;
                return "";
            },
            [m](Config& c, const Config& d) { c.*m = d.*m; }};
}

Field intField(int Config::*m, int lo, int hi) {
    return {[m, lo, hi](Config& c, const std::string& v) -> std::string {
                long n = 0;
                if (!parseIntStrict(v, n)) return "expected an integer, got '" + v + "'";
                if (n < lo || n > hi) {
                    return "value " + v + " outside " + std::to_string(lo) + ".." +
                           std::to_string(hi);
                }
                c.*m = static_cast<int>(n);
                return "";
            },
            [m](Config& c, const Config& d) { c.*m = d.*m; }};
}

Field doubleField(double Config::*m, double lo, double hi) {
    return {[m, lo, hi](Config& c, const std::string& v) -> std::string {
                double d = 0;
                if (!parseDoubleStrict(v, d)) return "expected a finite number, got '" + v + "'";
                if (d < lo || d > hi) {
                    std::ostringstream os;
                    os << "value " << v << " outside " << lo << ".." << hi;
                    return os.str();
                }
                c.*m = d;
                return "";
            },
            [m](Config& c, const Config& d) { c.*m = d.*m; }};
}

Field colorField(std::string Config::*m) {
    return {[m](Config& c, const std::string& v) -> std::string {
                if (!isValidColor(v)) return "expected #RRGGBB, got '" + v + "'";
                c.*m = v;
                return "";
            },
            [m](Config& c, const Config& d) { c.*m = d.*m; }};
}

Field fontFamilyField() {
    return {[](Config& c, const std::string& v) -> std::string {
                if (v.empty()) return "font_family must not be empty";
                c.font_family = v;
                return "";
            },
            [](Config& c, const Config& d) { c.font_family = d.font_family; }};
}

const std::map<std::string, Field>& editorFields() {
    static const std::map<std::string, Field> fields = {
        {"wordwrap", boolField(&Config::wordwrap)},
        {"border_size", intField(&Config::border_size, kMinBorderSize, kMaxBorderSize)},
        {"border_color", colorField(&Config::border_color)},
        {"background_color", colorField(&Config::background_color)},
        {"gutter_background_color", colorField(&Config::gutter_background_color)},
        {"current_line_color", colorField(&Config::current_line_color)},
        {"line_number_color", colorField(&Config::line_number_color)},
        {"text_color", colorField(&Config::text_color)},
        {"block_cursor", boolField(&Config::block_cursor)},
        {"block_cursor_blink", boolField(&Config::block_cursor_blink)},
        {"font_family", fontFamilyField()},
        {"font_size", intField(&Config::font_size, kMinFontSize, kMaxFontSize)},
        {"line_height", doubleField(&Config::line_height, 0.5, 5.0)},
        {"pixels_above", doubleField(&Config::pixels_above, 0.0, 100.0)},
        {"pixels_below", doubleField(&Config::pixels_below, 0.0, 100.0)},
        {"line_distance", doubleField(&Config::line_distance, 0.0, 100.0)},
        {"show_line_numbers", boolField(&Config::show_line_numbers)},
        {"highlight_current_line", boolField(&Config::highlight_current_line)},
        {"show_statusbar", boolField(&Config::show_statusbar)},
    };
    return fields;
}

// Serialisation order == order in the supplied config.ini.
const std::vector<std::string>& editorKeyOrder() {
    static const std::vector<std::string> order = {
        "wordwrap",          "border_size",       "border_color",   "background_color",
        "gutter_background_color", "current_line_color", "line_number_color", "text_color",
        "block_cursor",      "block_cursor_blink", "font_family",   "font_size",
        "line_height",       "pixels_above",      "pixels_below",   "line_distance",
        "show_line_numbers", "highlight_current_line", "show_statusbar"};
    return order;
}

std::string formatDouble(double d) {
    std::ostringstream os;
    os.precision(15);
    os << d;
    return os.str();
}

std::string fieldValueText(const Config& c, const std::string& key) {
    if (key == "wordwrap") return c.wordwrap ? "true" : "false";
    if (key == "border_size") return std::to_string(c.border_size);
    if (key == "border_color") return c.border_color;
    if (key == "background_color") return c.background_color;
    if (key == "gutter_background_color") return c.gutter_background_color;
    if (key == "current_line_color") return c.current_line_color;
    if (key == "line_number_color") return c.line_number_color;
    if (key == "text_color") return c.text_color;
    if (key == "block_cursor") return c.block_cursor ? "true" : "false";
    if (key == "block_cursor_blink") return c.block_cursor_blink ? "true" : "false";
    if (key == "font_family") return c.font_family;
    if (key == "font_size") return std::to_string(c.font_size);
    if (key == "line_height") return formatDouble(c.line_height);
    if (key == "pixels_above") return formatDouble(c.pixels_above);
    if (key == "pixels_below") return formatDouble(c.pixels_below);
    if (key == "line_distance") return formatDouble(c.line_distance);
    if (key == "show_line_numbers") return c.show_line_numbers ? "true" : "false";
    if (key == "highlight_current_line") return c.highlight_current_line ? "true" : "false";
    if (key == "show_statusbar") return c.show_statusbar ? "true" : "false";
    return "";
}

}  // namespace

bool isValidColor(const std::string& s) {
    if (s.size() != 7 || s[0] != '#') return false;
    for (size_t i = 1; i < 7; ++i) {
        if (!std::isxdigit(static_cast<unsigned char>(s[i]))) return false;
    }
    return true;
}

// ----------------------------------------------------------------- parsing

ParseResult parseConfigText(const std::string& text) {
    ParseResult result;
    result.config = makeDefaults();
    const Config defaults = makeDefaults();
    Config& cfg = result.config;
    auto& diag = result.diagnostics;

    enum class Section { None, Editor, Shortcuts, Unknown };
    Section section = Section::None;
    std::string sectionName;
    std::set<std::string> seen;

    std::istringstream in(text);
    std::string rawLine;
    int lineNo = 0;
    while (std::getline(in, rawLine)) {
        ++lineNo;
        const std::string line = trim(rawLine);  // also drops a trailing '\r'
        if (line.empty() || line[0] == '#' || line[0] == ';') continue;
        const std::string where = "line " + std::to_string(lineNo) + ": ";

        if (line[0] == '[') {
            if (line.back() != ']' || line.size() < 3) {
                diag.push_back(where + "malformed section header '" + line + "'");
                section = Section::Unknown;  // ignore the keys that follow
                continue;
            }
            sectionName = trim(line.substr(1, line.size() - 2));
            if (sectionName == "editor") {
                section = Section::Editor;
            } else if (sectionName == "shortcuts") {
                section = Section::Shortcuts;
            } else {
                diag.push_back(where + "unknown section [" + sectionName + "] ignored");
                section = Section::Unknown;
            }
            continue;
        }

        const size_t eq = line.find('=');
        if (eq == std::string::npos) {
            diag.push_back(where + "malformed line (expected key=value): '" + line + "'");
            continue;
        }
        const std::string key = trim(line.substr(0, eq));
        const std::string value = trim(line.substr(eq + 1));
        if (key.empty()) {
            diag.push_back(where + "malformed line (empty key): '" + line + "'");
            continue;
        }
        if (section == Section::None) {
            diag.push_back(where + "key '" + key + "' outside any section ignored");
            continue;
        }
        if (section == Section::Unknown) continue;

        const std::string id = sectionName + "." + key;
        if (!seen.insert(id).second) {
            diag.push_back(where + "duplicate key '" + key + "' in [" + sectionName +
                           "]; last occurrence wins");
        }

        if (section == Section::Editor) {
            const auto it = editorFields().find(key);
            if (it == editorFields().end()) {
                diag.push_back(where + "unknown key '" + key + "' in [editor] ignored");
                continue;
            }
            const std::string err = it->second.set(cfg, value);
            if (!err.empty()) {
                it->second.reset(cfg, defaults);
                diag.push_back(where + "invalid value for '" + key + "': " + err +
                               "; using default");
            }
        } else {
            const ActionInfo* info = findActionByConfigName(key);
            if (!info) {
                diag.push_back(where + "unknown key '" + key + "' in [shortcuts] ignored");
                continue;
            }
            const ParseShortcutResult r = parseShortcut(value);
            if (!r.ok) {
                cfg.shortcuts[key] = info->defaultShortcut;
                diag.push_back(where + "invalid shortcut for '" + key + "': " + r.error +
                               "; using default");
            } else {
                cfg.shortcuts[key] = value;
            }
        }
    }
    return result;
}

std::string serializeConfig(const Config& cfg) {
    std::ostringstream os;
    os << "[editor]\n";
    for (const auto& key : editorKeyOrder()) {
        os << key << "=" << fieldValueText(cfg, key) << "\n";
    }
    os << "\n[shortcuts]\n";
    for (const auto& info : allActions()) {
        const auto it = cfg.shortcuts.find(info.configName);
        os << info.configName << "=" << (it != cfg.shortcuts.end() ? it->second : info.defaultShortcut)
           << "\n";
    }
    return os.str();
}

// --------------------------------------------------------------- discovery

Env Env::fromProcess() {
    Env e;
    std::error_code ec;
    e.cwd = fs::current_path(ec).string();
    auto get = [](const char* name) {
        const char* v = std::getenv(name);
        return std::string(v ? v : "");
    };
    e.xdgConfigHome = get("XDG_CONFIG_HOME");
    e.home = get("HOME");
    e.appData = get("APPDATA");
    return e;
}

std::vector<std::string> candidatePaths(const Env& env, bool windows) {
    std::vector<std::string> out;
    if (!env.cwd.empty()) out.push_back((fs::path(env.cwd) / "config.ini").string());
    if (windows) {
        if (!env.appData.empty()) {
            out.push_back((fs::path(env.appData) / "wedit" / "config.ini").string());
        }
    } else {
        if (!env.xdgConfigHome.empty()) {
            out.push_back((fs::path(env.xdgConfigHome) / "wedit" / "config.ini").string());
        } else if (!env.home.empty()) {
            out.push_back((fs::path(env.home) / ".config" / "wedit" / "config.ini").string());
        }
        out.push_back("/etc/wedit/config.ini");
    }
    return out;
}

namespace {

bool fileExists(const std::string& p) {
    std::error_code ec;
    return fs::is_regular_file(fs::path(p), ec);
}

bool fileReadable(const std::string& p) {
    std::ifstream f(fs::path(p), std::ios::binary);
    return f.good();
}

bool readAll(const std::string& p, std::string& out) {
    std::ifstream f(fs::path(p), std::ios::binary);
    if (!f) return false;
    std::ostringstream ss;
    ss << f.rdbuf();
    if (f.bad()) return false;
    out = ss.str();
    return true;
}

}  // namespace

LoadResult loadConfig(const std::optional<std::string>& explicitPath, const Env& env,
                      bool windows) {
    LoadResult r;
    auto parseFile = [&](const std::string& path) -> bool {
        std::string text;
        if (!readAll(path, text)) return false;
        ParseResult pr = parseConfigText(text);
        r.config = std::move(pr.config);
        for (auto& d : pr.diagnostics) r.diagnostics.push_back(path + ": " + d);
        r.sourcePath = path;
        r.usingDefaults = false;
        r.ok = true;
        return true;
    };

    if (explicitPath) {
        if (!fileExists(*explicitPath)) {
            r.error = "configuration file '" + *explicitPath + "' does not exist or is not a file";
            return r;
        }
        if (!parseFile(*explicitPath)) {
            r.error = "configuration file '" + *explicitPath + "' cannot be read";
            return r;
        }
        return r;
    }

    for (const auto& path : candidatePaths(env, windows)) {
        if (!fileExists(path)) continue;
        if (parseFile(path)) return r;
        r.diagnostics.push_back(path + ": exists but cannot be read; trying next candidate");
    }
    r.config = makeDefaults();
    r.usingDefaults = true;
    r.ok = true;
    return r;
}

std::string describeConfigSources(const std::optional<std::string>& explicitPath, const Env& env,
                                  bool windows) {
    std::ostringstream os;
    os << "Configuration search order (highest priority first):\n";
    int n = 1;
    if (explicitPath) {
        os << "  " << n++ << ". --config " << *explicitPath << "  ["
           << (fileExists(*explicitPath) ? "exists" : "missing") << ", "
           << (fileReadable(*explicitPath) ? "readable" : "not readable") << "]\n";
    }
    for (const auto& path : candidatePaths(env, windows)) {
        os << "  " << n++ << ". " << path << "  [" << (fileExists(path) ? "exists" : "missing")
           << ", " << (fileReadable(path) ? "readable" : "not readable") << "]\n";
    }
    os << "  " << n << ". built-in canonical defaults\n";
    const LoadResult r = loadConfig(explicitPath, env, windows);
    os << "Active source: ";
    if (!r.ok) {
        os << "NONE (" << r.error << ")\n";
    } else if (r.usingDefaults) {
        os << "built-in defaults are in effect\n";
    } else {
        os << r.sourcePath << "\n";
    }
    return os.str();
}

ConfigManager::ConfigManager(std::optional<std::string> explicitPath, Env env, bool windows)
    : explicit_(std::move(explicitPath)),
      env_(std::move(env)),
      windows_(windows),
      live_(makeDefaults()) {}

bool ConfigManager::reload(std::vector<std::string>* diagnostics, std::string* error) {
    LoadResult r = loadConfig(explicit_, env_, windows_);
    if (diagnostics) *diagnostics = r.diagnostics;
    if (!r.ok) {
        if (error) *error = r.error;
        return false;  // live_ untouched
    }
    live_ = std::move(r.config);
    source_ = r.usingDefaults ? std::string() : r.sourcePath;
    return true;
}

}  // namespace wedit

#include "EditorControl.h"

#include <wx/fontenum.h>

#include <algorithm>
#include <string>

#include "EditorLogic.h"
#include "Utf8Utils.h"

namespace {

wxColour toColour(const std::string& hex) {
    wxColour c;
    c.Set(wxString::FromUTF8(hex.c_str()));  // validated as #RRGGBB by the config parser
    return c;
}

wxColour blend(const wxColour& a, const wxColour& b, double t) {
    auto mix = [t](unsigned char x, unsigned char y) {
        return static_cast<unsigned char>(x + (y - x) * t + 0.5);
    };
    return wxColour(mix(a.Red(), b.Red()), mix(a.Green(), b.Green()), mix(a.Blue(), b.Blue()));
}

// Configured face if installed and fixed-width, else "Monospace", else empty
// (meaning: let wxWidgets pick its teletype family).
wxString resolveFace(const wxString& requested) {
    if (!requested.empty() && wxFontEnumerator::IsValidFacename(requested)) {
        const wxArrayString fixed = wxFontEnumerator::GetFacenames(wxFONTENCODING_SYSTEM, true);
        if (fixed.Index(requested, false) != wxNOT_FOUND) return requested;
    }
    if (wxFontEnumerator::IsValidFacename(wxS("Monospace"))) return wxS("Monospace");
    return wxString();
}

}  // namespace

EditorControl::EditorControl(wxWindow* parent, wxWindowID id)
    : wxStyledTextCtrl(parent, id, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE) {
    // Plain text only: no lexer, UTF-8 document, LF line endings.
    SetLexer(wxSTC_LEX_NULL);
    SetCodePage(wxSTC_CP_UTF8);
    SetEOLMode(wxSTC_EOL_LF);
    SetTabWidth(4);
    SetUseTabs(true);  // literal tabs are preserved, never converted
    SetViewEOL(false);
    SetViewWhiteSpace(wxSTC_WS_INVISIBLE);
    SetMarginType(0, wxSTC_MARGIN_NUMBER);
    SetMarginMask(0, 0);
    SetMarginWidth(0, 0);
    SetMarginWidth(1, 0);
    SetMarginWidth(2, 0);
    SetMarginLeft(FromDIP(6));
    SetMarginRight(FromDIP(6));
    Bind(wxEVT_STC_CHANGE, &EditorControl::OnChange, this);
}

EditorControl::ApplyReport EditorControl::ApplyConfig(const wedit::Config& cfg) {
    ApplyReport report;
    report.requestedFont = cfg.font_family;

    const wxColour fg = toColour(cfg.text_color);
    const wxColour bg = toColour(cfg.background_color);

    // --- font ---------------------------------------------------------
    const wxString face = resolveFace(wxString::FromUTF8(cfg.font_family.c_str()));
    wxFont font(cfg.font_size, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL,
                false, face);
    report.resolvedFont = std::string(font.GetFaceName().utf8_str());
    if (face.empty() || face.CmpNoCase(wxString::FromUTF8(cfg.font_family.c_str())) != 0) {
        report.warnings.push_back("font '" + cfg.font_family + "' is not an installed fixed-width " +
                                  "font; using '" + report.resolvedFont + "'");
    }

    // --- default style, then derived styles (order matters) -------------
    StyleSetFont(wxSTC_STYLE_DEFAULT, font);
    StyleSetForeground(wxSTC_STYLE_DEFAULT, fg);
    StyleSetBackground(wxSTC_STYLE_DEFAULT, bg);
    StyleClearAll();  // copies the default style to every style, incl. line numbers
    StyleSetFont(wxSTC_STYLE_LINENUMBER, font);
    StyleSetForeground(wxSTC_STYLE_LINENUMBER, toColour(cfg.line_number_color));
    StyleSetBackground(wxSTC_STYLE_LINENUMBER, toColour(cfg.gutter_background_color));

    SetSelBackground(true, blend(bg, fg, 0.28));
    SetSelForeground(false, fg);
    SetCaretForeground(fg);
    SetCaretWidth(FromDIP(2));

    // --- wrapping ------------------------------------------------------
    SetWrapMode(cfg.wordwrap ? wxSTC_WRAP_WORD : wxSTC_WRAP_NONE);
    SetScrollWidth(1);
    SetScrollWidthTracking(true);

    // --- caret ---------------------------------------------------------
    SetCaretStyle(cfg.block_cursor ? wxSTC_CARETSTYLE_BLOCK : wxSTC_CARETSTYLE_LINE);
    SetCaretPeriod(cfg.block_cursor_blink ? 500 : 0);  // 0 == steady caret

    // --- current line (whole logical line, native caret-line feature) ---
    SetCaretLineVisible(cfg.highlight_current_line);
    SetCaretLineBackground(toColour(cfg.current_line_color));
    SetCaretLineVisibleAlways(true);

    // --- line spacing: always recomputed from a zero-extra baseline -----
    SetExtraAscent(0);
    SetExtraDescent(0);
    const int natural = TextHeight(0);
    const wedit::LineSpacing spacing = wedit::computeLineSpacing(natural, cfg.line_height);
    SetExtraAscent(spacing.above);
    SetExtraDescent(spacing.below);
    if (spacing.compressionUnsupported) {
        report.warnings.push_back("line_height < 1.0 is not supported by Scintilla's global line "
                                  "metrics; using the natural line height");
    }
    if (cfg.pixels_above != 0 || cfg.pixels_below != 0) {
        report.warnings.push_back("pixels_above/pixels_below are not supported (Scintilla has no "
                                  "per-paragraph spacing); values are preserved but not applied");
    }
    if (cfg.line_distance != 0) {
        report.warnings.push_back("line_distance is not supported separately from line_height "
                                  "(Scintilla spacing is global); value preserved but not applied");
    }

    // --- line-number margin --------------------------------------------
    m_showLineNumbers = cfg.show_line_numbers;
    UpdateLineNumberMargin(true);
    return report;
}

void EditorControl::UpdateLineNumberMargin(bool force) {
    if (!m_showLineNumbers) {
        if (GetMarginWidth(0) != 0) SetMarginWidth(0, 0);  // space is reclaimed
        m_lastLineCount = -1;
        return;
    }
    const int lines = GetLineCount();  // logical lines, never wrapped rows
    if (!force && lines == m_lastLineCount && GetMarginWidth(0) != 0) return;
    m_lastLineCount = lines;
    const int digitWidth = TextWidth(wxSTC_STYLE_LINENUMBER, wxS("9"));
    SetMarginWidth(0, wedit::lineNumberMarginWidth(lines, digitWidth, FromDIP(4)));
}

void EditorControl::OnChange(wxStyledTextEvent& event) {
    UpdateLineNumberMargin(false);
    event.Skip();
}

void EditorControl::LoadUtf8(const std::string& text) {
    SetUndoCollection(false);  // loading must not create undo steps
    ClearAll();
    SetTextRaw(text.c_str());  // text is validated and contains no NUL
    SetUndoCollection(true);
    EmptyUndoBuffer();         // the previous document's history must not survive
    SetSavePoint();
    GotoPos(0);
    EnsureCaretVisible();
    UpdateLineNumberMargin(true);
}

std::string EditorControl::GetUtf8() {
    const int length = GetLength();  // bytes
    if (length <= 0) return std::string();
    const wxCharBuffer buf = GetTextRaw();
    return std::string(buf.data(), static_cast<size_t>(length));
}

int EditorControl::LogicalLine() { return LineFromPosition(GetCurrentPos()) + 1; }

int EditorControl::UnicodeColumn() {
    const int pos = GetCurrentPos();
    const int start = PositionFromLine(LineFromPosition(pos));
    if (pos <= start) return 1;
    const wxCharBuffer prefix = GetTextRangeRaw(start, pos);  // bytes, not characters
    return wedit::unicodeColumn(std::string_view(prefix.data(), static_cast<size_t>(pos - start)));
}

void EditorControl::ReleaseAppShortcuts(const std::vector<wedit::Shortcut>& shortcuts) {
    const int ctrl = wxSTC_KEYMOD_CTRL;
    // Standard edit keys always go through the application's single command path.
    for (int key : {'Z', 'Y', 'X', 'C', 'V'}) CmdKeyClear(key, ctrl);
    CmdKeyClear('Z', ctrl | wxSTC_KEYMOD_SHIFT);
    CmdKeyClear(wxSTC_KEY_DELETE, wxSTC_KEYMOD_SHIFT);
    CmdKeyClear(wxSTC_KEY_INSERT, wxSTC_KEYMOD_SHIFT);
    CmdKeyClear(wxSTC_KEY_INSERT, ctrl);

    for (const wedit::Shortcut& s : shortcuts) {
        int mods = 0;
        if (s.ctrl) mods |= wxSTC_KEYMOD_CTRL;
        if (s.shift) mods |= wxSTC_KEYMOD_SHIFT;
        if (s.alt) mods |= wxSTC_KEYMOD_ALT;
        switch (s.kind) {
            case wedit::KeyKind::Char:
                CmdKeyClear(s.value, mods);
                break;
            case wedit::KeyKind::Plus:
                CmdKeyClear(wxSTC_KEY_ADD, mods);  // Ctrl+KeypadPlus would zoom
                break;
            case wedit::KeyKind::Minus:
                CmdKeyClear(wxSTC_KEY_SUBTRACT, mods);
                break;
            default:
                break;
        }
    }
}

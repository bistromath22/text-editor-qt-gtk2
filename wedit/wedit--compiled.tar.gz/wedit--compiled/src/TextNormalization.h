// Newline normalization: the single place where CRLF / CR become LF.
#pragma once

#include <string>
#include <string_view>

namespace wedit {

// CRLF -> one LF, remaining CR -> LF, LF unchanged. Every other byte,
// including leading/trailing/repeated newlines, is preserved exactly.
std::string normalizeNewlines(std::string_view input);

}  // namespace wedit

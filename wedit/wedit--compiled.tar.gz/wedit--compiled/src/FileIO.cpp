#include "FileIO.h"

#include <cerrno>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>

#include "TextNormalization.h"
#include "Utf8Utils.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdlib>
#endif

namespace fs = std::filesystem;

namespace wedit {

namespace {

std::string errnoText(int e) { return std::strerror(e); }

#ifdef _WIN32
std::wstring widen(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, utf8.data(),
                                      static_cast<int>(utf8.size()), nullptr, 0);
    if (n <= 0) return std::wstring();
    std::wstring w(static_cast<size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, utf8.data(), static_cast<int>(utf8.size()),
                        &w[0], n);
    return w;
}

std::string winErrorText(DWORD code) {
    return "Windows error " + std::to_string(static_cast<unsigned long>(code));
}
#endif

}  // namespace

ReadResult readTextFile(const std::string& path) {
    ReadResult r;
    std::error_code ec;
    const fs::path p = fs::u8path(path);
    if (path.empty()) {
        r.error = "no file name given";
        return r;
    }
    if (!fs::exists(p, ec)) {
        r.error = "file '" + path + "' does not exist";
        return r;
    }
    if (fs::is_directory(p, ec)) {
        r.error = "'" + path + "' is a directory, not a file";
        return r;
    }
    std::ifstream in(p, std::ios::binary);
    if (!in) {
        r.error = "cannot open '" + path + "' for reading: " + errnoText(errno);
        return r;
    }
    std::ostringstream buf;
    buf << in.rdbuf();
    if (in.bad()) {
        r.error = "read error while reading '" + path + "'";
        return r;
    }
    const std::string bytes = buf.str();

    std::string_view view(bytes);
    r.hadBom = hasUtf8Bom(view);
    view = stripUtf8Bom(view);

    size_t bad = 0;
    if (!isValidUtf8(view, &bad)) {
        r.error = "'" + path + "' is not valid UTF-8 (first invalid sequence at byte " +
                  std::to_string(bad + (r.hadBom ? 3 : 0)) + ")";
        return r;
    }
    if (containsNul(view)) {
        r.error = "'" + path + "' contains NUL bytes, which wedit does not support";
        return r;
    }
    r.text = normalizeNewlines(view);
    r.ok = true;
    return r;
}

#ifdef _WIN32

WriteResult writeFileAtomic(const std::string& path, const std::string& bytes) {
    WriteResult res;
    const std::wstring dest = widen(path);
    if (dest.empty()) {
        res.error = "invalid path '" + path + "'";
        return res;
    }
    const fs::path destPath(dest);
    fs::path dir = destPath.parent_path();
    if (dir.empty()) dir = L".";

    std::wstring tmp;
    HANDLE h = INVALID_HANDLE_VALUE;
    for (int attempt = 0; attempt < 16 && h == INVALID_HANDLE_VALUE; ++attempt) {
        tmp = (dir / (L".wedit-" + std::to_wstring(GetCurrentProcessId()) + L"-" +
                      std::to_wstring(GetTickCount64()) + L"-" + std::to_wstring(attempt) + L".tmp"))
                  .wstring();
        h = CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW,
                        FILE_ATTRIBUTE_NORMAL, nullptr);
    }
    if (h == INVALID_HANDLE_VALUE) {
        res.error = "cannot create temporary file next to '" + path + "': " +
                    winErrorText(GetLastError());
        return res;
    }
    auto cleanup = [&]() {
        if (h != INVALID_HANDLE_VALUE) CloseHandle(h);
        h = INVALID_HANDLE_VALUE;
        DeleteFileW(tmp.c_str());
    };

    size_t off = 0;
    while (off < bytes.size()) {
        const DWORD chunk = static_cast<DWORD>(std::min<size_t>(bytes.size() - off, 1u << 20));
        DWORD written = 0;
        if (!WriteFile(h, bytes.data() + off, chunk, &written, nullptr) || written == 0) {
            res.error = "write failed for '" + path + "': " + winErrorText(GetLastError());
            cleanup();
            return res;
        }
        off += written;
    }
    if (!FlushFileBuffers(h)) {
        res.error = "flush failed for '" + path + "': " + winErrorText(GetLastError());
        cleanup();
        return res;
    }
    CloseHandle(h);
    h = INVALID_HANDLE_VALUE;
    if (!MoveFileExW(tmp.c_str(), dest.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        res.error = "cannot replace '" + path + "': " + winErrorText(GetLastError());
        DeleteFileW(tmp.c_str());
        return res;
    }
    res.ok = true;
    return res;
}

#else  // POSIX

WriteResult writeFileAtomic(const std::string& path, const std::string& bytes) {
    WriteResult res;
    if (path.empty()) {
        res.error = "no file name given";
        return res;
    }
    const fs::path destPath(path);
    fs::path dir = destPath.parent_path();
    if (dir.empty()) dir = ".";

    std::error_code ec;
    if (!fs::is_directory(dir, ec)) {
        res.error = "directory '" + dir.string() + "' does not exist";
        return res;
    }

    mode_t mode = 0644;
    struct stat st;
    if (::stat(path.c_str(), &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            res.error = "'" + path + "' is a directory";
            return res;
        }
        mode = st.st_mode & 07777;
    }

    std::string tmpl = (dir / ".wedit-XXXXXX").string();
    std::string tmpName(tmpl.begin(), tmpl.end());
    tmpName.push_back('\0');
    const int fd = ::mkstemp(&tmpName[0]);
    if (fd < 0) {
        res.error = "cannot create temporary file in '" + dir.string() + "': " + errnoText(errno);
        return res;
    }
    tmpName.pop_back();

    auto fail = [&](const std::string& msg, int err) {
        res.error = msg + ": " + errnoText(err);
        ::close(fd);
        ::unlink(tmpName.c_str());
        return res;
    };

    size_t off = 0;
    while (off < bytes.size()) {
        const ssize_t n = ::write(fd, bytes.data() + off, bytes.size() - off);
        if (n < 0) {
            if (errno == EINTR) continue;
            return fail("write failed for '" + path + "'", errno);
        }
        off += static_cast<size_t>(n);
    }
    if (::fchmod(fd, mode) != 0) {
        // Not fatal on filesystems without mode support; the data is what matters.
    }
    if (::fsync(fd) != 0) return fail("fsync failed for '" + path + "'", errno);
    if (::close(fd) != 0) {
        const int e = errno;
        ::unlink(tmpName.c_str());
        res.error = "close failed for '" + path + "': " + errnoText(e);
        return res;
    }
    if (::rename(tmpName.c_str(), path.c_str()) != 0) {
        const int e = errno;
        ::unlink(tmpName.c_str());
        res.error = "cannot replace '" + path + "': " + errnoText(e);
        return res;
    }
    res.ok = true;
    return res;
}

#endif

ReadResult loadDocument(DocumentFile& doc, std::string& text, const std::string& path) {
    ReadResult r = readTextFile(path);
    if (!r.ok) return r;  // nothing touched
    text = r.text;
    doc.path = path;
    doc.clean = true;
    return r;
}

WriteResult saveDocument(DocumentFile& doc, const std::string& target, const std::string& text) {
    WriteResult w = writeFileAtomic(target, text);
    if (!w.ok) return w;  // path and clean state unchanged
    doc.path = target;
    doc.clean = true;
    return w;
}

}  // namespace wedit

// Parses GTK-style accelerator spellings ("<Primary><Shift>s", "F3",
// "<Primary>plus") into a toolkit-neutral Shortcut, resolves collisions and
// renders display labels. Mapping to wxAcceleratorEntry happens in MainFrame.
#pragma once

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "AppActions.h"

namespace wedit {

enum class KeyKind { None, Char, Function, Plus, Minus };

struct Shortcut {
    bool ctrl = false;  // <Primary> / <Control> / <Ctrl>
    bool shift = false;
    bool alt = false;
    KeyKind kind = KeyKind::None;
    int value = 0;  // Char: upper-case ASCII code; Function: 1..24

    bool operator==(const Shortcut& o) const {
        return ctrl == o.ctrl && shift == o.shift && alt == o.alt && kind == o.kind &&
               value == o.value;
    }
    bool operator<(const Shortcut& o) const {
        return std::tie(ctrl, shift, alt, kind, value) <
               std::tie(o.ctrl, o.shift, o.alt, o.kind, o.value);
    }
    // Display label such as "Ctrl+Shift+S", "F3", "Ctrl++", "Ctrl+-".
    std::string label() const;
    // True when the key is rendered through "Plus"/"Minus" (which need
    // several physical key codes and are registered via an accelerator table).
    bool isPlusOrMinus() const { return kind == KeyKind::Plus || kind == KeyKind::Minus; }
};

struct ParseShortcutResult {
    bool ok = false;
    Shortcut shortcut;
    std::string error;
};

ParseShortcutResult parseShortcut(const std::string& spelling);

struct ResolvedShortcuts {
    // One entry per action that has an active binding (table order).
    std::vector<std::pair<Action, Shortcut>> bindings;
    std::vector<std::string> diagnostics;

    const Shortcut* find(Action a) const;
};

// `configured` maps config names ([shortcuts] keys) to spellings; missing keys
// use the compiled-in default. Policy:
//  * invalid spelling  -> the action's default (diagnostic);
//  * duplicate binding -> the first action in table order keeps the key; a
//    later action falls back to its own default if that is free, otherwise it
//    is left unbound (it stays reachable from the menu) (diagnostic).
ResolvedShortcuts resolveShortcuts(const std::map<std::string, std::string>& configured);

}  // namespace wedit

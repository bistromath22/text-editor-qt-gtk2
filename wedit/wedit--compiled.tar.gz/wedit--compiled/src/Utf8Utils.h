// Strict UTF-8 helpers. Scintilla positions are byte offsets; these helpers
// convert between bytes and Unicode code points without splitting characters.
#pragma once

#include <cstddef>
#include <string>
#include <string_view>

namespace wedit {

// Strict validation: rejects overlong forms, surrogates, > U+10FFFF,
// truncated and stray continuation bytes. On failure, *badOffset (if given)
// receives the byte offset of the first offending sequence.
bool isValidUtf8(std::string_view s, size_t* badOffset = nullptr);

bool hasUtf8Bom(std::string_view s);
// Removes exactly one BOM, and only at the very start.
std::string_view stripUtf8Bom(std::string_view s);

bool containsNul(std::string_view s);

// Number of code points in VALID UTF-8 (combining marks count separately).
size_t countCodePoints(std::string_view s);

// True when pos is 0, size(), or the start of a code point.
bool isCodePointBoundary(std::string_view s, size_t pos);

// Largest boundary <= pos / smallest boundary >= pos.
size_t floorToBoundary(std::string_view s, size_t pos);
size_t ceilToBoundary(std::string_view s, size_t pos);

// Byte offset reached after advancing n code points from the start
// (clamped to s.size()).
size_t byteOffsetOfCodePoint(std::string_view s, size_t n);

}  // namespace wedit

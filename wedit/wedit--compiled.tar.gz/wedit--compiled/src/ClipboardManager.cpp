#include "ClipboardManager.h"

#include <wx/clipbrd.h>
#include <wx/dataobj.h>
#include <wx/stc/stc.h>
#include <wx/string.h>

#include <string>

#include "TextNormalization.h"

namespace wedit {

namespace {

// Ensures EndUndoAction() runs on every exit path.
class UndoGroup {
public:
    explicit UndoGroup(wxStyledTextCtrl* ed) : ed_(ed) { ed_->BeginUndoAction(); }
    ~UndoGroup() { ed_->EndUndoAction(); }
    UndoGroup(const UndoGroup&) = delete;
    UndoGroup& operator=(const UndoGroup&) = delete;

private:
    wxStyledTextCtrl* ed_;
};

bool setClipboardText(const wxString& text) {
    wxClipboardLocker locker;  // closes the clipboard on scope exit
    if (!locker) return false;
    if (!wxTheClipboard->SetData(new wxTextDataObject(text))) return false;
    wxTheClipboard->Flush();
    return true;
}

bool getClipboardText(wxString& out) {
    wxClipboardLocker locker;
    if (!locker) return false;
    if (!wxTheClipboard->IsSupported(wxDF_UNICODETEXT)) return false;  // non-text data: ignore
    wxTextDataObject data;
    if (!wxTheClipboard->GetData(data)) return false;
    out = data.GetText();
    return true;
}

}  // namespace

bool ClipboardManager::Copy(wxStyledTextCtrl* editor) {
    const wxString sel = editor->GetSelectedText();
    if (sel.empty()) return true;  // nothing selected: documented no-op
    return setClipboardText(sel);
}

bool ClipboardManager::Cut(wxStyledTextCtrl* editor) {
    const wxString sel = editor->GetSelectedText();
    if (sel.empty()) return true;
    if (!setClipboardText(sel)) return false;  // keep the text if the clipboard refused it
    UndoGroup group(editor);
    editor->ReplaceSelection(wxString());
    editor->EnsureCaretVisible();
    return true;
}

bool ClipboardManager::Paste(wxStyledTextCtrl* editor) {
    wxString raw;
    if (!getClipboardText(raw)) return false;
    if (raw.empty()) return true;

    const wxScopedCharBuffer utf8 = raw.utf8_str();
    if (utf8.length() == 0) return false;  // conversion failed
    const std::string normalized = normalizeNewlines(std::string_view(utf8.data(), utf8.length()));
    const wxString text = wxString::FromUTF8(normalized.data(), normalized.size());
    if (text.empty() && !normalized.empty()) return false;

    UndoGroup group(editor);  // one undo step for the whole multi-line paste
    editor->ReplaceSelection(text);  // replaces the selection, caret ends after the insert
    editor->EnsureCaretVisible();
    return true;
}

}  // namespace wedit

#include "MainFrame.h"

#include <wx/accel.h>
#include <wx/filedlg.h>
#include <wx/filename.h>
#include <wx/msgdlg.h>
#include <wx/stc/stc.h>
#include <wx/textdlg.h>

#include <algorithm>
#include <cstdio>
#include <vector>

#include "ClipboardManager.h"
#include "EditorControl.h"
#include "EditorLogic.h"
#include "FileIO.h"

using wedit::Action;

namespace {

constexpr int kFirstCommandId = wxID_HIGHEST + 100;

int commandId(Action a) { return kFirstCommandId + wedit::actionIndex(a); }

Action actionFromId(int id) { return static_cast<Action>(id - kFirstCommandId); }

wxString fromStd(const std::string& s) { return wxString::FromUTF8(s.c_str()); }

std::string toStd(const wxString& s) {
    const wxScopedCharBuffer b = s.utf8_str();
    return std::string(b.data(), b.length());
}

wxColour colour(const std::string& hex) {
    wxColour c;
    c.Set(fromStd(hex));
    return c;
}

void logLine(const std::string& s) { std::fprintf(stderr, "wedit: %s\n", s.c_str()); }

void showError(wxWindow* parent, const std::string& message) {
    wxMessageBox(fromStd(message), wxS("wedit"), wxOK | wxICON_ERROR, parent);
}

}  // namespace

MainFrame::MainFrame(wedit::ConfigManager config, const std::string& initialFile)
    : wxFrame(nullptr, wxID_ANY, wxS("wedit"), wxDefaultPosition, wxSize(900, 600)),
      m_cfg(std::move(config)),
      m_active(m_cfg.live()) {
    SetMinSize(FromDIP(wxSize(400, 300)));
    BuildLayout();
    BuildMenus();

    Bind(wxEVT_MENU, &MainFrame::OnCommand, this, kFirstCommandId,
         kFirstCommandId + static_cast<int>(wedit::allActions().size()) - 1);
    Bind(wxEVT_CLOSE_WINDOW, &MainFrame::OnClose, this);
    m_editor->Bind(wxEVT_STC_UPDATEUI, &MainFrame::OnUpdateUI, this);
    m_editor->Bind(wxEVT_STC_SAVEPOINTREACHED, &MainFrame::OnSavePointChanged, this);
    m_editor->Bind(wxEVT_STC_SAVEPOINTLEFT, &MainFrame::OnSavePointChanged, this);

    RebuildShortcuts();
    ApplyAll();
    m_editor->LoadUtf8(std::string());

    if (!initialFile.empty()) {
        // If the first file fails we stay on an empty document; later files
        // are never silently substituted (single-document policy).
        OpenPath(fromStd(initialFile));
    }
    UpdateTitle();
    m_editor->SetFocus();
}

// ------------------------------------------------------------------ layout

void MainFrame::BuildLayout() {
    m_root = new wxBoxSizer(wxVERTICAL);

    // The border panel owns border_color; the editor is inset inside it by
    // border_size. The status row lives outside it and is never "border".
    m_borderPanel = new wxPanel(this, wxID_ANY);
    m_borderSizer = new wxBoxSizer(wxVERTICAL);
    m_editor = new EditorControl(m_borderPanel, wxID_ANY);
    m_borderSizer->Add(m_editor, 1, wxEXPAND | wxALL, 0);
    m_borderPanel->SetSizer(m_borderSizer);

    m_statusPanel = new wxPanel(this, wxID_ANY);
    auto* statusSizer = new wxBoxSizer(wxHORIZONTAL);
    m_statusText = new wxStaticText(m_statusPanel, wxID_ANY, wxS("Ln 1, Col 1"));
    statusSizer->Add(m_statusText, 1, wxALIGN_CENTER_VERTICAL | wxLEFT | wxRIGHT | wxTOP | wxBOTTOM,
                     FromDIP(4));
    m_statusPanel->SetSizer(statusSizer);

    m_root->Add(m_borderPanel, 1, wxEXPAND);
    m_root->Add(m_statusPanel, 0, wxEXPAND);
    SetSizer(m_root);
}

void MainFrame::BuildMenus() {
    auto* bar = new wxMenuBar();
    auto addItem = [this](wxMenu* menu, Action a) {
        wxMenuItem* item = menu->Append(commandId(a), fromStd(wedit::infoFor(a).menuLabel));
        m_items[a] = item;
    };

    auto* file = new wxMenu();
    for (Action a : {Action::NewFile, Action::Open, Action::Save, Action::SaveAs}) addItem(file, a);
    file->AppendSeparator();
    addItem(file, Action::Quit);

    auto* edit = new wxMenu();
    addItem(edit, Action::Undo);
    addItem(edit, Action::Redo);
    edit->AppendSeparator();
    for (Action a : {Action::Cut, Action::Copy, Action::Paste}) addItem(edit, a);
    edit->AppendSeparator();
    for (Action a : {Action::Find, Action::FindNext, Action::GotoLine}) addItem(edit, a);
    edit->AppendSeparator();
    for (Action a : {Action::ReloadConfig, Action::ToggleWordWrap, Action::ToggleBlockCursor,
                     Action::IncreaseFont, Action::DecreaseFont}) {
        addItem(edit, a);
    }

    auto* view = new wxMenu();
    for (Action a : {Action::FullScreen, Action::ToggleLineNumbers, Action::ToggleCurrentLine,
                     Action::ToggleStatusBar}) {
        addItem(view, a);
    }

    bar->Append(file, wxS("&File"));
    bar->Append(edit, wxS("&Edit"));
    bar->Append(view, wxS("&View"));
    SetMenuBar(bar);
}

// ----------------------------------------------------------------- shortcuts

void MainFrame::RebuildShortcuts() {
    // Validate the complete candidate first; only then touch menus/accelerators.
    wedit::ResolvedShortcuts resolved = wedit::resolveShortcuts(m_active.shortcuts);
    for (const auto& d : resolved.diagnostics) logLine(d);
    m_shortcuts = std::move(resolved);

    std::vector<wxAcceleratorEntry> entries;
    std::vector<wedit::Shortcut> all;
    for (const auto& info : wedit::allActions()) {
        const Action a = info.action;
        wxMenuItem* item = m_items[a];
        wxString label = fromStd(info.menuLabel);
        const wedit::Shortcut* sc = m_shortcuts.find(a);
        if (sc) {
            all.push_back(*sc);
            if (sc->isPlusOrMinus()) {
                // Plus/minus need several physical keys; they are registered
                // through the accelerator table and only *shown* in the label.
                label += wxS(" (") + fromStd(sc->label()) + wxS(")");
                int flags = wxACCEL_NORMAL;
                if (sc->ctrl) flags |= wxACCEL_CTRL;
                if (sc->alt) flags |= wxACCEL_ALT;
                const int shiftFlags = flags | wxACCEL_SHIFT;
                const int base = sc->shift ? shiftFlags : flags;
                const int id = commandId(a);
                if (sc->kind == wedit::KeyKind::Plus) {
                    entries.emplace_back(base, static_cast<int>('+'), id);
                    entries.emplace_back(shiftFlags, static_cast<int>('+'), id);  // Shift+= layouts
                    entries.emplace_back(base, static_cast<int>('='), id);        // unshifted '='
                    entries.emplace_back(base, static_cast<int>(WXK_NUMPAD_ADD), id);
                } else {
                    entries.emplace_back(base, static_cast<int>('-'), id);
                    entries.emplace_back(base, static_cast<int>(WXK_NUMPAD_SUBTRACT), id);
                }
            } else {
                label += wxS("\t") + fromStd(sc->label());  // wx registers this accelerator
            }
        }
        item->SetItemLabel(label);
    }
    SetAcceleratorTable(entries.empty() ? wxAcceleratorTable()
                                        : wxAcceleratorTable(static_cast<int>(entries.size()),
                                                             entries.data()));
    m_editor->ReleaseAppShortcuts(all);
}

// -------------------------------------------------------------- presentation

void MainFrame::ApplyAll() {
    const EditorControl::ApplyReport report = m_editor->ApplyConfig(m_active);
    logLine("font requested '" + report.requestedFont + "', resolved '" + report.resolvedFont + "'");
    for (const auto& w : report.warnings) logLine("warning: " + w);

    m_borderPanel->SetBackgroundColour(colour(m_active.border_color));
    if (wxSizerItem* item = m_borderSizer->GetItem(m_editor)) {
        item->SetBorder(FromDIP(m_active.border_size));  // DIP-aware surround
    }
    m_statusPanel->SetBackgroundColour(colour(m_active.gutter_background_color));
    m_statusText->SetBackgroundColour(colour(m_active.gutter_background_color));
    m_statusText->SetForegroundColour(colour(m_active.text_color));

    m_root->Show(m_statusPanel, m_active.show_statusbar);  // hidden == no space reserved
    m_borderPanel->Refresh();
    Layout();
    UpdateStatus();
}

void MainFrame::ReloadConfig() {
    std::vector<std::string> diags;
    std::string error;
    if (!m_cfg.reload(&diags, &error)) {
        showError(this, "Configuration not reloaded: " + error +
                            "\nThe previous settings remain active.");
        return;
    }
    for (const auto& d : diags) logLine(d);

    const int firstLine = m_editor->GetFirstVisibleLine();
    m_active = m_cfg.live();
    RebuildShortcuts();
    ApplyAll();
    m_editor->SetFirstVisibleLine(firstLine);  // text, caret, selection and undo are untouched
}

void MainFrame::ChangeFontSize(int delta) {
    const int next = m_active.font_size + delta;
    if (next < wedit::kMinFontSize || next > wedit::kMaxFontSize) return;
    m_active.font_size = next;
    ApplyAll();
}

// ------------------------------------------------------------------ commands

void MainFrame::OnCommand(wxCommandEvent& event) { Dispatch(actionFromId(event.GetId())); }

void MainFrame::Dispatch(Action action) {
    switch (action) {
        case Action::NewFile:
            NewDocument();
            break;
        case Action::Open: {
            wxFileDialog dlg(this, wxS("Open"), wxEmptyString, wxEmptyString,
                             wxS("Text files (*.txt)|*.txt|All files|") +
                                 wxString(wxFileSelectorDefaultWildcardStr),
                             wxFD_OPEN | wxFD_FILE_MUST_EXIST);
            if (dlg.ShowModal() == wxID_OK) OpenPath(dlg.GetPath());
            break;
        }
        case Action::Save:
            DoSave();
            break;
        case Action::SaveAs:
            DoSaveAs();
            break;
        case Action::Quit:
            Close();  // goes through OnClose and the unsaved-change prompt
            break;
        case Action::Undo:
            if (m_editor->CanUndo()) m_editor->Undo();
            break;
        case Action::Redo:
            if (m_editor->CanRedo()) m_editor->Redo();
            break;
        case Action::Cut:
            if (!wedit::ClipboardManager::Cut(m_editor)) {
                showError(this, "The clipboard is unavailable; the selection was not cut.");
            }
            break;
        case Action::Copy:
            if (!wedit::ClipboardManager::Copy(m_editor)) {
                showError(this, "The clipboard is unavailable; nothing was copied.");
            }
            break;
        case Action::Paste:
            if (!wedit::ClipboardManager::Paste(m_editor)) {
                showError(this, "There is no plain text on the clipboard, or it cannot be read.");
            }
            break;
        case Action::Find: {
            wxTextEntryDialog dlg(this, wxS("Find:"), wxS("Find"), m_lastFind);
            if (dlg.ShowModal() != wxID_OK) break;
            m_lastFind = dlg.GetValue();
            DoFind(false);
            break;
        }
        case Action::FindNext:
            if (m_lastFind.empty()) {
                Dispatch(Action::Find);
            } else {
                DoFind(true);
            }
            break;
        case Action::GotoLine:
            DoGotoLine();
            break;
        case Action::ReloadConfig:
            ReloadConfig();
            break;
        case Action::ToggleWordWrap:
            m_active.wordwrap = !m_active.wordwrap;
            ApplyAll();
            break;
        case Action::ToggleBlockCursor:
            m_active.block_cursor = !m_active.block_cursor;
            ApplyAll();
            break;
        case Action::IncreaseFont:
            ChangeFontSize(+1);
            break;
        case Action::DecreaseFont:
            ChangeFontSize(-1);
            break;
        case Action::FullScreen:
            ShowFullScreen(!IsFullScreen(), wxFULLSCREEN_NOTOOLBAR | wxFULLSCREEN_NOSTATUSBAR |
                                                wxFULLSCREEN_NOBORDER | wxFULLSCREEN_NOCAPTION);
            m_editor->SetFocus();
            break;
        case Action::ToggleLineNumbers:
            m_active.show_line_numbers = !m_active.show_line_numbers;
            ApplyAll();
            break;
        case Action::ToggleCurrentLine:
            m_active.highlight_current_line = !m_active.highlight_current_line;
            ApplyAll();
            break;
        case Action::ToggleStatusBar:
            m_active.show_statusbar = !m_active.show_statusbar;
            ApplyAll();
            break;
    }
}

// --------------------------------------------------------------- file workflow

bool MainFrame::ConfirmDiscard() {
    if (!m_editor->GetModify()) return true;
    wxMessageDialog dlg(this, wxS("The document has unsaved changes."), wxS("wedit"),
                        wxYES_NO | wxCANCEL | wxICON_QUESTION);
    dlg.SetYesNoCancelLabels(wxS("Save"), wxS("Discard"), wxS("Cancel"));
    switch (dlg.ShowModal()) {
        case wxID_YES:
            return DoSave();  // proceed only if the save really succeeded
        case wxID_NO:
            return true;
        default:
            return false;
    }
}

void MainFrame::NewDocument() {
    if (!ConfirmDiscard()) return;
    m_editor->LoadUtf8(std::string());
    m_path.clear();
    UpdateTitle();
    UpdateStatus();
}

bool MainFrame::OpenPath(const wxString& path) {
    // Read, validate and normalise first; the active document is untouched
    // until that has fully succeeded.
    const wedit::ReadResult read = wedit::readTextFile(toStd(path));
    if (!read.ok) {
        showError(this, read.error);
        return false;
    }
    if (!ConfirmDiscard()) return false;
    m_editor->LoadUtf8(read.text);
    m_path = path;
    UpdateTitle();
    UpdateStatus();
    return true;
}

bool MainFrame::DoWrite(const wxString& path) {
    const wedit::WriteResult w = wedit::writeFileAtomic(toStd(path), m_editor->GetUtf8());
    if (!w.ok) {
        showError(this, "Could not save: " + w.error);  // path and dirty state unchanged
        return false;
    }
    m_editor->SetSavePoint();
    m_path = path;
    UpdateTitle();
    return true;
}

bool MainFrame::DoSave() {
    if (m_path.empty()) return DoSaveAs();
    return DoWrite(m_path);
}

bool MainFrame::DoSaveAs() {
    wxFileDialog dlg(this, wxS("Save As"), m_path.empty() ? wxString() : wxFileName(m_path).GetPath(),
                     m_path.empty() ? wxString() : wxFileName(m_path).GetFullName(),
                     wxS("Text files (*.txt)|*.txt|All files|") +
                         wxString(wxFileSelectorDefaultWildcardStr),
                     wxFD_SAVE | wxFD_OVERWRITE_PROMPT);
    if (dlg.ShowModal() != wxID_OK) return false;
    return DoWrite(dlg.GetPath());
}

void MainFrame::OnClose(wxCloseEvent& event) {
    if (event.CanVeto() && !ConfirmDiscard()) {
        event.Veto();
        return;
    }
    Destroy();
}

// ------------------------------------------------------------- search / goto

void MainFrame::DoFind(bool fromSelectionEnd) {
    if (m_lastFind.empty()) return;
    const int length = m_editor->GetLength();
    const int start = fromSelectionEnd ? m_editor->GetSelectionEnd() : m_editor->GetCurrentPos();
    const int needleBytes = static_cast<int>(toStd(m_lastFind).size());

    m_editor->SetSearchFlags(0);  // case-insensitive (ASCII folding), plain text
    m_editor->SetTargetStart(start);
    m_editor->SetTargetEnd(length);
    int pos = m_editor->SearchInTarget(m_lastFind);
    bool wrapped = false;
    if (pos < 0) {  // wrap once
        m_editor->SetTargetStart(0);
        m_editor->SetTargetEnd(std::min(length, start + needleBytes));
        pos = m_editor->SearchInTarget(m_lastFind);
        wrapped = pos >= 0;
    }
    if (pos < 0) {
        wxMessageBox(wxS("Not found: ") + m_lastFind, wxS("Find"), wxOK | wxICON_INFORMATION, this);
        return;  // selection and caret untouched
    }
    m_editor->SetSelection(m_editor->GetTargetStart(), m_editor->GetTargetEnd());
    m_editor->EnsureCaretVisible();
    if (wrapped) UpdateStatus(wxS("Search wrapped"));
}

void MainFrame::DoGotoLine() {
    const int lineCount = m_editor->GetLineCount();  // logical lines
    wxTextEntryDialog dlg(this, wxString::Format(wxS("Line number (1-%d):"), lineCount),
                          wxS("Go to Line"));
    if (dlg.ShowModal() != wxID_OK) return;
    const wedit::GotoResult r = wedit::parseGotoLine(toStd(dlg.GetValue()), lineCount);
    if (!r.ok) {
        wxMessageBox(fromStd(r.error), wxS("Go to Line"), wxOK | wxICON_INFORMATION, this);
        return;  // cursor unchanged
    }
    m_editor->GotoLine(r.line - 1);
    m_editor->EnsureCaretVisible();
}

// ------------------------------------------------------------- title / status

void MainFrame::UpdateTitle() {
    wxString name = m_path.empty() ? wxString(wxS("Untitled")) : wxFileName(m_path).GetFullName();
    wxString title = wxString::FromUTF8("wedit \xE2\x80\x94 ") + name;
    if (m_editor->GetModify()) title += wxS(" [modified]");
    SetTitle(title);
}

void MainFrame::UpdateStatus(const wxString& note) {
    if (!m_active.show_statusbar) return;
    wxString text = wxString::Format(wxS("Ln %d, Col %d"), m_editor->LogicalLine(),
                                     m_editor->UnicodeColumn());
    if (!note.empty()) text = note + wxS("  |  ") + text;
    m_statusText->SetLabel(text);
}

void MainFrame::OnUpdateUI(wxStyledTextEvent& event) {
    UpdateStatus();
    event.Skip();
}

void MainFrame::OnSavePointChanged(wxStyledTextEvent& event) {
    UpdateTitle();
    event.Skip();
}

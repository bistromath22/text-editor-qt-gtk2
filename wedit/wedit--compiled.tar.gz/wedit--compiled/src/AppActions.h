// Registry of every user-visible command. This table is the single source of
// truth for action names, labels and default shortcuts; the config defaults,
// the shortcut resolver, the menus and the dispatcher all derive from it.
#pragma once

#include <string>
#include <vector>

namespace wedit {

// Enumerator order == order of keys in the [shortcuts] section of config.ini.
// ToggleBlockCursor is the built-in extra and therefore last.
enum class Action {
    NewFile,
    Open,
    Save,
    SaveAs,
    Quit,
    Undo,
    Redo,
    Cut,
    Copy,
    Paste,
    Find,
    FindNext,
    GotoLine,
    ReloadConfig,
    ToggleWordWrap,
    IncreaseFont,
    DecreaseFont,
    FullScreen,
    ToggleLineNumbers,
    ToggleCurrentLine,
    ToggleStatusBar,
    ToggleBlockCursor,
};

struct ActionInfo {
    Action action;
    const char* configName;       // key in [shortcuts]
    const char* menuLabel;        // label without accelerator text
    const char* defaultShortcut;  // GTK-style spelling
    bool inSuppliedConfig;        // false for built-in extras
};

const std::vector<ActionInfo>& allActions();
const ActionInfo& infoFor(Action a);
const ActionInfo* findActionByConfigName(const std::string& name);

// Stable integer used as the wx command id offset.
inline int actionIndex(Action a) { return static_cast<int>(a); }

}  // namespace wedit

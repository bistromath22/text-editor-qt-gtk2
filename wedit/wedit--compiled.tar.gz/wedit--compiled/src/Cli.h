// Command-line parsing. Pure std code so --help/--version/--print-config*
// work without initialising wxWidgets or needing a display.
#pragma once

#include <optional>
#include <string>
#include <vector>

namespace wedit {

enum class CliAction { Run, Help, Version, PrintConfig, PrintConfigPaths, Error };

struct CliOptions {
    CliAction action = CliAction::Run;
    std::optional<std::string> configPath;
    std::vector<std::string> files;     // as given
    std::vector<std::string> warnings;  // e.g. extra files ignored
    std::string error;
};

// args excludes argv[0].
CliOptions parseCli(const std::vector<std::string>& args);

std::string helpText();
std::string versionText(const std::string& wxVersion);

}  // namespace wedit

#include "Utf8Utils.h"

namespace wedit {

namespace {
inline bool isContinuation(char c) {
    return (static_cast<unsigned char>(c) & 0xC0) == 0x80;
}
}  // namespace

bool isValidUtf8(std::string_view s, size_t* badOffset) {
    size_t i = 0;
    const size_t n = s.size();
    auto fail = [&](size_t at) {
        if (badOffset) *badOffset = at;
        return false;
    };
    while (i < n) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        if (c < 0x80) {
            ++i;
            continue;
        }
        size_t len = 0;
        unsigned char lo = 0x80, hi = 0xBF;  // allowed range of the 2nd byte
        if (c >= 0xC2 && c <= 0xDF) {
            len = 2;
        } else if (c == 0xE0) {
            len = 3;
            lo = 0xA0;  // no overlongs
        } else if (c >= 0xE1 && c <= 0xEC) {
            len = 3;
        } else if (c == 0xED) {
            len = 3;
            hi = 0x9F;  // no surrogates
        } else if (c >= 0xEE && c <= 0xEF) {
            len = 3;
        } else if (c == 0xF0) {
            len = 4;
            lo = 0x90;  // no overlongs
        } else if (c >= 0xF1 && c <= 0xF3) {
            len = 4;
        } else if (c == 0xF4) {
            len = 4;
            hi = 0x8F;  // <= U+10FFFF
        } else {
            return fail(i);  // 0x80..0xC1, 0xF5..0xFF
        }
        if (i + len > n) return fail(i);  // truncated
        const unsigned char c1 = static_cast<unsigned char>(s[i + 1]);
        if (c1 < lo || c1 > hi) return fail(i);
        for (size_t k = 2; k < len; ++k) {
            if (!isContinuation(s[i + k])) return fail(i);
        }
        i += len;
    }
    return true;
}

bool hasUtf8Bom(std::string_view s) {
    return s.size() >= 3 && static_cast<unsigned char>(s[0]) == 0xEF &&
           static_cast<unsigned char>(s[1]) == 0xBB && static_cast<unsigned char>(s[2]) == 0xBF;
}

std::string_view stripUtf8Bom(std::string_view s) {
    return hasUtf8Bom(s) ? s.substr(3) : s;
}

bool containsNul(std::string_view s) {
    return s.find('\0') != std::string_view::npos;
}

size_t countCodePoints(std::string_view s) {
    size_t count = 0;
    for (char c : s) {
        if (!isContinuation(c)) ++count;
    }
    return count;
}

bool isCodePointBoundary(std::string_view s, size_t pos) {
    if (pos > s.size()) return false;
    if (pos == 0 || pos == s.size()) return true;
    return !isContinuation(s[pos]);
}

size_t floorToBoundary(std::string_view s, size_t pos) {
    if (pos >= s.size()) return s.size();
    while (pos > 0 && isContinuation(s[pos])) --pos;
    return pos;
}

size_t ceilToBoundary(std::string_view s, size_t pos) {
    if (pos >= s.size()) return s.size();
    while (pos < s.size() && isContinuation(s[pos])) ++pos;
    return pos;
}

size_t byteOffsetOfCodePoint(std::string_view s, size_t n) {
    size_t i = 0;
    while (n > 0 && i < s.size()) {
        ++i;
        while (i < s.size() && isContinuation(s[i])) ++i;
        --n;
    }
    return i;
}

}  // namespace wedit

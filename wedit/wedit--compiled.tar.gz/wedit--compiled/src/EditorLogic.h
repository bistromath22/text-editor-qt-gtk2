// Pure (toolkit-free) editor logic so it can be unit-tested without a display.
#pragma once

#include <cstddef>
#include <string>
#include <string_view>

namespace wedit {

// 1-based Unicode code-point column for the text that precedes the caret on
// its logical line (never a byte count).
int unicodeColumn(std::string_view linePrefix);

// Number of decimal digits of n (n <= 0 counts as 1).
int digitCount(int n);

// Width of the line-number margin for `lineCount` logical lines.
int lineNumberMarginWidth(int lineCount, int digitWidth, int inset);

// Number of logical lines in LF-normalised text ('\n' count + 1).
int countLogicalLines(std::string_view text);

struct LineSpacing {
    int above = 0;
    int below = 0;
    bool compressionUnsupported = false;  // requested line_height < 1.0
};
// Global line-height approximation from the natural font height. Always
// computed from a zero-extra baseline, so repeated calls never accumulate.
LineSpacing computeLineSpacing(int naturalHeight, double lineHeight);

struct GotoResult {
    bool ok = false;
    int line = 0;  // 1-based
    std::string error;
};
GotoResult parseGotoLine(const std::string& text, int lineCount);

// Finds `needle` at or after byte `start`, wrapping once. Case-insensitive
// matching folds ASCII only. Returns npos when absent.
size_t findText(std::string_view haystack, std::string_view needle, size_t start, bool matchCase,
                bool* wrapped);

}  // namespace wedit

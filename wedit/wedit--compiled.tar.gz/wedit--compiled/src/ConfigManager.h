// Configuration: canonical defaults (defined exactly once), INI parsing with
// strict validation, config discovery and atomic reload.
#pragma once

#include <map>
#include <optional>
#include <string>
#include <vector>

namespace wedit {

struct Config {
    // [editor]
    bool wordwrap = true;
    int border_size = 20;
    std::string border_color = "#313244";
    std::string background_color = "#1e1e2e";
    std::string gutter_background_color = "#313244";
    std::string current_line_color = "#313244";
    std::string line_number_color = "#6c7086";
    std::string text_color = "#cdd6f4";
    bool block_cursor = true;
    bool block_cursor_blink = false;
    std::string font_family = "Monaco";
    int font_size = 18;
    double line_height = 1.4;
    double pixels_above = 0;
    double pixels_below = 0;
    double line_distance = 0;
    bool show_line_numbers = false;
    bool highlight_current_line = true;
    bool show_statusbar = false;

    // [shortcuts]: config name -> GTK-style spelling. Always holds every action.
    std::map<std::string, std::string> shortcuts;

    bool operator==(const Config& o) const;
    bool operator!=(const Config& o) const { return !(*this == o); }
};

// The one and only source of canonical defaults.
Config makeDefaults();

// Shared validation limits (also used by runtime font-size commands).
constexpr int kMinFontSize = 6;
constexpr int kMaxFontSize = 96;
constexpr int kMinBorderSize = 0;
constexpr int kMaxBorderSize = 128;

struct ParseResult {
    Config config;
    std::vector<std::string> diagnostics;
};

// Parses INI text into a candidate Config. Never throws; every problem becomes
// a diagnostic and the affected property keeps its compiled-in default.
ParseResult parseConfigText(const std::string& text);

// "[editor]/[shortcuts]" text for the given config (used by --print-config).
std::string serializeConfig(const Config& cfg);

// Validates "#RRGGBB".
bool isValidColor(const std::string& s);

// ---- discovery -----------------------------------------------------------

struct Env {
    std::string cwd;
    std::string xdgConfigHome;
    std::string home;
    std::string appData;
    static Env fromProcess();
};

constexpr bool kIsWindowsBuild =
#ifdef _WIN32
    true;
#else
    false;
#endif

// Automatic candidate list in priority order (no explicit path).
std::vector<std::string> candidatePaths(const Env& env, bool windows);

struct LoadResult {
    bool ok = false;
    Config config;               // valid only when ok
    std::string sourcePath;      // empty when built-in defaults are in effect
    bool usingDefaults = true;
    std::vector<std::string> diagnostics;
    std::string error;           // set when !ok
};

// explicitPath: exact file or failure (no silent fallback). Otherwise the
// first existing, readable candidate wins; none -> built-in defaults.
LoadResult loadConfig(const std::optional<std::string>& explicitPath, const Env& env,
                      bool windows);

// Human-readable report for --print-config-paths.
std::string describeConfigSources(const std::optional<std::string>& explicitPath, const Env& env,
                                  bool windows);

// Holds the live configuration. reload() parses a complete candidate first and
// swaps it in only on success; on failure the live config is untouched.
class ConfigManager {
public:
    ConfigManager(std::optional<std::string> explicitPath, Env env,
                  bool windows = kIsWindowsBuild);

    bool reload(std::vector<std::string>* diagnostics, std::string* error);

    const Config& live() const { return live_; }
    const std::string& activeSource() const { return source_; }
    bool usingDefaults() const { return source_.empty(); }
    const std::optional<std::string>& explicitPath() const { return explicit_; }

private:
    std::optional<std::string> explicit_;
    Env env_;
    bool windows_;
    Config live_;
    std::string source_;
};

}  // namespace wedit

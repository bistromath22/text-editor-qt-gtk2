// File loading (strict UTF-8, BOM stripped, newlines normalised) and atomic
// saving. Paths are UTF-8 std::string; platform specifics stay in FileIO.cpp.
#pragma once

#include <string>

namespace wedit {

struct ReadResult {
    bool ok = false;
    std::string error;
    std::string text;      // valid UTF-8, LF newlines, BOM removed
    bool hadBom = false;
};

// Reads the whole file as bytes, strips one leading UTF-8 BOM, rejects invalid
// UTF-8 and embedded NUL, then normalises CRLF/CR to LF.
ReadResult readTextFile(const std::string& path);

struct WriteResult {
    bool ok = false;
    std::string error;
};

// Writes `bytes` to a unique temp file in the destination directory, fsyncs it
// and atomically replaces `path`. The destination is never truncated; the temp
// file is removed on every failure path. Existing permissions are preserved on
// POSIX (new files get 0644); ownership/ACLs/xattrs are not preserved.
WriteResult writeFileAtomic(const std::string& path, const std::string& bytes);

// Minimal path/clean bookkeeping used to prove the "change state only after
// success" rules independently of the GUI.
struct DocumentFile {
    std::string path;  // empty == Untitled
    bool clean = true;
};

// Loads `path` into `text`/`doc` only if the whole read succeeds; otherwise
// both are left untouched.
ReadResult loadDocument(DocumentFile& doc, std::string& text, const std::string& path);

// Saves `text` to `target`; updates doc.path and doc.clean only on success.
WriteResult saveDocument(DocumentFile& doc, const std::string& target, const std::string& text);

}  // namespace wedit

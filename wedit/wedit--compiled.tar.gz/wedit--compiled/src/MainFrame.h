// Main window: menus, layout (border surround, editor, optional status row),
// file workflow, and the single command dispatcher.
#pragma once

#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/stattext.h>

#include <map>
#include <string>

#include "AppActions.h"
#include "ConfigManager.h"
#include "ShortcutParser.h"

class EditorControl;
class wxCloseEvent;
class wxStyledTextEvent;

class MainFrame : public wxFrame {
public:
    MainFrame(wedit::ConfigManager config, const std::string& initialFile);

private:
    // construction
    void BuildMenus();
    void BuildLayout();

    // configuration / presentation
    void ApplyAll();
    void RebuildShortcuts();
    void ReloadConfig();

    // command path (menu, accelerator table and editor all end up here)
    void OnCommand(wxCommandEvent& event);
    void Dispatch(wedit::Action action);

    // file workflow
    bool ConfirmDiscard();
    bool OpenPath(const wxString& path);
    bool DoSave();
    bool DoSaveAs();
    bool DoWrite(const wxString& path);
    void NewDocument();

    // editing helpers
    void DoFind(bool fromSelectionEnd);
    void DoGotoLine();
    void ChangeFontSize(int delta);

    // events / status
    void OnClose(wxCloseEvent& event);
    void OnUpdateUI(wxStyledTextEvent& event);
    void OnSavePointChanged(wxStyledTextEvent& event);
    void UpdateTitle();
    void UpdateStatus(const wxString& note = wxString());

    wedit::ConfigManager m_cfg;  // owns the live config + reload policy
    wedit::Config m_active;      // live config plus runtime toggles
    wedit::ResolvedShortcuts m_shortcuts;

    wxPanel* m_borderPanel = nullptr;
    wxBoxSizer* m_borderSizer = nullptr;
    EditorControl* m_editor = nullptr;
    wxPanel* m_statusPanel = nullptr;
    wxStaticText* m_statusText = nullptr;
    wxBoxSizer* m_root = nullptr;
    std::map<wedit::Action, wxMenuItem*> m_items;

    wxString m_path;      // empty == Untitled
    wxString m_lastFind;
};

#include "AppActions.h"

namespace wedit {

const std::vector<ActionInfo>& allActions() {
    static const std::vector<ActionInfo> table = {
        {Action::NewFile, "new_file", "&New", "<Primary>n", true},
        {Action::Open, "open", "&Open...", "<Primary>o", true},
        {Action::Save, "save", "&Save", "<Primary>s", true},
        {Action::SaveAs, "save_as", "Save &As...", "<Primary><Shift>s", true},
        {Action::Quit, "quit", "&Quit", "<Primary>q", true},
        {Action::Undo, "undo", "&Undo", "<Primary>z", true},
        {Action::Redo, "redo", "&Redo", "<Primary>y", true},
        {Action::Cut, "cut", "Cu&t", "<Primary>x", true},
        {Action::Copy, "copy", "&Copy", "<Primary>c", true},
        {Action::Paste, "paste", "&Paste", "<Primary>v", true},
        {Action::Find, "find", "&Find...", "<Primary>f", true},
        {Action::FindNext, "find_next", "Find &Next", "F3", true},
        {Action::GotoLine, "goto_line", "&Go to Line...", "<Primary>g", true},
        {Action::ReloadConfig, "reload_config", "Re&load Config", "<Primary>r", true},
        {Action::ToggleWordWrap, "toggle_wordwrap", "Toggle Word &Wrap", "<Primary>w", true},
        {Action::IncreaseFont, "increase_font", "&Increase Font", "<Primary>plus", true},
        {Action::DecreaseFont, "decrease_font", "&Decrease Font", "<Primary>minus", true},
        {Action::FullScreen, "fullscreen", "&Full Screen", "F11", true},
        {Action::ToggleLineNumbers, "toggle_line_numbers", "Toggle &Line Numbers", "<Primary>l", true},
        {Action::ToggleCurrentLine, "toggle_current_line", "Toggle &Current-Line Highlight",
         "<Primary>h", true},
        {Action::ToggleStatusBar, "toggle_statusbar", "Toggle &Status Bar", "<Primary><Shift>b",
         true},
        {Action::ToggleBlockCursor, "toggle_block_cursor", "Toggle &Block Cursor", "<Primary>b",
         false},
    };
    return table;
}

const ActionInfo& infoFor(Action a) {
    return allActions()[static_cast<size_t>(a)];
}

const ActionInfo* findActionByConfigName(const std::string& name) {
    for (const auto& info : allActions()) {
        if (name == info.configName) return &info;
    }
    return nullptr;
}

}  // namespace wedit

// The single editing surface: a wxStyledTextCtrl (Scintilla) used strictly as
// a plain-text control. The Scintilla document is the only text model.
#pragma once

#include <wx/stc/stc.h>

#include <string>
#include <vector>

#include "ConfigManager.h"
#include "ShortcutParser.h"

class EditorControl : public wxStyledTextCtrl {
public:
    EditorControl(wxWindow* parent, wxWindowID id);

    struct ApplyReport {
        std::string requestedFont;
        std::string resolvedFont;
        std::vector<std::string> warnings;
    };

    // Applies colours, font, wrap, caret, margins, caret line and line spacing.
    // Never touches the text, selection, undo history or save point.
    ApplyReport ApplyConfig(const wedit::Config& cfg);

    // Replaces the document with already validated, LF-normalised UTF-8.
    // Resets undo history and sets a clean save point.
    void LoadUtf8(const std::string& text);

    std::string GetUtf8();

    int LogicalLine();     // 1-based logical line of the caret
    int UnicodeColumn();   // 1-based code-point column of the caret

    // Removes Scintilla's built-in bindings for every configured app shortcut
    // (and the standard edit keys) so those keys reach the frame's single
    // command path instead of being consumed natively.
    void ReleaseAppShortcuts(const std::vector<wedit::Shortcut>& shortcuts);

private:
    void OnChange(wxStyledTextEvent& event);
    void UpdateLineNumberMargin(bool force);

    bool m_showLineNumbers = false;
    int m_lastLineCount = -1;
};

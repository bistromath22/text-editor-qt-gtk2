// Entry point. All text-only command-line modes (--help, --version,
// --print-config, --print-config-paths) are handled in main() before wxWidgets
// is initialised, so they work without a display.
#include <wx/app.h>
#include <wx/version.h>

#include <cstdio>
#include <optional>
#include <string>
#include <vector>

#include "Cli.h"
#include "ConfigManager.h"
#include "MainFrame.h"

#if !wxCHECK_VERSION(3, 2, 0)
#error "wedit requires wxWidgets 3.2.0 or newer in the 3.2 series"
#endif

namespace {

wedit::CliOptions g_cli;
std::optional<wedit::ConfigManager> g_config;

}  // namespace

class WeditApp : public wxApp {
public:
    bool OnInit() override {
        SetAppName(wxS("wedit"));
        const std::string initial = g_cli.files.empty() ? std::string() : g_cli.files.front();
        auto* frame = new MainFrame(std::move(*g_config), initial);
        frame->Show(true);
        return true;
    }
};

wxIMPLEMENT_APP_NO_MAIN(WeditApp);

int main(int argc, char** argv) {
    std::vector<std::string> args;
    for (int i = 1; i < argc; ++i) args.emplace_back(argv[i]);
    g_cli = wedit::parseCli(args);

    switch (g_cli.action) {
        case wedit::CliAction::Help:
            std::fputs(wedit::helpText().c_str(), stdout);
            return 0;
        case wedit::CliAction::Version:
            std::fputs(wedit::versionText(wxVERSION_NUM_DOT_STRING).c_str(), stdout);
            return 0;
        case wedit::CliAction::PrintConfig:
            // Always the canonical defaults, from the one defaults object.
            std::fputs(wedit::serializeConfig(wedit::makeDefaults()).c_str(), stdout);
            return 0;
        case wedit::CliAction::PrintConfigPaths:
            std::fputs(wedit::describeConfigSources(g_cli.configPath, wedit::Env::fromProcess(),
                                                    wedit::kIsWindowsBuild)
                           .c_str(),
                       stdout);
            return 0;
        case wedit::CliAction::Error:
            std::fprintf(stderr, "wedit: %s\n", g_cli.error.c_str());
            return 2;
        case wedit::CliAction::Run:
            break;
    }
    for (const auto& w : g_cli.warnings) std::fprintf(stderr, "wedit: %s\n", w.c_str());

    g_config.emplace(g_cli.configPath, wedit::Env::fromProcess());
    std::vector<std::string> diagnostics;
    std::string error;
    if (!g_config->reload(&diagnostics, &error)) {
        std::fprintf(stderr, "wedit: %s\n", error.c_str());  // explicit path failed: no fallback
        return 2;
    }
    for (const auto& d : diagnostics) std::fprintf(stderr, "wedit: %s\n", d.c_str());

    return wxEntry(argc, argv);
}

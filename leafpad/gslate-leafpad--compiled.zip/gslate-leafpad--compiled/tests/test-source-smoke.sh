#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "FAIL: $1" >&2; exit 1; }
[ -s src/gslate.c ] || fail "missing GSlate implementation"
[ -s src/gslate.h ] || fail "missing GSlate header"
grep -q 'gslate.c' src/Makefile.am || fail "GSlate module not in Automake source list"
grep -q 'gtk_text_view_set_cursor_visible' src/gslate.c || fail "editor-scoped native caret suppression missing"
grep -q 'g_signal_connect_after(pub->mw->view, "expose-event"' src/gslate.c || fail "block cursor expose renderer missing"
grep -q 'gtk_text_view_get_iter_location' src/gslate.c || fail "cursor geometry not derived from GtkTextView"
grep -q 'gtk_text_view_buffer_to_window_coords' src/gslate.c || fail "cursor coordinate conversion missing"
! grep -q 'gtk_settings_set.*cursor-blink\|gtk-cursor-blink' src/gslate.c || fail "global cursor blink setting must not be changed"
grep -q 'paragraph-background-gdk' src/gslate.c || fail "paragraph highlight property missing"
grep -q 'g_key_file_load_from_file' src/gslate.c || fail "GKeyFile config loader missing"
grep -q 'line_number_background' gslate.ini.example || fail "gutter colour example missing"
grep -q 'block_cursor=false' gslate.ini.example || fail "block cursor default missing"
grep -q 'GtkTextView' GSLATE-DESIGN.md || fail "technical design missing"
echo "PASS: GSlate source integration smoke checks"
# Regression guard for the missing gutter state reported by the first user build.
grep -q '^static GtkWidget \*line_number_view = NULL;' src/linenum.c || fail "line-number widget state is undeclared"
grep -q '^static GdkColor gutter_background;' src/linenum.c || fail "gutter background state is undeclared"
grep -q '^static GdkColor gutter_foreground;' src/linenum.c || fail "gutter foreground state is undeclared"
grep -q '^static gboolean gutter_colors_initialized = FALSE;' src/linenum.c || fail "gutter color initialization state is undeclared"

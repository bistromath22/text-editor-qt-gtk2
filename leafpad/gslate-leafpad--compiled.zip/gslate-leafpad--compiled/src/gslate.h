/*
 * GSlate presentation and editor preferences for Leafpad.
 * Derived from Leafpad; original copyright and GPL notices are retained.
 */
#ifndef _GSLATE_H
#define _GSLATE_H

void gslate_config_load(gboolean legacy_wrap, gboolean legacy_lines,
                        const gchar *legacy_font);
void gslate_config_save(void);
void gslate_apply_config(void);
void gslate_features_init(void);
void gslate_capture_font(void);
void gslate_sync_word_wrap(gboolean enabled);
void gslate_sync_line_numbers(gboolean enabled);
void gslate_toggle_block_cursor(void);
void gslate_toggle_current_line(void);
void gslate_toggle_statusbar(void);
void gslate_reload_config(void);

#endif /* _GSLATE_H */

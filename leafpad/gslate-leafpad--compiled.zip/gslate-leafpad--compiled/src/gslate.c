/*
 * GSlate editor presentation layer.
 * This file is part of a Leafpad-derived application.  See COPYING and the
 * original Leafpad source files for the applicable copyright and licence.
 */
#include "leafpad.h"
#include "gslate.h"
#include <math.h>
#include <string.h>

#define GSLATE_DEFAULT_BG       "#1e1e2e"
#define GSLATE_DEFAULT_TEXT     "#cdd6f4"
#define GSLATE_DEFAULT_BORDER   "#313244"
#define GSLATE_DEFAULT_GUTTER   "#313244"
#define GSLATE_DEFAULT_GUTTER_FG "#6c7086"
#define GSLATE_DEFAULT_CURSOR   "#cdd6f4"
#define GSLATE_DEFAULT_CURRENT  "#313244"

typedef struct {
	gboolean wordwrap;
	gboolean line_numbers;
	gboolean current_line;
	gboolean block_cursor;
	gboolean statusbar;
	gint border_size;
	gint font_size;
	gint tab_width;
	gint pixels_above;
	gint pixels_below;
	gint line_distance;
	gdouble line_height;
	gchar *font_family;
	gchar *background;
	gchar *text;
	gchar *border;
	gchar *gutter;
	gchar *gutter_text;
	gchar *current_line_color;
	gchar *cursor;
} GSlateConfig;

static GSlateConfig cfg;
static gboolean config_ready = FALSE;
static GtkTextTag *current_line_tag = NULL;
static GtkTextMark *previous_line_start = NULL;
static GtkTextMark *previous_line_end = NULL;
static GdkColor block_cursor_color;
static gboolean block_cursor_color_valid = FALSE;

static gboolean on_editor_focus_changed(GtkWidget *widget, GdkEventFocus *event, gpointer data);

static gchar *gslate_config_path(void)
{
	return g_build_filename(g_get_user_config_dir(), PACKAGE,
		"gslate.ini", NULL);
}

static void set_defaults(gboolean legacy_wrap, gboolean legacy_lines,
                         const gchar *legacy_font)
{
	memset(&cfg, 0, sizeof(cfg));
	cfg.wordwrap = legacy_wrap;
	cfg.line_numbers = legacy_lines;
	cfg.current_line = TRUE;
	cfg.block_cursor = FALSE;
	cfg.statusbar = TRUE;
	cfg.border_size = 8;
	cfg.font_size = 12;
	cfg.tab_width = 4;
	cfg.pixels_above = 0;
	cfg.pixels_below = 0;
	cfg.line_distance = 0;
	cfg.line_height = 1.4;
	cfg.font_family = g_strdup("Monospace");
	cfg.background = g_strdup(GSLATE_DEFAULT_BG);
	cfg.text = g_strdup(GSLATE_DEFAULT_TEXT);
	cfg.border = g_strdup(GSLATE_DEFAULT_BORDER);
	cfg.gutter = g_strdup(GSLATE_DEFAULT_GUTTER);
	cfg.gutter_text = g_strdup(GSLATE_DEFAULT_GUTTER_FG);
	cfg.current_line_color = g_strdup(GSLATE_DEFAULT_CURRENT);
	cfg.cursor = g_strdup(GSLATE_DEFAULT_CURSOR);

	/* Retain the selected legacy font when it can be split into family/size. */
	if (legacy_font && *legacy_font) {
		PangoFontDescription *desc = pango_font_description_from_string(legacy_font);
		if (desc) {
			const gchar *family = pango_font_description_get_family(desc);
			gint size = pango_font_description_get_size(desc);
			if (family && *family) {
				g_free(cfg.font_family);
				cfg.font_family = g_strdup(family);
			}
			if (size > 0)
				cfg.font_size = MAX(6, MIN(96, (gint) (size / PANGO_SCALE)));
			pango_font_description_free(desc);
		}
	}
}

static gboolean key_exists(GKeyFile *keyfile, const gchar *group,
                           const gchar *key)
{
	return g_key_file_has_key(keyfile, group, key, NULL);
}

static gboolean read_boolean(GKeyFile *keyfile, const gchar *key,
                             gboolean current)
{
	GError *error = NULL;
	gboolean value;
	if (!key_exists(keyfile, "editor", key))
		return current;
	value = g_key_file_get_boolean(keyfile, "editor", key, &error);
	if (error) {
		g_warning("GSlate config: invalid editor.%s: %s", key, error->message);
		g_error_free(error);
		return current;
	}
	return value;
}

static gint read_integer(GKeyFile *keyfile, const gchar *key,
                         gint current, gint minimum, gint maximum)
{
	GError *error = NULL;
	gint value;
	if (!key_exists(keyfile, "editor", key))
		return current;
	value = g_key_file_get_integer(keyfile, "editor", key, &error);
	if (error) {
		g_warning("GSlate config: invalid editor.%s: %s", key, error->message);
		g_error_free(error);
		return current;
	}
	if (value < minimum || value > maximum) {
		g_warning("GSlate config: editor.%s outside %d..%d; using default",
			key, minimum, maximum);
		return current;
	}
	return value;
}

static gdouble read_double(GKeyFile *keyfile, const gchar *key,
                           gdouble current, gdouble minimum, gdouble maximum)
{
	GError *error = NULL;
	gdouble value;
	if (!key_exists(keyfile, "editor", key))
		return current;
	value = g_key_file_get_double(keyfile, "editor", key, &error);
	if (error) {
		g_warning("GSlate config: invalid editor.%s: %s", key, error->message);
		g_error_free(error);
		return current;
	}
	if (value < minimum || value > maximum) {
		g_warning("GSlate config: editor.%s outside %.1f..%.1f; using default",
			key, minimum, maximum);
		return current;
	}
	return value;
}

static gchar *read_string(GKeyFile *keyfile, const gchar *key,
                          const gchar *current, gboolean colour)
{
	GError *error = NULL;
	gchar *value;
	GdkColor parsed;
	if (!key_exists(keyfile, "editor", key))
		return g_strdup(current);
	value = g_key_file_get_string(keyfile, "editor", key, &error);
	if (error) {
		g_warning("GSlate config: invalid editor.%s: %s", key, error->message);
		g_error_free(error);
		return g_strdup(current);
	}
	if (!value || !*value || (colour && !gdk_color_parse(value, &parsed))) {
		g_warning("GSlate config: invalid value for editor.%s; using default", key);
		g_free(value);
		return g_strdup(current);
	}
	return value;
}

static void load_keyfile_into_config(GKeyFile *keyfile)
{
	cfg.wordwrap = read_boolean(keyfile, "wordwrap", cfg.wordwrap);
	cfg.line_numbers = read_boolean(keyfile, "show_line_numbers", cfg.line_numbers);
	cfg.current_line = read_boolean(keyfile, "highlight_current_line", cfg.current_line);
	cfg.block_cursor = read_boolean(keyfile, "block_cursor", cfg.block_cursor);
	cfg.statusbar = read_boolean(keyfile, "show_statusbar", cfg.statusbar);
	cfg.border_size = read_integer(keyfile, "border_size", cfg.border_size, 0, 64);
	cfg.font_size = read_integer(keyfile, "font_size", cfg.font_size, 6, 96);
	cfg.tab_width = read_integer(keyfile, "tab_width", cfg.tab_width, 1, 16);
	cfg.pixels_above = read_integer(keyfile, "pixels_above", cfg.pixels_above, 0, 64);
	cfg.pixels_below = read_integer(keyfile, "pixels_below", cfg.pixels_below, 0, 64);
	cfg.line_distance = read_integer(keyfile, "line_distance", cfg.line_distance, 0, 64);
	cfg.line_height = read_double(keyfile, "line_height", cfg.line_height, 1.0, 3.0);

#define REPLACE_STRING(field, key, colour) do { \
	gchar *replacement = read_string(keyfile, key, cfg.field, colour); \
	g_free(cfg.field); cfg.field = replacement; \
} while (0)
	REPLACE_STRING(font_family, "font_family", FALSE);
	REPLACE_STRING(background, "background_color", TRUE);
	REPLACE_STRING(text, "text_color", TRUE);
	REPLACE_STRING(border, "border_color", TRUE);
	REPLACE_STRING(gutter, "line_number_background", TRUE);
	REPLACE_STRING(gutter_text, "line_number_color", TRUE);
	REPLACE_STRING(current_line_color, "current_line_color", TRUE);
	REPLACE_STRING(cursor, "cursor_color", TRUE);
#undef REPLACE_STRING
}

void gslate_config_load(gboolean legacy_wrap, gboolean legacy_lines,
                        const gchar *legacy_font)
{
	GKeyFile *keyfile;
	GError *error = NULL;
	gchar *path;

	set_defaults(legacy_wrap, legacy_lines, legacy_font);
	keyfile = g_key_file_new();
	path = gslate_config_path();
	if (g_key_file_load_from_file(keyfile, path, G_KEY_FILE_NONE, &error))
		load_keyfile_into_config(keyfile);
	else if (error && !g_error_matches(error, G_FILE_ERROR, G_FILE_ERROR_NOENT)) {
		g_warning("Could not read GSlate configuration '%s': %s",
			path, error->message);
	}
	if (error)
		g_error_free(error);
	g_free(path);
	g_key_file_free(keyfile);
	config_ready = TRUE;
}

void gslate_config_save(void)
{
	GKeyFile *keyfile;
	gchar *path, *directory, *data;
	gsize length = 0;
	GError *error = NULL;

	if (!config_ready)
		return;
	gslate_capture_font();
	keyfile = g_key_file_new();
#define SET_BOOL(k, v) g_key_file_set_boolean(keyfile, "editor", k, v)
#define SET_INT(k, v) g_key_file_set_integer(keyfile, "editor", k, v)
#define SET_STR(k, v) g_key_file_set_string(keyfile, "editor", k, v)
	SET_BOOL("wordwrap", cfg.wordwrap);
	SET_INT("border_size", cfg.border_size);
	SET_STR("border_color", cfg.border);
	SET_STR("background_color", cfg.background);
	SET_STR("text_color", cfg.text);
	SET_STR("current_line_color", cfg.current_line_color);
	SET_STR("line_number_background", cfg.gutter);
	SET_STR("line_number_color", cfg.gutter_text);
	SET_STR("cursor_color", cfg.cursor);
	SET_BOOL("block_cursor", cfg.block_cursor);
	SET_STR("font_family", cfg.font_family);
	SET_INT("font_size", cfg.font_size);
	g_key_file_set_double(keyfile, "editor", "line_height", cfg.line_height);
	SET_INT("pixels_above", cfg.pixels_above);
	SET_INT("pixels_below", cfg.pixels_below);
	SET_INT("line_distance", cfg.line_distance);
	SET_BOOL("show_line_numbers", cfg.line_numbers);
	SET_BOOL("highlight_current_line", cfg.current_line);
	SET_BOOL("show_statusbar", cfg.statusbar);
	SET_INT("tab_width", cfg.tab_width);
#undef SET_BOOL
#undef SET_INT
#undef SET_STR
	data = g_key_file_to_data(keyfile, &length, NULL);
	path = gslate_config_path();
	directory = g_path_get_dirname(path);
	if (g_mkdir_with_parents(directory, 0700) != 0)
		g_warning("Could not create GSlate config directory '%s'", directory);
	else if (!g_file_set_contents(path, data, length, &error)) {
		g_warning("Could not save GSlate configuration '%s': %s",
			path, error ? error->message : "unknown error");
	}
	if (error)
		g_error_free(error);
	g_free(directory);
	g_free(path);
	g_free(data);
	g_key_file_free(keyfile);
}

static gboolean parse_colour(const gchar *name, GdkColor *colour)
{
	return name && gdk_color_parse(name, colour);
}

static GtkWidget *get_option_item(const gchar *path)
{
	GtkItemFactory *factory;
	if (!pub || !pub->mw || !pub->mw->menubar)
		return NULL;
	factory = gtk_item_factory_from_widget(pub->mw->menubar);
	return gtk_item_factory_get_widget(factory, path);
}

static void set_menu_state(const gchar *path, gboolean state, GCallback callback)
{
	GtkWidget *item = get_option_item(path);
	if (!item)
		return;
	if (callback)
		g_signal_handlers_block_by_func(item, callback, NULL);
	gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(item), state);
	if (callback)
		g_signal_handlers_unblock_by_func(item, callback, NULL);
}

static void update_statusbar(void)
{
	GtkTextIter iter;
	gchar *status;
	if (!pub || !pub->mw || !pub->mw->status_label)
		return;
	gtk_text_buffer_get_iter_at_mark(pub->mw->buffer, &iter,
		gtk_text_buffer_get_insert(pub->mw->buffer));
	status = g_strdup_printf(_("Ln %d, Col %d"),
		gtk_text_iter_get_line(&iter) + 1,
		gtk_text_iter_get_line_offset(&iter) + 1);
	gtk_label_set_text(GTK_LABEL(pub->mw->status_label), status);
	g_free(status);
}

static void remove_current_line_tag(void)
{
	GtkTextIter start, end;
	if (!pub || !pub->mw || !current_line_tag)
		return;
	if (previous_line_start && previous_line_end) {
		gtk_text_buffer_get_iter_at_mark(pub->mw->buffer, &start, previous_line_start);
		gtk_text_buffer_get_iter_at_mark(pub->mw->buffer, &end, previous_line_end);
		gtk_text_buffer_remove_tag(pub->mw->buffer, current_line_tag, &start, &end);
		gtk_text_buffer_delete_mark(pub->mw->buffer, previous_line_start);
		gtk_text_buffer_delete_mark(pub->mw->buffer, previous_line_end);
		previous_line_start = NULL;
		previous_line_end = NULL;
	}
}

static void update_current_line(void)
{
	GtkTextIter cursor, start, end, buffer_end;
	if (!pub || !pub->mw || !current_line_tag)
		return;
	remove_current_line_tag();
	if (cfg.current_line) {
		gtk_text_buffer_get_iter_at_mark(pub->mw->buffer, &cursor,
			gtk_text_buffer_get_insert(pub->mw->buffer));
		start = cursor;
		gtk_text_iter_set_line_offset(&start, 0);
		end = start;
		gtk_text_iter_forward_to_line_end(&end);
		gtk_text_buffer_get_end_iter(pub->mw->buffer, &buffer_end);
		if (!gtk_text_iter_equal(&end, &buffer_end))
			gtk_text_iter_forward_char(&end); /* include the paragraph separator */
		if (!gtk_text_iter_equal(&start, &end)) {
			gtk_text_buffer_apply_tag(pub->mw->buffer, current_line_tag, &start, &end);
			previous_line_start = gtk_text_buffer_create_mark(pub->mw->buffer,
				"gslate-current-start", &start, TRUE);
			previous_line_end = gtk_text_buffer_create_mark(pub->mw->buffer,
				"gslate-current-end", &end, FALSE);
		}
	}
	if (pub->mw->view)
		gtk_widget_queue_draw(pub->mw->view);
}

static void on_editor_mark_set(GtkTextBuffer *buffer, GtkTextIter *iter,
                               GtkTextMark *mark, gpointer data)
{
	if (gtk_text_mark_get_name(mark) &&
		!strcmp(gtk_text_mark_get_name(mark), "insert")) {
		update_current_line();
		update_statusbar();
	}
}

static void on_editor_changed(GtkTextBuffer *buffer, gpointer data)
{
	update_current_line();
	update_statusbar();
	if (pub && pub->mw && pub->mw->view && cfg.block_cursor)
		gtk_widget_queue_draw(pub->mw->view);
}

static gboolean draw_block_cursor(GtkWidget *widget, GdkEventExpose *event,
                                  gpointer data)
{
	GtkTextView *view = GTK_TEXT_VIEW(widget);
	GdkWindow *text_window;
	GtkTextIter iter, next;
	GdkRectangle location, next_location, visible;
	gint x, y, width, height;
	GdkGC *gc;
	PangoLayout *layout;
	gint text_width = 0;

	if (!cfg.block_cursor || !GTK_WIDGET_HAS_FOCUS(widget) ||
		!GTK_WIDGET_REALIZED(widget))
		return FALSE;
	text_window = gtk_text_view_get_window(view, GTK_TEXT_WINDOW_TEXT);
	if (event->window != text_window)
		return FALSE;

	gtk_text_buffer_get_iter_at_mark(gtk_text_view_get_buffer(view), &iter,
		gtk_text_buffer_get_insert(gtk_text_view_get_buffer(view)));
	gtk_text_view_get_iter_location(view, &iter, &location);
	gtk_text_view_get_visible_rect(view, &visible);
	if (location.y + location.height < visible.y || location.y > visible.y + visible.height ||
		location.x < visible.x - 256 || location.x > visible.x + visible.width)
		return FALSE;
	gtk_text_view_buffer_to_window_coords(view, GTK_TEXT_WINDOW_TEXT,
		location.x, location.y, &x, &y);
	width = 0;
	next = iter;
	if (gtk_text_iter_forward_char(&next)) {
		gtk_text_view_get_iter_location(view, &next, &next_location);
		if (next_location.y == location.y && next_location.x > location.x)
			width = next_location.x - location.x;
	}
	if (width < 2) {
		layout = gtk_widget_create_pango_layout(widget, "M");
		if (widget->style && widget->style->font_desc)
			pango_layout_set_font_description(layout, widget->style->font_desc);
		pango_layout_get_pixel_size(layout, &text_width, NULL);
		g_object_unref(layout);
		width = MAX(2, text_width);
	}
	width = MIN(width, 256);
	height = MAX(2, location.height);
	if (!block_cursor_color_valid)
		block_cursor_color_valid = parse_colour(cfg.cursor, &block_cursor_color);
	if (!block_cursor_color_valid)
		gdk_color_parse(GSLATE_DEFAULT_CURSOR, &block_cursor_color);
	{
		GdkColormap *colormap = gtk_widget_get_colormap(widget);
		GdkColor draw_colour = block_cursor_color;
		gdk_colormap_alloc_color(colormap, &draw_colour, FALSE, TRUE);
		gc = gdk_gc_new(text_window);
		gdk_gc_set_foreground(gc, &draw_colour);
		gdk_draw_rectangle(text_window, gc, TRUE, x, y, width, height);
		/* Repaint a printable character in a contrasting colour when one exists.
		 * The block itself remains the stable fallback for tabs and end-of-line. */
		if (!gtk_text_iter_is_end(&iter)) {
			gunichar character = gtk_text_iter_get_char(&iter);
			if (character && !g_unichar_isspace(character) &&
				g_unichar_type(character) != G_UNICODE_NON_SPACING_MARK &&
				g_unichar_type(character) != G_UNICODE_SPACING_MARK &&
				g_unichar_type(character) != G_UNICODE_ENCLOSING_MARK) {
				gchar utf8[7] = { 0 };
				gint glyph_height = 0;
				GdkColor glyph_foreground;
				g_unichar_to_utf8(character, utf8);
				layout = gtk_widget_create_pango_layout(widget, utf8);
				if (widget->style && widget->style->font_desc)
					pango_layout_set_font_description(layout, widget->style->font_desc);
				pango_layout_get_pixel_size(layout, NULL, &glyph_height);
				if ((guint) block_cursor_color.red + block_cursor_color.green +
					block_cursor_color.blue > 3 * 32768)
					gdk_color_parse("#1e1e2e", &glyph_foreground);
				else
					gdk_color_parse("#cdd6f4", &glyph_foreground);
				gdk_colormap_alloc_color(colormap, &glyph_foreground, FALSE, TRUE);
				gdk_draw_layout_with_colors(text_window, gc, x,
					y + MAX(0, (height - glyph_height) / 2), layout,
					&glyph_foreground, NULL);
				gdk_colormap_free_colors(colormap, &glyph_foreground, 1);
				g_object_unref(layout);
			}
		}
		g_object_unref(gc);
		gdk_colormap_free_colors(colormap, &draw_colour, 1);
	}
	return FALSE;
}

static void apply_typography(void)
{
	PangoFontDescription *description;
	PangoFontMetrics *metrics;
	gint natural_height, extra;
	gchar *fontname;
	if (!pub || !pub->mw || !pub->mw->view)
		return;
	fontname = g_strdup_printf("%s %d", cfg.font_family, cfg.font_size);
	description = pango_font_description_from_string(fontname);
	g_free(fontname);
	gtk_widget_modify_font(pub->mw->view, description);
	metrics = pango_context_get_metrics(gtk_widget_get_pango_context(pub->mw->view),
		description, pango_language_get_default());
	natural_height = PANGO_PIXELS_CEIL(pango_font_metrics_get_ascent(metrics) +
		pango_font_metrics_get_descent(metrics));
	pango_font_metrics_unref(metrics);
	pango_font_description_free(description);
	extra = (gint) ((cfg.line_height - 1.0) * natural_height + 0.5);
	gtk_text_view_set_pixels_above_lines(GTK_TEXT_VIEW(pub->mw->view),
		cfg.pixels_above + extra / 2);
	gtk_text_view_set_pixels_below_lines(GTK_TEXT_VIEW(pub->mw->view),
		cfg.pixels_below + extra - extra / 2);
	gtk_text_view_set_pixels_inside_wrap(GTK_TEXT_VIEW(pub->mw->view),
		cfg.line_distance);
	indent_set_default_tab_width(cfg.tab_width);
	indent_refresh_tab_width(pub->mw->view);
}

void gslate_apply_config(void)
{
	GdkColor colour;
	if (!config_ready || !pub || !pub->mw)
		return;
	if (parse_colour(cfg.border, &colour) && pub->mw->surround)
		gtk_widget_modify_bg(pub->mw->surround, GTK_STATE_NORMAL, &colour);
	if (pub->mw->surround)
		gtk_container_set_border_width(GTK_CONTAINER(pub->mw->surround), cfg.border_size);
	if (parse_colour(cfg.background, &colour))
		gtk_widget_modify_base(pub->mw->view, GTK_STATE_NORMAL, &colour);
	if (parse_colour(cfg.text, &colour))
		gtk_widget_modify_text(pub->mw->view, GTK_STATE_NORMAL, &colour);
	linenum_set_colors(cfg.gutter, cfg.gutter_text);
	gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(pub->mw->view),
		cfg.wordwrap ? GTK_WRAP_WORD : GTK_WRAP_NONE);
	show_line_numbers(pub->mw->view, cfg.line_numbers);
	apply_typography();
	if (current_line_tag) {
		if (parse_colour(cfg.current_line_color, &colour))
			g_object_set(G_OBJECT(current_line_tag), "background-gdk", &colour,
			"paragraph-background-gdk", &colour, NULL);
		update_current_line();
	}
	if (parse_colour(cfg.cursor, &block_cursor_color))
		block_cursor_color_valid = TRUE;
	else
		block_cursor_color_valid = FALSE;
	gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(pub->mw->view), !cfg.block_cursor);
	if (pub->mw->statusbar) {
		if (cfg.statusbar)
			gtk_widget_show(pub->mw->statusbar);
		else
			gtk_widget_hide(pub->mw->statusbar);
	}
	set_menu_state("/Options/Word Wrap", cfg.wordwrap, G_CALLBACK(on_option_word_wrap));
	set_menu_state("/Options/Line Numbers", cfg.line_numbers, G_CALLBACK(on_option_line_numbers));
	set_menu_state("/Options/Highlight Current Line", cfg.current_line, G_CALLBACK(on_option_current_line));
	set_menu_state("/Options/Block Cursor", cfg.block_cursor, G_CALLBACK(on_option_block_cursor));
	set_menu_state("/Options/Status Bar", cfg.statusbar, G_CALLBACK(on_option_statusbar));
	update_statusbar();
	if (pub->mw->view)
		gtk_widget_queue_draw(pub->mw->view);
}

void gslate_features_init(void)
{
	GdkColor colour;
	if (!pub || !pub->mw)
		return;
	current_line_tag = gtk_text_buffer_create_tag(pub->mw->buffer,
		"gslate-current-line", NULL);
	if (parse_colour(cfg.current_line_color, &colour))
		g_object_set(G_OBJECT(current_line_tag), "background-gdk", &colour,
			"paragraph-background-gdk", &colour, NULL);
	g_signal_connect(pub->mw->buffer, "mark-set", G_CALLBACK(on_editor_mark_set), NULL);
	g_signal_connect(pub->mw->buffer, "changed", G_CALLBACK(on_editor_changed), NULL);
	g_signal_connect_after(pub->mw->view, "expose-event",
		G_CALLBACK(draw_block_cursor), NULL);
	g_signal_connect(pub->mw->view, "focus-in-event",
		G_CALLBACK(on_editor_focus_changed), NULL);
	g_signal_connect(pub->mw->view, "focus-out-event",
		G_CALLBACK(on_editor_focus_changed), NULL);
	update_current_line();
	update_statusbar();
}

void gslate_capture_font(void)
{
	gchar *fontname;
	PangoFontDescription *description;
	const gchar *family;
	gint size;
	if (!pub || !pub->mw || !pub->mw->view || !config_ready)
		return;
	fontname = get_font_name_from_widget(pub->mw->view);
	description = pango_font_description_from_string(fontname);
	family = pango_font_description_get_family(description);
	size = pango_font_description_get_size(description);
	if (family && *family) {
		g_free(cfg.font_family);
		cfg.font_family = g_strdup(family);
	}
	if (size > 0)
		cfg.font_size = MAX(6, MIN(96, (gint)(size / PANGO_SCALE)));
	pango_font_description_free(description);
	g_free(fontname);
}

void gslate_sync_word_wrap(gboolean enabled)
{
	cfg.wordwrap = enabled;
}

void gslate_sync_line_numbers(gboolean enabled)
{
	cfg.line_numbers = enabled;
}

void gslate_toggle_block_cursor(void)
{
	GtkWidget *item = get_option_item("/Options/Block Cursor");
	cfg.block_cursor = item ? gtk_check_menu_item_get_active(GTK_CHECK_MENU_ITEM(item)) : !cfg.block_cursor;
	if (pub && pub->mw && pub->mw->view)
		gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(pub->mw->view), !cfg.block_cursor);
	if (pub && pub->mw && pub->mw->view)
		gtk_widget_queue_draw(pub->mw->view);
}

void gslate_toggle_current_line(void)
{
	GtkWidget *item = get_option_item("/Options/Highlight Current Line");
	cfg.current_line = item ? gtk_check_menu_item_get_active(GTK_CHECK_MENU_ITEM(item)) : !cfg.current_line;
	update_current_line();
}

void gslate_toggle_statusbar(void)
{
	GtkWidget *item = get_option_item("/Options/Status Bar");
	cfg.statusbar = item ? gtk_check_menu_item_get_active(GTK_CHECK_MENU_ITEM(item)) : !cfg.statusbar;
	if (pub && pub->mw && pub->mw->statusbar) {
		if (cfg.statusbar) gtk_widget_show(pub->mw->statusbar);
		else gtk_widget_hide(pub->mw->statusbar);
	}
}

void gslate_reload_config(void)
{
	GKeyFile *keyfile;
	GError *error = NULL;
	gchar *path;
	if (!config_ready)
		return;
	keyfile = g_key_file_new();
	path = gslate_config_path();
	if (g_key_file_load_from_file(keyfile, path, G_KEY_FILE_NONE, &error)) {
		load_keyfile_into_config(keyfile);
		gslate_apply_config();
	} else {
		run_dialog_message(pub->mw->window, GTK_MESSAGE_ERROR,
			_("Unable to reload GSlate configuration. See the terminal for details."));
		if (error) g_warning("%s", error->message);
	}
	if (error) g_error_free(error);
	g_free(path);
	g_key_file_free(keyfile);
}

static gboolean on_editor_focus_changed(GtkWidget *widget, GdkEventFocus *event, gpointer data)
{
	gtk_widget_queue_draw(widget);
	return FALSE;
}

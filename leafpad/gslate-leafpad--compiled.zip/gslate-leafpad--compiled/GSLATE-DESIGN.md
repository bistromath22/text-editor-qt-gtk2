# GSlate-Leafpad technical design

## Project and compatibility

This tree is a modification of the supplied Leafpad 0.8.19 C/GTK 2 project.
It keeps the original Autotools build, the `GtkTextView`/`GtkTextBuffer` editing
model and the existing file/encoding/undo/search/printing subsystems. The
original `COPYING`, `AUTHORS`, copyright headers and project attribution are
retained. No GTK 3/4, Qt, gtkmm, GtkSourceView, web engine or C++ rewrite has
been introduced.

## Existing modules reused

- `main.c`: application startup, command-line parsing and legacy Leafpad
  configuration migration remain in place.
- `window.c` / `window.h`: the original main window and editor widget hierarchy
  are extended with a colourable surround and a status row.
- `view.c`: the existing `GtkTextView` remains the editor and continues to own
  the established key, selection and buffer signal behaviour.
- `linenum.c`: the original GTK 2 left-border-window gutter is retained; its
  background and foreground are now configurable.
- `font.c` and `indent.c`: Pango font selection and the existing tab-stop
  calculation are reused.
- `menu.c` / `callback.c`: new view actions are registered through the existing
  `GtkItemFactory` menu and callback architecture.
- `file.c`, `encoding.c`, `undo.c`, `search.c`, `dnd.c`, and printing modules
  remain the original Leafpad implementations.

## New module

`src/gslate.c` and `src/gslate.h` hold the GSlate configuration and the
presentation-only editor features. This keeps the central feature work out of
`main.c` and leaves existing text/file code largely unchanged.

## Window hierarchy

The main vertical box contains the original menu bar, then an event-box
surround. The surround contains the original scrolled window and text view.
A separate status row follows the editor. The surround's border width is an
independent logical-pixel inset; setting it to zero removes the inset. The
scrolled window uses automatic horizontal and vertical scrollbars and has no
extra shadow frame.

## Configuration and defaults

The original Leafpad configuration remains readable and is still written by
`save_config_file()`. GSlate adds a separate INI-style file at:

`$XDG_CONFIG_HOME/leafpad/gslate.ini` (normally `~/.config/leafpad/gslate.ini`).

The checked-in `gslate.ini.example` documents all supported keys. Missing keys
retain defaults. Invalid booleans, numbers, colours and out-of-range values
produce warnings and fall back to the current safe value. Runtime reload
updates the running editor without replacing the text buffer.

Supported editor keys include `wordwrap`, `border_size`, `border_color`,
`background_color`, `text_color`, `current_line_color`,
`line_number_background`, `line_number_color`, `cursor_color`, `block_cursor`,
`font_family`, `font_size`, `line_height`, `pixels_above`, `pixels_below`,
`line_distance`, `show_line_numbers`, `highlight_current_line`,
`show_statusbar`, and `tab_width`.

## Gutter and current-line highlight

The existing line-number gutter continues to use `GtkTextView`'s left border
window and GTK 2 iter/line coordinate APIs. It enumerates logical buffer lines,
not visual wrapped rows. Colour changes redraw only the text view. Gutter width
is recalculated during expose using the current font and current line count.

Current-line highlighting is a `GtkTextTag` applied to the paragraph containing
the insertion mark. The tag is presentation state in the live `GtkTextBuffer`;
it does not add characters or serialized rich-text data, does not mark the
buffer modified and does not create an undo step. The previous highlighted
range is tracked by marks so cursor movement does not require clearing tags
across the entire document.

## Typography

Font family and point size use Pango descriptions. Tab width uses the existing
`indent.c` Pango-based tab-stop routine. Paragraph spacing uses GTK 2's
`pixels-above-lines`, `pixels-below-lines`, and `pixels-inside-wrap` support.
`line_height` is implemented as an approximate multiplier of the natural Pango
font height by distributing the added vertical space above and below logical
paragraph lines. `line_distance` controls inside-wrap spacing. GTK 2 does not
provide a single exact fractional line-height API, so exact typographic leading
may differ from a modern layout engine; the approximation is intentionally
visual-only.

## Block cursor strategy

When enabled, `gtk_text_view_set_cursor_visible(FALSE)` suppresses the native
thin caret on this editor widget only. The GSlate expose-event handler paints a
solid rectangle after normal text drawing in the `GTK_TEXT_WINDOW_TEXT`
GdkWindow. Its position is derived from the insertion mark and
`gtk_text_view_get_iter_location()` / `gtk_text_view_buffer_to_window_coords()`.
The width uses the next iterator's on-screen x-coordinate when it is on the
same visual row (which naturally handles tabs and many wide glyphs); at
end-of-line or where that measurement is unavailable, a Pango `M` width is the
fallback. A printable character is repainted over the block in a contrasting
colour when practical.

There is no timer and no periodic visibility toggle. The native caret is
hidden, so desktop cursor-blink preferences cannot make the custom block
blink. The block is drawn only while the editor widget has focus; it is
repainted on expose and queued after cursor/buffer/focus changes. When the mode
is disabled, the normal GTK cursor is restored. This is scoped to the editor
and does not change `GtkSettings` or other widgets.

The implementation is source-integrated but has not been visually verified in
this build environment because GTK 2 development/runtime libraries are not
installed here. Complex shaping cases (combining sequences, mixed fonts and
bidirectional text) require visual GUI testing on the target system. The block
uses a single character's geometry and cannot perfectly emulate every
terminal's overwrite-mode rendering.

## Menu actions

The Options menu adds highlight-current-line, block-cursor, status-bar,
full-screen, and reload-configuration actions. Word wrap uses `Ctrl+Shift+W` so it does not
conflict with Leafpad's existing hidden `Ctrl+W` close action. The existing
`Ctrl+H` replace action is preserved; current-line highlighting uses
`Ctrl+Shift+H`. Other additions are `Ctrl+B`, `Ctrl+L`, `Ctrl+Shift+B`, and
`Ctrl+Shift+R`. Shortcut values are currently fixed by the menu definitions; although the
configuration format is INI-based, shortcut values are not dynamically parsed
in this implementation.

## Build dependencies

GTK 2 is a hard requirement (`pkg-config gtk+-2.0`). The helper
`install-deps.sh` installs common Debian/Ubuntu build tools and the GTK 2
development package only when it exists in configured repositories. No GTK 3
or GTK 4 fallback is attempted. Native GTK printing remains controlled by the
original GTK version checks, with the original optional GNOME print fallback.

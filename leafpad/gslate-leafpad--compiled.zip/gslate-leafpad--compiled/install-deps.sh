#!/bin/sh
# Install the legacy GTK 2 build dependencies on Debian/Ubuntu systems.
# This script is intended to be executed, not sourced.
set -eu

if [ ! -r /etc/os-release ]; then
    echo "Cannot identify this operating system (missing /etc/os-release)." >&2
    exit 1
fi
. /etc/os-release
case "${ID:-}" in
    ubuntu|debian) ;;
    *) echo "This helper supports Ubuntu/Debian only; detected: ${PRETTY_NAME:-unknown}." >&2; exit 1 ;;
esac

if ! command -v apt-get >/dev/null 2>&1; then
    echo "apt-get is not available." >&2
    exit 1
fi

if [ "$(id -u)" -eq 0 ]; then
    SUDO=""
elif command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
else
    echo "Run as root or install sudo." >&2
    exit 1
fi

BASE_PACKAGES="build-essential autoconf automake autopoint gettext intltool pkg-config"
GTK_PACKAGE="libgtk2.0-dev"
# Refresh first so apt-cache sees the configured repositories.
# shellcheck disable=SC2086
$SUDO apt-get update
if ! apt-cache show "$GTK_PACKAGE" >/dev/null 2>&1; then
    echo "The package '$GTK_PACKAGE' is not available from the configured APT repositories." >&2
    echo "GSlate's source requires GTK 2 (pkg-config module gtk+-2.0); GTK 3/4 are not substitutes." >&2
    exit 2
fi

# shellcheck disable=SC2086
$SUDO apt-get install -y $BASE_PACKAGES "$GTK_PACKAGE"

if ! pkg-config --exists gtk+-2.0; then
    echo "GTK 2 installation did not provide gtk+-2.0.pc." >&2
    exit 3
fi
printf 'GTK 2 version: %s\n' "$(pkg-config --modversion gtk+-2.0)"
echo "Dependencies are ready. Build with: autoreconf -fi && ./configure && make"

# Build and validation record for this source package

Environment: Debian GNU/Linux 13 (trixie), x86_64 container.

| Check | Result | Notes |
|---|---|---|
| `sh -n install-deps.sh` | PASS | Dependency helper shell syntax. |
| `sh -n tests/test-source-smoke.sh` | PASS | Smoke-test shell syntax. |
| `sh tests/test-source-smoke.sh` | PASS | Confirms source integration points and GTK 2-only cursor strategy are present. |
| Python `configparser` on `gslate.ini.example` | PASS | Example INI parses and selected defaults match expected values. |
| `pycparser` syntax parse of `src/gslate.c` with GTK/GLib types stubbed | PASS | Checks C grammar only; it does not validate GTK symbols or ABI. |
| `pkg-config --modversion gtk+-2.0` | BLOCKED | `gtk+-2.0.pc` is not installed in this container. |
| `autoreconf -fi` | BLOCKED | Required `AC_PROG_INTLTOOL`, `AM_GLIB_GNU_GETTEXT`, and `AM_GLIB_DEFINE_LOCALEDIR` macros are absent in this container. |
| GTK 2 compilation and GUI tests | NOT RUN | GTK 2 development/runtime libraries are unavailable here. |
| 60-second block-cursor idle test | NOT RUN | Requires a running GTK 2 graphical session. |

Install the dependencies on a Debian/Ubuntu system with `./install-deps.sh`,
then run `autoreconf -fi && ./configure && make`. The helper checks whether the
GTK 2 development package is present in the configured APT repositories; it
will not substitute GTK 3 or GTK 4.

The source package is an implementation pass, not a claim of fully verified
GUI behaviour. Follow `TESTING.md` for target-system regression and manual
visual testing, especially cursor alignment for tabs, Unicode, combining
characters, wrapped lines, scrolling and resize.

## Follow-up correction from the user's build log (2026-11-12)

The first reported fatal error was in `src/linenum.c`: the GSlate gutter
implementation used four undeclared file-scope variables. They are now declared
privately in that module. See `BUILD-FIX-2026-11-12.md`. This correction is
source-reviewed and covered by the checks below; a complete GTK 2 rebuild was
not possible in this packaging container because its GTK 2 pkg-config metadata
is absent. A build on the target desktop is still required to reveal any later
translation-unit errors that the original build could not reach.

# GSlate test checklist

## Automated source smoke test

Run from the project root:

```sh
sh tests/test-source-smoke.sh
```

This checks that the key implementation files, configuration defaults and
required GTK 2 APIs are present. It is a source-integrity check, not a substitute
for compiling or interacting with the GUI.

## Build and manual regression

```sh
autoreconf -fi
./configure
make
./src/gslate
```

Verify new/open/save/save-as, unsaved-change prompts, encoding selection,
undo/redo, clipboard, find/replace, auto-indent, multi-line indent, drag/drop,
line numbers and printing (where compiled in).

## Visual checks

1. Check dark background/text colours and that the border colour/size update;
   test `border_size=0`.
2. Toggle word wrap and verify horizontal scrolling without text modification.
3. Check logical line numbers through scroll, resize, font changes, wrapped
   paragraphs, blank lines, paste, undo and redo.
4. Move the caret through several logical lines and confirm current-line
   highlighting follows it without modifying the file.
5. Check font family/size, tab width, paragraph spacing and Unicode fallback.
6. Check the status row reports 1-based logical line and column and hides
   without leaving a blank row. Check F11 full-screen and restore.
7. Enable Block Cursor, place the caret before ordinary text, tabs, wide
   Unicode, an empty line and end-of-buffer. Leave the editor idle for at least
   60 seconds. The solid block should not blink or disappear while focused.
8. Type, delete, select, scroll, resize, change font, switch wrap mode, and
   reload config while Block Cursor is enabled. Confirm no stale rectangle.
9. Disable Block Cursor and confirm the ordinary theme-controlled GTK caret is
   restored. Confirm menus and dialogs retain their normal caret behaviour.
10. Test under at least two GTK themes with cursor blinking enabled globally.

## Results in the supplied build container

See `BUILD-RESULTS.md` for the exact checks run and their results. The source
smoke tests pass, but GTK 2 compilation and GUI verification are blocked because
`gtk+-2.0.pc` and the required intltool/GLib gettext Autotools macros are not
installed. Do not interpret source smoke checks as proof of successful
compilation or visual cursor alignment.

cleaf = Leafpad 0.8.19 + appearance options + CMake build
=========================================================

Build (needs gtk+-2.0 >= 2.8 dev files, pkg-config, cmake >= 3.10, a C compiler;
msgfmt from gettext is optional and only needed for translations):

    Debian/Ubuntu:  sudo apt install build-essential cmake pkg-config \
                                     libgtk2.0-dev gettext

    cmake -S . -B build
    cmake --build build
    ./build/leafpad                 # run without installing
    sudo cmake --install build      # optional

CMake options:  -DENABLE_CHOOSER=ON|OFF   -DENABLE_EMACS=ON|OFF
                -DENABLE_NLS=ON|OFF       -DCMAKE_INSTALL_PREFIX=/usr/local

Command line options (new)
--------------------------
  -bw  --border-size        20px       border width around the text area
  -bc  --border-color       "#313244"  border colour
  -pa  --pixels_above       4px        extra pixels above every line
  -pb  --pixels_below       4px        extra pixels below every line
  -ct  --cursor-type        2          1 = caret, 2 = block
  -cb  --cursor-blink       1          1 = no blink, 2 = blink
  -bg  --background-color   "#1e1e2e" text background colour

Sizes accept "8" or "8px" (0-1000).  Colours: "#rrggbb" or any X11 name.
"--pixels-above" / "--pixels-below" are accepted as aliases.
Both "-bw 8" and "-bw=8" work.  Examples:

    leafpad -bw 0 -ct 1 -cb 2 notes.txt
    leafpad -bg "#ffffff" -bc "#dddddd" -pa 2 -pb 2

The text colour is chosen automatically (light text on a dark background,
dark text on a light one).

Source changes
--------------
  new   src/options.[ch]      option parsing / validation (GLib only)
  new   src/appearance.[ch]   colours, border frame, spacing, block cursor
  edit  src/main.c            registers the options, validates them
  edit  src/window.c          border frame + applies appearance to the view
  edit  src/linenum.c         line numbers follow --pixels_above
  edit  src/leafpad.h, src/Makefile.am, data/leafpad.1
  new   CMakeLists.txt, cmake/config.h.in

/*
 *  Leafpad - GTK+ based simple text editor
 *  Appearance command line options (see options.h)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include "options.h"
#include <errno.h>
#include <string.h>

AppOptions app_opts;

/* raw strings as typed by the user; converted in options_finalize() */
static gchar *raw_border_size  = NULL;
static gchar *raw_pixels_above = NULL;
static gchar *raw_pixels_below = NULL;

static const struct {
	const gchar *shortopt;
	const gchar *longopt;
} aliases[] = {
	{ "-bw", "--border-size"      },
	{ "-bc", "--border-color"     },
	{ "-pa", "--pixels_above"     },
	{ "-pb", "--pixels_below"     },
	{ "-ct", "--cursor-type"      },
	{ "-cb", "--cursor-blink"     },
	{ "-bg", "--background-color" },
	{ NULL, NULL }
};

void options_init(void)
{
	app_opts.border_size      = 20;
	app_opts.border_color     = g_strdup("#313244");
	app_opts.pixels_above     = 4;
	app_opts.pixels_below     = 4;
	app_opts.cursor_type      = CURSOR_TYPE_BLOCK;
	app_opts.cursor_blink     = CURSOR_BLINK_OFF;
	app_opts.background_color = g_strdup("#1e1e2e");

	/* GOption frees a previous string value, so these must be heap copies */
	g_free(raw_border_size);
	g_free(raw_pixels_above);
	g_free(raw_pixels_below);
	raw_border_size  = g_strdup("20px");
	raw_pixels_above = g_strdup("4px");
	raw_pixels_below = g_strdup("4px");
}

void options_rewrite_short_args(gint argc, gchar **argv)
{
	gint i, k;
	gsize len;
	
	for (i = 1; i < argc; i++) {
		if (!argv[i])
			continue;
		if (strcmp(argv[i], "--") == 0)
			break;
		for (k = 0; aliases[k].shortopt; k++) {
			len = strlen(aliases[k].shortopt);
			if (strncmp(argv[i], aliases[k].shortopt, len) != 0)
				continue;
			if (argv[i][len] == '\0') {                 /* -bw 10 */
				argv[i] = g_strdup(aliases[k].longopt);
				break;
			}
			if (argv[i][len] == '=') {                  /* -bw=10 */
				argv[i] = g_strconcat(aliases[k].longopt,
					argv[i] + len, NULL);
				break;
			}
		}
	}
}

void options_add_to_context(GOptionContext *context)
{
	GOptionEntry entries[] = {
		{ "border-size", 0, 0, G_OPTION_ARG_STRING, &raw_border_size,
		  "Border width around the text area (-bw) [20px]", "SIZE" },
		{ "border-color", 0, 0, G_OPTION_ARG_STRING, &app_opts.border_color,
		  "Border colour (-bc) [#313244]", "COLOR" },
		{ "pixels_above", 0, 0, G_OPTION_ARG_STRING, &raw_pixels_above,
		  "Pixels above each line (-pa) [4px]", "SIZE" },
		{ "pixels_below", 0, 0, G_OPTION_ARG_STRING, &raw_pixels_below,
		  "Pixels below each line (-pb) [4px]", "SIZE" },
		{ "cursor-type", 0, 0, G_OPTION_ARG_INT, &app_opts.cursor_type,
		  "Cursor type (-ct): 1=caret, 2=block [2]", "N" },
		{ "cursor-blink", 0, 0, G_OPTION_ARG_INT, &app_opts.cursor_blink,
		  "Cursor blink (-cb): 1=no-blink, 2=blink [1]", "N" },
		{ "background-color", 0, 0, G_OPTION_ARG_STRING,
		  &app_opts.background_color,
		  "Text background colour (-bg) [#1e1e2e]", "COLOR" },
		/* hyphenated spellings of the two underscore options */
		{ "pixels-above", 0, G_OPTION_FLAG_HIDDEN, G_OPTION_ARG_STRING,
		  &raw_pixels_above, NULL, NULL },
		{ "pixels-below", 0, G_OPTION_FLAG_HIDDEN, G_OPTION_ARG_STRING,
		  &raw_pixels_below, NULL, NULL },
		{ NULL }
	};
	
	g_option_context_add_main_entries(context, entries, NULL);
}

gboolean options_parse_px(const gchar *str, gint *out)
{
	gchar *end;
	gint64 val;
	
	if (!str)
		return FALSE;
	while (g_ascii_isspace(*str))
		str++;
	if (!g_ascii_isdigit(*str))
		return FALSE;
	errno = 0;
	val = g_ascii_strtoll(str, &end, 10);
	if (errno || val > OPT_MAX_PIXELS)
		return FALSE;
	while (g_ascii_isspace(*end))
		end++;
	if (g_ascii_strncasecmp(end, "px", 2) == 0)
		end += 2;
	while (g_ascii_isspace(*end))
		end++;
	if (*end != '\0')
		return FALSE;
	
	*out = (gint)val;
	return TRUE;
}

static gboolean parse_px_option(const gchar *name, const gchar *value,
	gint *out, GError **error)
{
	if (options_parse_px(value, out))
		return TRUE;
	g_set_error(error, G_OPTION_ERROR, G_OPTION_ERROR_BAD_VALUE,
		"invalid value '%s' for --%s (expected 0-%d, e.g. 4 or 4px)",
		value ? value : "", name, OPT_MAX_PIXELS);
	return FALSE;
}

gboolean options_finalize(GError **error)
{
	if (!parse_px_option("border-size",  raw_border_size,
			&app_opts.border_size, error)
	 || !parse_px_option("pixels_above", raw_pixels_above,
			&app_opts.pixels_above, error)
	 || !parse_px_option("pixels_below", raw_pixels_below,
			&app_opts.pixels_below, error))
		return FALSE;
	
	if (app_opts.cursor_type != CURSOR_TYPE_CARET
	 && app_opts.cursor_type != CURSOR_TYPE_BLOCK) {
		g_set_error(error, G_OPTION_ERROR, G_OPTION_ERROR_BAD_VALUE,
			"invalid value '%d' for --cursor-type (1=caret, 2=block)",
			app_opts.cursor_type);
		return FALSE;
	}
	if (app_opts.cursor_blink != CURSOR_BLINK_OFF
	 && app_opts.cursor_blink != CURSOR_BLINK_ON) {
		g_set_error(error, G_OPTION_ERROR, G_OPTION_ERROR_BAD_VALUE,
			"invalid value '%d' for --cursor-blink (1=no-blink, 2=blink)",
			app_opts.cursor_blink);
		return FALSE;
	}
	return TRUE;
}

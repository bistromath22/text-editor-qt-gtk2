/*
 *  Leafpad - GTK+ based simple text editor
 *  Appearance: colours, border, line spacing, cursor style (cleaf additions)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include "leafpad.h"
#include <pango/pangocairo.h>

static GdkColor bg_color;      /* text background           */
static GdkColor fg_color;      /* text + cursor colour      */
static GdkColor border_color;  /* frame colour              */

static gboolean view_focused = FALSE;
static gboolean block_visible = TRUE;   /* blink phase of the block cursor */
static guint blink_id = 0;

/* ------------------------------------------------------------------ */
/* colours                                                             */
/* ------------------------------------------------------------------ */

static gboolean parse_color(const gchar *optname, const gchar *spec,
	GdkColor *color, GError **error)
{
	if (spec && gdk_color_parse(spec, color))
		return TRUE;
	g_set_error(error, G_OPTION_ERROR, G_OPTION_ERROR_BAD_VALUE,
		"invalid colour '%s' for --%s (try #rrggbb)",
		spec ? spec : "", optname);
	return FALSE;
}

gboolean appearance_init(GError **error)
{
	gdouble lum;
	
	if (!parse_color("background-color", app_opts.background_color,
			&bg_color, error)
	 || !parse_color("border-color", app_opts.border_color,
			&border_color, error))
		return FALSE;
	
	/* Pick a readable text colour for the chosen background:
	 * light text on a dark background, dark text on a light one. */
	lum = (0.299 * bg_color.red + 0.587 * bg_color.green
		+ 0.114 * bg_color.blue) / 65535.0;
	gdk_color_parse(lum < 0.5 ? "#cdd6f4" : "#1e1e2e", &fg_color);
	
	return TRUE;
}

/* ------------------------------------------------------------------ */
/* border                                                              */
/* ------------------------------------------------------------------ */

GtkWidget *appearance_wrap_border(GtkWidget *sw)
{
	GtkWidget *box, *align;
	guint b = app_opts.border_size;
	
	if (b == 0)
		return sw;
	
	box = gtk_event_box_new();
	gtk_widget_modify_bg(box, GTK_STATE_NORMAL, &border_color);
	
	align = gtk_alignment_new(0.0, 0.0, 1.0, 1.0);
	gtk_alignment_set_padding(GTK_ALIGNMENT(align), b, b, b, b);
	
	gtk_container_add(GTK_CONTAINER(align), sw);
	gtk_container_add(GTK_CONTAINER(box), align);
	
	return box;
}

/* ------------------------------------------------------------------ */
/* block cursor (GTK+ 2 has no native one, so it is drawn here)        */
/* ------------------------------------------------------------------ */

static void get_font_metrics(GtkWidget *view, gint *char_width, gint *height)
{
	PangoContext *ctx = gtk_widget_get_pango_context(view);
	PangoFontMetrics *m = pango_context_get_metrics(ctx,
		view->style->font_desc, pango_context_get_language(ctx));
	
	*char_width = PANGO_PIXELS(pango_font_metrics_get_approximate_char_width(m));
	*height = PANGO_PIXELS(pango_font_metrics_get_ascent(m)
		+ pango_font_metrics_get_descent(m));
	pango_font_metrics_unref(m);
}

/* Cursor cell in text-window coordinates, and the character under it. */
static void get_cursor_cell(GtkWidget *view, GdkRectangle *cell, gunichar *ch)
{
	GtkTextView *tv = GTK_TEXT_VIEW(view);
	GtkTextBuffer *buffer = gtk_text_view_get_buffer(tv);
	GtkTextIter iter;
	GdkRectangle loc;
	gint cw, ch_h;
	
	gtk_text_buffer_get_iter_at_mark(buffer, &iter,
		gtk_text_buffer_get_insert(buffer));
	gtk_text_view_get_iter_location(tv, &iter, &loc);
	gtk_text_view_buffer_to_window_coords(tv, GTK_TEXT_WINDOW_TEXT,
		loc.x, loc.y, &cell->x, &cell->y);
	
	*ch = gtk_text_iter_get_char(&iter);
	get_font_metrics(view, &cw, &ch_h);
	
	cell->width  = loc.width;
	cell->height = loc.height;
	if (*ch == 0 || *ch == '\n' || *ch == '\r' || cell->width <= 0)
		cell->width = cw;          /* end of line / end of buffer */
	if (cell->width < 2)
		cell->width = 2;
	if (cell->height <= 0)
		cell->height = ch_h;
}

static void invalidate_cursor(GtkWidget *view)
{
	GdkWindow *win;
	GdkRectangle cell;
	gunichar ch;
	
	win = gtk_text_view_get_window(GTK_TEXT_VIEW(view), GTK_TEXT_WINDOW_TEXT);
	if (!win)
		return;
	get_cursor_cell(view, &cell, &ch);
	cell.x--; cell.y--; cell.width += 2; cell.height += 2;
	gdk_window_invalidate_rect(win, &cell, FALSE);
}

static gboolean cb_expose_block_cursor(GtkWidget *view, GdkEventExpose *event)
{
	GdkWindow *win;
	GdkRectangle cell;
	gunichar ch;
	cairo_t *cr;
	
	win = gtk_text_view_get_window(GTK_TEXT_VIEW(view), GTK_TEXT_WINDOW_TEXT);
	if (!win || event->window != win)
		return FALSE;
	if (view_focused && !block_visible)      /* blink: "off" phase */
		return FALSE;
	
	get_cursor_cell(view, &cell, &ch);
	
	cr = gdk_cairo_create(win);
	gdk_cairo_rectangle(cr, &event->area);
	cairo_clip(cr);
	gdk_cairo_set_source_color(cr, &fg_color);
	
	if (view_focused) {
		cairo_rectangle(cr, cell.x, cell.y, cell.width, cell.height);
		cairo_fill(cr);
		
		/* redraw the character under the block in the background colour */
		if (ch != '\t' && g_unichar_isprint(ch)) {
			gchar utf8[8];
			PangoLayout *layout;
			
			utf8[g_unichar_to_utf8(ch, utf8)] = '\0';
			layout = gtk_widget_create_pango_layout(view, utf8);
			gdk_cairo_set_source_color(cr, &bg_color);
			cairo_move_to(cr, cell.x, cell.y);
			pango_cairo_show_layout(cr, layout);
			g_object_unref(layout);
		}
	} else {
		/* unfocused window: hollow block, like most terminals */
		cairo_set_line_width(cr, 1.0);
		cairo_rectangle(cr, cell.x + 0.5, cell.y + 0.5,
			cell.width - 1, cell.height - 1);
		cairo_stroke(cr);
	}
	cairo_destroy(cr);
	
	return FALSE;
}

static gboolean cb_blink_timeout(gpointer data)
{
	GtkWidget *view = GTK_WIDGET(data);
	
	if (view_focused) {
		block_visible = !block_visible;
		invalidate_cursor(view);
	}
	return TRUE;
}

/* Cursor moved / text changed / focus changed: show it and restart blinking */
static void blink_reset(GtkWidget *view)
{
	if (blink_id) {
		g_source_remove(blink_id);
		blink_id = 0;
	}
	block_visible = TRUE;
	if (app_opts.cursor_blink == CURSOR_BLINK_ON && view_focused) {
		gint t = 1200;
		
		g_object_get(gtk_widget_get_settings(view),
			"gtk-cursor-blink-time", &t, NULL);
		blink_id = g_timeout_add(MAX(t / 2, 200), cb_blink_timeout, view);
	}
	gtk_widget_queue_draw(view);
}

static gboolean cb_focus_block_cursor(GtkWidget *view, GdkEventFocus *event)
{
	view_focused = event->in ? TRUE : FALSE;
	blink_reset(view);
	return FALSE;
}

static void cb_mark_set_block_cursor(GtkTextBuffer *buffer,
	GtkTextIter *iter, GtkTextMark *mark, GtkWidget *view)
{
	if (mark == gtk_text_buffer_get_insert(buffer))
		blink_reset(view);
}

static void cb_changed_block_cursor(GtkTextBuffer *buffer, GtkWidget *view)
{
	blink_reset(view);
}

/* ------------------------------------------------------------------ */
/* view                                                                */
/* ------------------------------------------------------------------ */

void appearance_apply_view(GtkWidget *view)
{
	GtkTextView *tv = GTK_TEXT_VIEW(view);
	GtkTextBuffer *buffer = gtk_text_view_get_buffer(tv);
	
	/* colours: the cursor and the line-number gutter follow these */
	gtk_widget_modify_base(view, GTK_STATE_NORMAL, &bg_color);
	gtk_widget_modify_text(view, GTK_STATE_NORMAL, &fg_color);
	
	/* line spacing */
	gtk_text_view_set_pixels_above_lines(tv, app_opts.pixels_above);
	gtk_text_view_set_pixels_below_lines(tv, app_opts.pixels_below);
	
	/* blinking of the normal caret; the block cursor blinks by itself */
	g_object_set(gtk_widget_get_settings(view), "gtk-cursor-blink",
		app_opts.cursor_type == CURSOR_TYPE_CARET
			&& app_opts.cursor_blink == CURSOR_BLINK_ON, NULL);
	
	/* block cursor: draw our own, and hide GTK's caret by painting it in the
	 * background colour. (gtk_text_view_set_cursor_visible(FALSE) must NOT be
	 * used: GTK then turns Up/Down/Home/End into scrolling commands.) */
	if (app_opts.cursor_type == CURSOR_TYPE_BLOCK) {
		gchar *rc = g_strdup_printf(
			"style \"cleaf-hide-caret\" {\n"
			"  GtkWidget::cursor-color = \"#%04x%04x%04x\"\n"
			"  GtkWidget::secondary-cursor-color = \"#%04x%04x%04x\"\n"
			"}\n"
			"class \"GtkTextView\" style \"cleaf-hide-caret\"\n",
			bg_color.red, bg_color.green, bg_color.blue,
			bg_color.red, bg_color.green, bg_color.blue);
		gtk_rc_parse_string(rc);
		g_free(rc);
		gtk_rc_reset_styles(gtk_widget_get_settings(view));
		
		g_signal_connect_after(G_OBJECT(view), "expose-event",
			G_CALLBACK(cb_expose_block_cursor), NULL);
		g_signal_connect_after(G_OBJECT(view), "focus-in-event",
			G_CALLBACK(cb_focus_block_cursor), NULL);
		g_signal_connect_after(G_OBJECT(view), "focus-out-event",
			G_CALLBACK(cb_focus_block_cursor), NULL);
		g_signal_connect_after(G_OBJECT(buffer), "mark-set",
			G_CALLBACK(cb_mark_set_block_cursor), view);
		g_signal_connect_after(G_OBJECT(buffer), "changed",
			G_CALLBACK(cb_changed_block_cursor), view);
	}
}

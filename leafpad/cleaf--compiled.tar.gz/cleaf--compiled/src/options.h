/*
 *  Leafpad - GTK+ based simple text editor
 *
 *  Appearance command line options (cleaf additions):
 *    -bw / --border-size       border width in px          (default 20px)
 *    -bc / --border-color      border colour               (default #313244)
 *    -pa / --pixels_above      pixels above each line      (default 4px)
 *    -pb / --pixels_below      pixels below each line      (default 4px)
 *    -ct / --cursor-type       1 = caret, 2 = block        (default 2)
 *    -cb / --cursor-blink      1 = no blink, 2 = blink     (default 1)
 *    -bg / --background-color  text background colour      (default #1e1e2e)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#ifndef _OPTIONS_H
#define _OPTIONS_H

#include <glib.h>

#define CURSOR_TYPE_CARET  1
#define CURSOR_TYPE_BLOCK  2
#define CURSOR_BLINK_OFF   1
#define CURSOR_BLINK_ON    2

#define OPT_MAX_PIXELS     1000

typedef struct {
	gint   border_size;       /* px */
	gchar *border_color;      /* colour string, validated by appearance.c */
	gint   pixels_above;      /* px */
	gint   pixels_below;      /* px */
	gint   cursor_type;       /* CURSOR_TYPE_* */
	gint   cursor_blink;      /* CURSOR_BLINK_* */
	gchar *background_color;  /* colour string, validated by appearance.c */
} AppOptions;

extern AppOptions app_opts;

/* Fill app_opts with the defaults. Call once, before parsing. */
void options_init(void);

/* GOption has no multi-letter short options, so "-bw 10" is rewritten to
 * "--border-size 10" (also "-bw=10") in argv before GOption sees it. */
void options_rewrite_short_args(gint argc, gchar **argv);

/* Register the appearance options as main entries of the context. */
void options_add_to_context(GOptionContext *context);

/* Convert/validate what GOption stored. FALSE + *error on bad input. */
gboolean options_finalize(GError **error);

/* "20", "20px", " 20 PX " -> 20.  FALSE if not a non-negative pixel value. */
gboolean options_parse_px(const gchar *str, gint *out);

#endif /* _OPTIONS_H */

/*
 *  Leafpad - GTK+ based simple text editor
 *  Appearance: colours, border, line spacing, cursor style (cleaf additions)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#ifndef _APPEARANCE_H
#define _APPEARANCE_H

/* Parse/validate the colour options. Call after options_finalize(),
 * before gtk_init(). FALSE + *error if a colour cannot be parsed. */
gboolean appearance_init(GError **error);

/* Wrap the scrolled window in a coloured frame of app_opts.border_size px.
 * Returns the widget to pack in place of the scrolled window. */
GtkWidget *appearance_wrap_border(GtkWidget *scrolled_window);

/* Apply background/text colour, line spacing and cursor style to the view.
 * Call after gtk_init(), right after the GtkTextView is created. */
void appearance_apply_view(GtkWidget *view);

#endif /* _APPEARANCE_H */

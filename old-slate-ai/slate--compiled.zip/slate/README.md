# Slate

Slate is a lightweight native Linux plain-text editor built with C++17 and Qt 6 Widgets. It uses a single document window, a dark editing surface, an optional logical-line gutter, and a small INI configuration file. It is not an IDE or a rich-text word processor.

## Dependencies

- CMake 3.16+
- A C++17 compiler
- Qt 6 Widgets development files (`qt6-base-dev` on Debian/Ubuntu)
- Qt 6 Test development files (`qt6-base-dev` generally provides Qt Test; install the platform's Qt Test package if split)

## Build and test

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
sudo cmake --install build
```

The test target is added when Qt 6 Test is available. On systems without Qt 6, CMake configuration will fail at `find_package(Qt6 ...)`; the source tree remains complete but compilation and GUI tests cannot be verified there.

## Run

```sh
slate [files...]
slate --config /path/to/config.ini [files...]
slate --print-config
slate --print-config-paths
slate --help
slate --version
```

There is one active document and no tabs. If multiple paths are passed, the first is opened and additional paths are reported as unsupported. A UTF-8 BOM is stripped on load. File output is UTF-8 with LF line endings. Save uses `QSaveFile` so an unsuccessful write does not replace the previous file.

## Configuration

Discovery order is `./config.ini`, `${XDG_CONFIG_HOME:-~/.config}/slate/config.ini`, then `/etc/slate/config.ini`. `--config PATH` overrides discovery. Missing configuration uses the same canonical defaults printed by `--print-config`. Partial files override only keys they contain. Invalid colors and out-of-range numeric values fall back to defaults; invalid shortcut sequences retain their defaults.

Copy `config.example.ini` to `config.ini` and edit it. `border_color` and `border_size` apply to Slate's editor surround only. They do not alter the desktop environment's native title bar/window-manager decorations.

## Shortcuts

| Action | Default |
|---|---|
| New / Open / Save / Save As / Quit | Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S / Ctrl+Q |
| Find / Find Next / Go to Line | Ctrl+F / F3 / Ctrl+G |
| Reload Config | Ctrl+R |
| Word Wrap / Block Cursor | Ctrl+W / Ctrl+B |
| Increase / Decrease Font | Ctrl++ / Ctrl+- |
| Full Screen | F11 |
| Line Numbers / Current-Line Highlight / Status Bar | Ctrl+L / Ctrl+H / Ctrl+Shift+B |

## Technical design note

- **Document and newline model:** `QTextDocument` is the sole logical document model. Its blocks represent stored paragraph breaks; visual wrapping is layout-only. External CRLF is normalized to LF before remaining CR characters are normalized. Leading, repeated, and trailing newline characters are passed through the text API. UTF-8 BOM is stripped at file-load boundaries.
- **Clipboard:** rich text is disabled. The custom MIME insertion path accepts text only, normalizes line endings, inserts at the active cursor/selection, and wraps the insertion and affected-block formatting in an edit block. Non-text-only MIME payloads are ignored. Copy/cut use QTextEdit's plain-text path.
- **Paragraph presentation:** proportional block line height is used (`line_height * 100` percent), with `pixels_above` and `pixels_below` as paragraph margins. `line_distance` is an additional bottom paragraph spacing term. These are presentation properties and are not serialized into text.
- **Layout and border:** `EditorFrame` owns the four-sided editor surround and its independent content margins. The editor owns its left line-number gutter through `setViewportMargins`; the main window owns the status bar. No status-bar height is used as editor padding. The border frame paints itself in its own paint event; no viewport paint event paints the outer editor widget.
- **Gutter:** line numbers count QTextBlocks (logical paragraphs), while block geometry follows the document layout so wrapped paragraphs occupy the correct vertical space. The gutter scrolls with the editor.

## Manual GUI checks

After building, check normal (~900x600), maximized, and full-screen modes; resize down to the minimum size; toggle status bar and line numbers; test word wrap on/off; change font size and line-height; paste a large multiline Unicode document and scroll to its final line. Set `border_color=#ff0000`, reload, then change it to `#00ff00` and reload. Verify all four surround edges change while the text viewport and status bar retain their own colors. Run from a terminal and check for QPainter warnings. These visual checks are instructions, not claims that they have been performed in this build environment.

## Known implementation scope

The project intentionally omits tabs, split panes, syntax highlighting, toolbars, plugins, and IDE features. Native window decorations remain controlled by the desktop environment. See `DESIGN.md` for implementation caveats and the defect-correction summary.

#include "Editor.h"
#include "TextNormalization.h"
#include <QAbstractTextDocumentLayout>
#include <QApplication>
#include <QFontDatabase>
#include <QFontInfo>
#include <QKeyEvent>
#include <QCursor>
#include <QMimeData>
#include <QPainter>
#include <QScrollBar>
#include <QTextBlock>
#include <QTextBlockFormat>
#include <QTextCursor>
#include <QVBoxLayout>

class LineNumberArea : public QWidget {
public:
    explicit LineNumberArea(Editor *editor) : QWidget(editor), m_editor(editor) {}
    QSize sizeHint() const override { return QSize(m_editor->lineNumberAreaWidth(),0); }
protected:
    void paintEvent(QPaintEvent *event) override { m_editor->lineNumberAreaPaintEvent(event); }
private: Editor *m_editor;
};

Editor::Editor(QWidget *parent) : QTextEdit(parent) {
    setAcceptRichText(false); setTabStopDistance(QFontMetricsF(font()).horizontalAdvance(' ') * 4.0);
    m_lineNumberArea=new LineNumberArea(this);
    connect(this,&QTextEdit::cursorPositionChanged,this,&Editor::highlightCurrentLine);
    connect(this,&QTextEdit::textChanged,this,&Editor::updateLineNumberAreaWidth);
    connect(this,&QTextEdit::textChanged,this,[this]{ m_lineNumberArea->update(); });
    connect(verticalScrollBar(),&QScrollBar::valueChanged,m_lineNumberArea,qOverload<>(&QWidget::update));
    applyConfig(m_config);
    document()->setUndoRedoEnabled(false); document()->setUndoRedoEnabled(true);
}
QString Editor::plainText() const { return TextNormalization::normalizeNewlines(toPlainText()); }
void Editor::setPlainTextNormalized(const QString &text) {
    setPlainText(TextNormalization::normalizeNewlines(text));
    applyAllParagraphFormats();
    document()->setUndoRedoEnabled(false); document()->setUndoRedoEnabled(true);
    document()->setModified(false); highlightCurrentLine();
}
int Editor::lineNumberAreaWidth() const {
    if(!m_config.showLineNumbers) return 0;
    int digits=1, max=qMax(1,document()->blockCount()); while(max>=10){max/=10;++digits;}
    return 10 + fontMetrics().horizontalAdvance(QLatin1Char('9'))*digits;
}
void Editor::updateLineNumberAreaWidth(){ setViewportMargins(lineNumberAreaWidth(),0,0,0); }
void Editor::updateLineNumberArea(const QRect &rect,int dy){
    if(dy) m_lineNumberArea->scroll(0,dy); else m_lineNumberArea->update(0,rect.y(),m_lineNumberArea->width(),rect.height());
    if(rect.contains(viewport()->rect())) updateLineNumberAreaWidth();
}
void Editor::resizeEvent(QResizeEvent *event){ QTextEdit::resizeEvent(event); QRect cr=contentsRect(); m_lineNumberArea->setGeometry(QRect(cr.left(),cr.top(),lineNumberAreaWidth(),cr.height())); }
void Editor::lineNumberAreaPaintEvent(QPaintEvent *event){
    QPainter painter(m_lineNumberArea);
    painter.fillRect(event->rect(),m_config.borderColor);
    for (QTextBlock block=document()->begin(); block.isValid(); block=block.next()) {
        QTextCursor cursor(block);
        const QRect r=cursorRect(cursor);
        if (r.bottom()<event->rect().top() || r.top()>event->rect().bottom()) continue;
        painter.setPen(m_config.lineNumberColor);
        painter.drawText(0,r.top(),m_lineNumberArea->width()-5,fontMetrics().height(),
                         Qt::AlignRight|Qt::AlignTop,QString::number(block.blockNumber()+1));
    }
}

void Editor::applyParagraphFormat(QTextBlock block){
    if(!block.isValid()) return;
    QTextBlockFormat fmt=block.blockFormat();
    fmt.setLineHeight(m_config.lineHeight*100.0,QTextBlockFormat::ProportionalHeight);
    fmt.setTopMargin(m_config.pixelsAbove); fmt.setBottomMargin(m_config.pixelsBelow+m_config.lineDistance);
    QTextCursor c(block); c.setBlockFormat(fmt);
}
void Editor::applyAllParagraphFormats(){
    QTextCursor c(document()); c.beginEditBlock();
    for(QTextBlock b=document()->begin();b.isValid();b=b.next()) applyParagraphFormat(b);
    c.endEditBlock();
}
void Editor::applyConfig(const EditorConfig &config){
    const bool wasModified=document()->isModified(); const int pos=textCursor().position();
    m_config=config; QFont f(config.fontFamily); if(!QFontInfo(f).exactMatch()) f=QFontDatabase::systemFont(QFontDatabase::FixedFont);
    f.setPointSize(config.fontSize); setFont(f); document()->setDefaultFont(f);
    QPalette p=palette(); p.setColor(QPalette::Base,config.backgroundColor); p.setColor(QPalette::Text,config.textColor); setPalette(p);
    setWordWrapMode(config.wordWrap?QTextOption::WrapAtWordBoundaryOrAnywhere:QTextOption::NoWrap);
    setBlockCursor(config.blockCursor); updateLineNumberAreaWidth(); m_lineNumberArea->setVisible(config.showLineNumbers);
    applyAllParagraphFormats(); QTextCursor cur(document()); cur.setPosition(qBound(0,pos,document()->characterCount()-1)); setTextCursor(cur);
    document()->setModified(wasModified); highlightCurrentLine(); viewport()->update(); m_lineNumberArea->update();
}
void Editor::setLineNumbersVisible(bool visible){m_config.showLineNumbers=visible;m_lineNumberArea->setVisible(visible);updateLineNumberAreaWidth();}
void Editor::setBlockCursor(bool enabled){m_config.blockCursor=enabled; viewport()->setCursor(QCursor(Qt::IBeamCursor));}
void Editor::setFontPointSize(int size){ if(size<6||size>96)return; m_config.fontSize=size; QFont f=font();f.setPointSize(size);setFont(f);document()->setDefaultFont(f);setTabStopDistance(QFontMetricsF(f).horizontalAdvance(' ')*4.0);applyAllParagraphFormats();updateLineNumberAreaWidth(); }
void Editor::highlightCurrentLine(){
    QList<QTextEdit::ExtraSelection> selections;
    if(!isReadOnly() && m_config.highlightCurrentLine){ QTextEdit::ExtraSelection s; s.format.setBackground(m_config.currentLineColor); s.format.setProperty(QTextFormat::FullWidthSelection,true); s.cursor=textCursor();s.cursor.clearSelection();selections<<s; }
    if (m_config.blockCursor && !isReadOnly()) {
        QTextEdit::ExtraSelection block;
        block.cursor=textCursor();
        if (block.cursor.position()<document()->characterCount()-1) block.cursor.movePosition(QTextCursor::NextCharacter,QTextCursor::KeepAnchor);
        block.format.setBackground(m_config.textColor);
        block.format.setForeground(m_config.backgroundColor);
        selections << block;
    }
    setExtraSelections(selections);
}
QMimeData *Editor::createMimeDataFromSelection() const {
    auto *mime=new QMimeData;
    mime->setText(TextNormalization::normalizeNewlines(textCursor().selectedText().replace(QChar::ParagraphSeparator, QChar('\n'))));
    return mime;
}
void Editor::insertFromMimeData(const QMimeData *source){
    if(!source || !source->hasText()) return;
    const QString text=TextNormalization::normalizeNewlines(source->text());
    QTextCursor c=textCursor(); QTextBlock first=c.block(); c.beginEditBlock(); c.insertText(text);
    const QTextBlock last=c.block();
    for(QTextBlock b=first; b.isValid(); b=b.next()){ applyParagraphFormat(b); if(b==last) break; }
    c.endEditBlock(); setTextCursor(c); ensureCursorVisible(); m_lineNumberArea->update();
}
void Editor::keyPressEvent(QKeyEvent *event){
    if((event->key()==Qt::Key_Return||event->key()==Qt::Key_Enter) && !(event->modifiers()&(Qt::ControlModifier|Qt::AltModifier|Qt::MetaModifier))){
        QTextCursor c=textCursor(); c.beginEditBlock(); c.insertBlock(); applyParagraphFormat(c.block()); applyParagraphFormat(c.block().previous()); c.endEditBlock(); setTextCursor(c); ensureCursorVisible(); return;
    }
    QTextEdit::keyPressEvent(event);
}
EditorFrame::EditorFrame(Editor *editor,QWidget *parent):QFrame(parent){
    setObjectName("slateEditorFrame"); setFrameShape(QFrame::NoFrame); auto *layout=new QVBoxLayout(this); layout->setSpacing(0);layout->setContentsMargins(m_borderSize,m_borderSize,m_borderSize,m_borderSize);layout->addWidget(editor);setAutoFillBackground(false);
}
void EditorFrame::setBorder(int size,const QColor &color){m_borderSize=qBound(0,size,64);m_borderColor=color; if(auto *l=qobject_cast<QVBoxLayout*>(layout()))l->setContentsMargins(m_borderSize,m_borderSize,m_borderSize,m_borderSize);updateGeometry();update();}
void EditorFrame::paintEvent(QPaintEvent *event){Q_UNUSED(event);QPainter p(this);p.fillRect(rect(),m_borderSize?m_borderColor:Qt::transparent);}

#pragma once
#include <QColor>
#include <QHash>
#include <QKeySequence>
#include <QString>
#include <QStringList>

struct EditorConfig {
    bool wordWrap = true;
    int borderSize = 8;
    QColor borderColor = QColor("#313244");
    QColor backgroundColor = QColor("#1e1e2e");
    QColor currentLineColor = QColor("#313244");
    QColor lineNumberColor = QColor("#6c7086");
    QColor textColor = QColor("#cdd6f4");
    bool blockCursor = false;
    QString fontFamily = QStringLiteral("Monospace");
    int fontSize = 12;
    double lineHeight = 1.4;
    int pixelsAbove = 0;
    int pixelsBelow = 0;
    int lineDistance = 0;
    bool showLineNumbers = true;
    bool highlightCurrentLine = true;
    bool showStatusBar = true;
    static EditorConfig defaults() { return EditorConfig{}; }
};

class ConfigManager {
public:
    explicit ConfigManager(QString overridePath = {});
    bool load(QString *error = nullptr);
    QString activePath() const { return m_activePath; }
    QStringList searchPaths() const { return m_searchPaths; }
    bool usingDefaults() const { return m_usingDefaults; }
    const EditorConfig &config() const { return m_config; }
    const QHash<QString, QKeySequence> &shortcuts() const { return m_shortcuts; }
    static QString defaultIni();
    static QHash<QString, QKeySequence> defaultShortcuts();
private:
    QString m_overridePath, m_activePath;
    QStringList m_searchPaths;
    bool m_usingDefaults = true;
    EditorConfig m_config = EditorConfig::defaults();
    QHash<QString, QKeySequence> m_shortcuts;
};

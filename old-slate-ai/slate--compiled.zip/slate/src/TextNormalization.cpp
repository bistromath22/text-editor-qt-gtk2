#include "TextNormalization.h"
#include <QByteArray>

namespace TextNormalization {
QString normalizeNewlines(const QString &text) {
    QString out = text;
    out.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    out.replace(QChar('\r'), QChar('\n'));
    return out;
}
QString decodeUtf8(const QByteArray &bytes) {
    QByteArray data = bytes;
    if (data.startsWith("\xEF\xBB\xBF")) data.remove(0, 3); // Strip UTF-8 BOM.
    return normalizeNewlines(QString::fromUtf8(data));
}
QByteArray encodeUtf8(const QString &text) {
    return normalizeNewlines(text).toUtf8();
}
}

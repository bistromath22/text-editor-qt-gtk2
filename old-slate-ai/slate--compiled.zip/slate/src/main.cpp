#include "MainWindow.h"
#include "ConfigManager.h"
#include <QApplication>
#include <QCommandLineParser>
#include <QFileInfo>
#include <QTextStream>
#include <QStatusBar>

int main(int argc,char **argv){
    QApplication app(argc,argv);QCoreApplication::setApplicationName("slate");QCoreApplication::setApplicationVersion("1.0.0");QCoreApplication::setOrganizationName("Slate");
    QCommandLineParser parser;parser.setApplicationDescription("Slate lightweight plain-text editor");parser.addHelpOption();parser.addVersionOption();
    QCommandLineOption configOpt("config","Use configuration file PATH.","PATH");QCommandLineOption printConfig("print-config","Print canonical default configuration and exit.");QCommandLineOption printPaths("print-config-paths","Print configuration search order and active path.");
    parser.addOption(configOpt);parser.addOption(printConfig);parser.addOption(printPaths);parser.addPositionalArgument("files","Text files to open.");parser.process(app);
    if(parser.isSet(printConfig)){QTextStream(stdout)<<ConfigManager::defaultIni();return 0;}
    ConfigManager config(parser.value(configOpt));QString err;config.load(&err);
    if(parser.isSet(printPaths)){QTextStream out(stdout);for(const auto &p:config.searchPaths())out<< (QFileInfo::exists(p)?"found   ":"missing ")<<p<<'\n';out<<"active: "<<(config.activePath().isEmpty()?"(built-in defaults)":config.activePath())<<'\n';out<<"using defaults: "<<(config.usingDefaults()?"yes":"no")<<'\n';return 0;}
    MainWindow window(&config);if(!err.isEmpty())window.statusBar()->showMessage(err,7000);const QStringList files=parser.positionalArguments();window.openFiles(files);if(!files.isEmpty())window.showMaximized();else window.show();return app.exec();
}

#pragma once
#include <QMainWindow>
#include <functional>
#include <QHash>
#include "ConfigManager.h"
class Editor; class EditorFrame; class QAction; class QLabel; class QCloseEvent;
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(ConfigManager *config, QWidget *parent=nullptr);
    bool openFile(const QString &path);
    bool openFiles(const QStringList &paths);
protected:
    void closeEvent(QCloseEvent *event) override;
private slots:
    void newFile(); void openDialog(); void save(); void saveAs(); void find(); void findNext(); void goToLine(); void reloadConfig();
    void updateTitle(); void updateStatus(); void toggleFullscreen(); void increaseFont(); void decreaseFont();
private:
    bool maybeSave(); bool saveTo(const QString &path); void createMenus(); void applyConfig(); void updateActionShortcuts();
    Editor *m_editor; EditorFrame *m_frame; ConfigManager *m_config; QString m_path,m_lastSearch; QLabel *m_status;
    QHash<QString,QAction*> m_actions; bool m_fullscreen=false;
};

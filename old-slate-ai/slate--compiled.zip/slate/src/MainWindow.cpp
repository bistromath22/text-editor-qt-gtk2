#include "MainWindow.h"
#include "Editor.h"
#include "TextNormalization.h"
#include <QAction>
#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QInputDialog>
#include <QLineEdit>
#include <QTextBlock>
#include <QLabel>
#include <QMenuBar>
#include <QMessageBox>
#include <QSaveFile>
#include <QStatusBar>
#include <QTextCursor>

MainWindow::MainWindow(ConfigManager *config,QWidget *parent):QMainWindow(parent),m_config(config){
    m_editor=new Editor(this);m_frame=new EditorFrame(m_editor,this);setCentralWidget(m_frame);resize(900,600);setMinimumSize(400,300);
    m_status=new QLabel(this);statusBar()->addPermanentWidget(m_status);createMenus();applyConfig();
    connect(m_editor,&QTextEdit::cursorPositionChanged,this,&MainWindow::updateStatus);
    connect(m_editor->document(),&QTextDocument::modificationChanged,this,&MainWindow::updateTitle);
    updateTitle();updateStatus();
}
void MainWindow::createMenus(){
    auto add=[this](QMenu *menu,const QString &id,const QString &label,const std::function<void()> &fn){auto *a=menu->addAction(label);m_actions[id]=a;connect(a,&QAction::triggered,this,fn);};
    auto *file=menuBar()->addMenu("&File");add(file,"new_file","&New",[this]{newFile();});add(file,"open","&Open…",[this]{openDialog();});add(file,"save","&Save",[this]{save();});add(file,"save_as","Save &As…",[this]{saveAs();});file->addSeparator();add(file,"quit","&Quit",[this]{close();});
    auto *edit=menuBar()->addMenu("&Edit");add(edit,"find","&Find…",[this]{find();});add(edit,"find_next","Find &Next",[this]{findNext();});add(edit,"goto_line","Go to &Line…",[this]{goToLine();});add(edit,"reload_config","Reload Config",[this]{reloadConfig();});edit->addSeparator();
    add(edit,"toggle_wordwrap","Toggle Word Wrap",[this]{auto c=m_editor->config();c.wordWrap=!c.wordWrap;m_editor->applyConfig(c);});
    add(edit,"toggle_block_cursor","Toggle Block Cursor",[this]{auto c=m_editor->config();c.blockCursor=!c.blockCursor;m_editor->applyConfig(c);});
    add(edit,"increase_font","Increase Font",[this]{increaseFont();});add(edit,"decrease_font","Decrease Font",[this]{decreaseFont();});
    auto *view=menuBar()->addMenu("&View");add(view,"fullscreen","Full Screen",[this]{toggleFullscreen();});
    add(view,"toggle_line_numbers","Show Line Numbers",[this]{auto c=m_editor->config();c.showLineNumbers=!c.showLineNumbers;m_editor->applyConfig(c);});
    add(view,"toggle_current_line","Highlight Current Line",[this]{auto c=m_editor->config();c.highlightCurrentLine=!c.highlightCurrentLine;m_editor->applyConfig(c);});
    add(view,"toggle_statusbar","Show Status Bar",[this]{statusBar()->setVisible(!statusBar()->isVisible());});updateActionShortcuts();
}
void MainWindow::updateActionShortcuts(){for(auto it=m_actions.begin();it!=m_actions.end();++it)it.value()->setShortcut(m_config->shortcuts().value(it.key()));}
void MainWindow::applyConfig(){const auto &c=m_config->config();m_editor->applyConfig(c);m_frame->setBorder(c.borderSize,c.borderColor);statusBar()->setVisible(c.showStatusBar);updateActionShortcuts();}
void MainWindow::updateTitle(){QString n=m_path.isEmpty()?"Untitled":QFileInfo(m_path).fileName();setWindowTitle("slate — "+n+(m_editor->document()->isModified()?" [modified]":""));}
void MainWindow::updateStatus(){QTextCursor c=m_editor->textCursor();int line=c.blockNumber()+1,col=c.position()-c.block().position()+1;m_status->setText(QString("Ln %1, Col %2").arg(line).arg(col));}
bool MainWindow::maybeSave(){if(!m_editor->document()->isModified())return true;auto r=QMessageBox::warning(this,"Unsaved changes","Save changes before continuing?",QMessageBox::Save|QMessageBox::Discard|QMessageBox::Cancel,QMessageBox::Save);if(r==QMessageBox::Save){save();return !m_editor->document()->isModified();}return r==QMessageBox::Discard;}
void MainWindow::newFile(){if(!maybeSave())return;m_editor->clear();m_editor->document()->setModified(false);m_path.clear();updateTitle();}
void MainWindow::openDialog(){QString p=QFileDialog::getOpenFileName(this,"Open text file");if(!p.isEmpty())openFile(p);}
bool MainWindow::openFile(const QString &path){if(!maybeSave())return false;QFile f(path);if(!f.open(QIODevice::ReadOnly)){QMessageBox::critical(this,"Open failed",f.errorString());return false;}m_editor->setPlainTextNormalized(TextNormalization::decodeUtf8(f.readAll()));m_path=QFileInfo(path).absoluteFilePath();m_editor->document()->setModified(false);updateTitle();updateStatus();return true;}
bool MainWindow::openFiles(const QStringList &paths){if(paths.isEmpty())return true;bool ok=openFile(paths.first());if(paths.size()>1)statusBar()->showMessage(QString("Only one document is supported; ignored %1 additional path(s).").arg(paths.size()-1),8000);return ok;}
bool MainWindow::saveTo(const QString &path){QSaveFile f(path);if(!f.open(QIODevice::WriteOnly)){QMessageBox::critical(this,"Save failed",f.errorString());return false;}const QByteArray bytes=TextNormalization::encodeUtf8(m_editor->plainText());if(f.write(bytes)!=bytes.size()||!f.commit()){QMessageBox::critical(this,"Save failed",f.errorString());return false;}m_path=QFileInfo(path).absoluteFilePath();m_editor->document()->setModified(false);updateTitle();return true;}
void MainWindow::save(){if(m_path.isEmpty())saveAs();else saveTo(m_path);}
void MainWindow::saveAs(){QString p=QFileDialog::getSaveFileName(this,"Save text file",m_path);if(!p.isEmpty())saveTo(p);}
void MainWindow::find(){bool ok=false;QString q=QInputDialog::getText(this,"Find","Text:",QLineEdit::Normal,m_lastSearch,&ok);if(ok&&!q.isEmpty()){m_lastSearch=q;findNext();}}
void MainWindow::findNext(){if(m_lastSearch.isEmpty())return;QTextCursor start=m_editor->textCursor();QTextCursor found=m_editor->document()->find(m_lastSearch,start);if(found.isNull()){found=m_editor->document()->find(m_lastSearch,QTextCursor(m_editor->document()));if(found.isNull())QMessageBox::information(this,"Find","Text not found.");else statusBar()->showMessage("Search wrapped to the beginning.",3000);}if(!found.isNull()){m_editor->setTextCursor(found);m_editor->ensureCursorVisible();}}
void MainWindow::goToLine(){bool ok=false;int n=QInputDialog::getInt(this,"Go to Line","Line:",m_editor->textCursor().blockNumber()+1,1,m_editor->document()->blockCount(),1,&ok);if(ok){QTextBlock b=m_editor->document()->findBlockByNumber(n-1);QTextCursor c(b);m_editor->setTextCursor(c);m_editor->ensureCursorVisible();}}
void MainWindow::reloadConfig(){QString err;if(!m_config->load(&err))QMessageBox::warning(this,"Config",err);applyConfig();if(!err.isEmpty())statusBar()->showMessage(err,6000);}
void MainWindow::toggleFullscreen(){m_fullscreen=!m_fullscreen;if(m_fullscreen)showFullScreen();else showNormal();}
void MainWindow::increaseFont(){m_editor->setFontPointSize(m_editor->config().fontSize+1);}
void MainWindow::decreaseFont(){m_editor->setFontPointSize(m_editor->config().fontSize-1);}
void MainWindow::closeEvent(QCloseEvent *event){if(maybeSave())event->accept();else event->ignore();}

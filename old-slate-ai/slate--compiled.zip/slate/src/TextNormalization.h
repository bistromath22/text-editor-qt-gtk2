#pragma once
#include <QString>

namespace TextNormalization {
// Slate's canonical in-memory and on-disk line ending is LF.
QString normalizeNewlines(const QString &text);
QString decodeUtf8(const QByteArray &bytes);
QByteArray encodeUtf8(const QString &text);
}

#pragma once
#include <QTextEdit>
#include <QWidget>
#include "ConfigManager.h"

class LineNumberArea;
class Editor : public QTextEdit {
    Q_OBJECT
public:
    explicit Editor(QWidget *parent=nullptr);
    void applyConfig(const EditorConfig &config);
    const EditorConfig &config() const { return m_config; }
    QString plainText() const;
    void setPlainTextNormalized(const QString &text);
    void setLineNumbersVisible(bool visible);
    bool lineNumbersVisible() const { return m_config.showLineNumbers; }
    void setBlockCursor(bool enabled);
    void setFontPointSize(int size);
    int lineNumberAreaWidth() const;
    void lineNumberAreaPaintEvent(QPaintEvent *event);
protected:
    void resizeEvent(QResizeEvent *event) override;
    void insertFromMimeData(const QMimeData *source) override;
    QMimeData *createMimeDataFromSelection() const override;
    void keyPressEvent(QKeyEvent *event) override;
private slots:
    void updateLineNumberAreaWidth();
    void updateLineNumberArea(const QRect &, int);
    void highlightCurrentLine();
private:
    void applyParagraphFormat(QTextBlock block);
    void applyAllParagraphFormats();
    QWidget *m_lineNumberArea=nullptr;
    EditorConfig m_config=EditorConfig::defaults();
};

// Owns the editor surround. Its contents margins are the border thickness;
// status-bar geometry is owned by QMainWindow and never enters this widget.
class EditorFrame : public QFrame {
    Q_OBJECT
public:
    explicit EditorFrame(Editor *editor, QWidget *parent=nullptr);
    void setBorder(int size, const QColor &color);
    int borderSize() const { return m_borderSize; }
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    int m_borderSize=8;
    QColor m_borderColor="#313244";
};

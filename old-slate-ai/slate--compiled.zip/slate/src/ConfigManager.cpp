#include "ConfigManager.h"
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSettings>
#include <QStandardPaths>
#include <QTextStream>
#include <cmath>

static bool readBool(QSettings &s, const char *key, bool fallback) {
    if (!s.contains(key)) return fallback;
    const QString v = s.value(key).toString().trimmed().toLower();
    if (v == "true" || v == "1" || v == "yes" || v == "on") return true;
    if (v == "false" || v == "0" || v == "no" || v == "off") return false;
    return fallback;
}
static int readInt(QSettings &s, const char *key, int fallback, int lo, int hi) {
    bool ok = false; const int n = s.value(key).toString().toInt(&ok);
    return ok && n >= lo && n <= hi ? n : fallback;
}
static QColor readColor(QSettings &s, const char *key, const QColor &fallback) {
    if (!s.contains(key)) return fallback;
    QColor c(s.value(key).toString()); return c.isValid() ? c : fallback;
}

ConfigManager::ConfigManager(QString overridePath) : m_overridePath(std::move(overridePath)), m_shortcuts(defaultShortcuts()) {
    m_searchPaths << QDir::current().filePath("config.ini")
                  << QDir(QStandardPaths::writableLocation(QStandardPaths::ConfigLocation)).filePath("slate/config.ini")
                  << QStringLiteral("/etc/slate/config.ini");
}
QHash<QString, QKeySequence> ConfigManager::defaultShortcuts() {
    return {{"new_file", QKeySequence("Ctrl+N")}, {"open", QKeySequence("Ctrl+O")},
      {"save", QKeySequence("Ctrl+S")}, {"save_as", QKeySequence("Ctrl+Shift+S")},
      {"quit", QKeySequence("Ctrl+Q")}, {"find", QKeySequence("Ctrl+F")},
      {"find_next", QKeySequence("F3")}, {"goto_line", QKeySequence("Ctrl+G")},
      {"reload_config", QKeySequence("Ctrl+R")}, {"toggle_wordwrap", QKeySequence("Ctrl+W")},
      {"toggle_block_cursor", QKeySequence("Ctrl+B")}, {"increase_font", QKeySequence("Ctrl++")},
      {"decrease_font", QKeySequence("Ctrl+-")}, {"fullscreen", QKeySequence("F11")},
      {"toggle_line_numbers", QKeySequence("Ctrl+L")}, {"toggle_current_line", QKeySequence("Ctrl+H")},
      {"toggle_statusbar", QKeySequence("Ctrl+Shift+B")}};
}
bool ConfigManager::load(QString *error) {
    m_config = EditorConfig::defaults(); m_shortcuts = defaultShortcuts();
    m_activePath.clear(); m_usingDefaults = true;
    if (!m_overridePath.isEmpty()) m_activePath = m_overridePath;
    else for (const QString &p : m_searchPaths) if (QFileInfo::exists(p)) { m_activePath = p; break; }
    if (m_activePath.isEmpty() || !QFileInfo::exists(m_activePath)) return true;
    QSettings s(m_activePath, QSettings::IniFormat); s.setFallbacksEnabled(false);
    s.beginGroup("editor");
    auto &c = m_config;
    c.wordWrap = readBool(s,"wordwrap",c.wordWrap); c.borderSize=readInt(s,"border_size",c.borderSize,0,64);
    c.borderColor=readColor(s,"border_color",c.borderColor); c.backgroundColor=readColor(s,"background_color",c.backgroundColor);
    c.currentLineColor=readColor(s,"current_line_color",c.currentLineColor); c.lineNumberColor=readColor(s,"line_number_color",c.lineNumberColor);
    c.textColor=readColor(s,"text_color",c.textColor); c.blockCursor=readBool(s,"block_cursor",c.blockCursor);
    c.fontFamily=s.value("font_family",c.fontFamily).toString(); c.fontSize=readInt(s,"font_size",c.fontSize,6,96);
    bool ok=false; double lh=s.value("line_height",c.lineHeight).toString().toDouble(&ok);
    if(ok && std::isfinite(lh) && lh>=0.5 && lh<=5.0) c.lineHeight=lh;
    c.pixelsAbove=readInt(s,"pixels_above",c.pixelsAbove,0,100); c.pixelsBelow=readInt(s,"pixels_below",c.pixelsBelow,0,100);
    c.lineDistance=readInt(s,"line_distance",c.lineDistance,0,100);
    c.showLineNumbers=readBool(s,"show_line_numbers",c.showLineNumbers); c.highlightCurrentLine=readBool(s,"highlight_current_line",c.highlightCurrentLine);
    c.showStatusBar=readBool(s,"show_statusbar",c.showStatusBar); s.endGroup();
    s.beginGroup("shortcuts");
    for (auto it=m_shortcuts.begin(); it!=m_shortcuts.end(); ++it) if(s.contains(it.key())) {
        QKeySequence candidate(s.value(it.key()).toString(), QKeySequence::PortableText);
        if (!candidate.isEmpty()) it.value()=candidate;
        else if(error) *error += QString("Invalid shortcut %1; default retained. ").arg(it.key());
    }
    s.endGroup();
    if(s.status()!=QSettings::NoError) { if(error) *error += "Configuration file could not be parsed cleanly. "; return false; }
    m_usingDefaults=false; return true;
}
QString ConfigManager::defaultIni() {
    const auto c=EditorConfig::defaults(); QString out="[editor]\n";
    out += QString("wordwrap=%1\nborder_size=%2\nborder_color=%3\nbackground_color=%4\ncurrent_line_color=%5\nline_number_color=%6\ntext_color=%7\nblock_cursor=%8\nfont_family=%9\nfont_size=%10\nline_height=%11\npixels_above=%12\npixels_below=%13\nline_distance=%14\nshow_line_numbers=%15\nhighlight_current_line=%16\nshow_statusbar=%17\n\n[shortcuts]\n")
      .arg(c.wordWrap).arg(c.borderSize).arg(c.borderColor.name()).arg(c.backgroundColor.name()).arg(c.currentLineColor.name())
      .arg(c.lineNumberColor.name()).arg(c.textColor.name()).arg(c.blockCursor).arg(c.fontFamily).arg(c.fontSize)
      .arg(c.lineHeight).arg(c.pixelsAbove).arg(c.pixelsBelow).arg(c.lineDistance).arg(c.showLineNumbers).arg(c.highlightCurrentLine).arg(c.showStatusBar);
    const auto keys=defaultShortcuts(); for(auto it=keys.cbegin();it!=keys.cend();++it) out += it.key()+"="+it.value().toString(QKeySequence::PortableText)+"\n";
    return out;
}

#include <QtTest>
#include <QMimeData>
#include <QClipboard>
#include <QApplication>
#include <QTemporaryDir>
#include <QFile>
#include "TextNormalization.h"
#include "Editor.h"
#include "ConfigManager.h"

class SlateTests : public QObject {
    Q_OBJECT
private slots:
    void newlineNormalization();
    void emptyAndTrailingLines();
    void pasteIsPlainTextAndUndoable();
    void enterCreatesParagraph();
    void canonicalDefaults();
};
void SlateTests::newlineNormalization(){
    QCOMPARE(TextNormalization::normalizeNewlines("a\nb"),QString("a\nb"));
    QCOMPARE(TextNormalization::normalizeNewlines("a\r\nb"),QString("a\nb"));
    QCOMPARE(TextNormalization::normalizeNewlines("a\rb"),QString("a\nb"));
    QCOMPARE(TextNormalization::normalizeNewlines("a\r\n\rb\n"),QString("a\n\nb\n"));
}
void SlateTests::emptyAndTrailingLines(){
    QCOMPARE(TextNormalization::normalizeNewlines(""),QString(""));
    QCOMPARE(TextNormalization::normalizeNewlines("\n"),QString("\n"));
    QCOMPARE(TextNormalization::normalizeNewlines("\n\n"),QString("\n\n"));
}
void SlateTests::pasteIsPlainTextAndUndoable(){
    Editor e;e.setPlainTextNormalized("before after");QTextCursor c=e.textCursor();c.setPosition(7);e.setTextCursor(c);
    auto *mime=new QMimeData;mime->setHtml("<b>X</b><br>Y");mime->setText("X\r\n\rY");QApplication::clipboard()->setMimeData(mime);e.setFocus();QTest::keyClick(&e,Qt::Key_V,Qt::ControlModifier);
    QCOMPARE(e.plainText(),QString("beforeX\n\nY after"));
    e.undo();QCOMPARE(e.plainText(),QString("before after"));e.redo();QCOMPARE(e.plainText(),QString("beforeX\n\nY after"));
}
void SlateTests::enterCreatesParagraph(){
    Editor e;e.setPlainTextNormalized("ab");QTextCursor c=e.textCursor();c.setPosition(1);e.setTextCursor(c);
    QTest::keyClick(&e,Qt::Key_Return);QCOMPARE(e.document()->blockCount(),2);QCOMPARE(e.plainText(),QString("a\nb"));e.undo();QCOMPARE(e.plainText(),QString("ab"));
}
void SlateTests::canonicalDefaults(){
    const auto c=EditorConfig::defaults();QCOMPARE(c.borderSize,8);QCOMPARE(c.fontSize,12);QVERIFY(qAbs(c.lineHeight-1.4)<0.0001);QVERIFY(c.showLineNumbers);QVERIFY(c.showStatusBar);
    QVERIFY(ConfigManager::defaultIni().contains("border_color=#313244"));
}
QTEST_MAIN(SlateTests)
#include "tst_slate.moc"

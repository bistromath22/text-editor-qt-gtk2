# Slate implementation notes

## Core decisions

`QTextDocument` is authoritative. Input normalization converts CRLF first and then bare CR to LF. The file boundary strips a UTF-8 BOM and saves UTF-8/LF. `toPlainText()` is the serialization source; HTML is never written. Clipboard text is normalized and inserted with a `QTextCursor` edit block; unsupported non-text MIME payloads are ignored.

The editor uses proportional block line height rather than a font-metric-derived fixed pixel height. Paragraph top/bottom margins are separate, and the retained `line_distance` setting is added to bottom paragraph spacing. The line-number gutter counts document blocks and uses document block geometry, so wrapped visual rows do not change logical numbering.

`EditorFrame` is the border owner. It paints only itself and applies equal outer layout insets for the configured surround thickness. The line-number gutter belongs to `Editor`; status bar belongs to `MainWindow`. Native window-manager decorations are explicitly outside `border_color` control.

## Corrections relative to the supplied reference description

- Adds an explicit plain-text MIME insertion path and normalizes CRLF/CR/LF.
- Uses proportional line-height semantics rather than fixed pixel block heights.
- Defines one canonical `EditorConfig::defaults()` and derives `--print-config` from it.
- Unifies line-height validation at 0.5–5.0 and validates bounded integer settings.
- Opens only the first command-line path and reports that additional paths are unsupported.
- Uses the installed `slate` executable in the desktop entry.
- Updates existing QAction shortcuts when configuration is applied/reloaded.
- Separates the frame surround, line-number gutter, and status-bar ownership.
- Adds Qt Test coverage for newline conversion, paragraph insertion, clipboard insertion/undo, and defaults.

## Verification limitations

The implementation environment used to prepare this source did not contain Qt 6 development packages. CMake configuration, compilation, Qt Test execution, and interactive rendering checks therefore remain unverified. Run the build and manual checklist in `README.md` on a Qt 6 development system before treating the application as release-ready.


## Follow-up verification

Configuration-time paragraph reformatting uses QTextCursor block-format operations. Qt stores block-format edits in the document undo history; this first-pass implementation does not yet provide a non-undoable formatting transaction that preserves a pre-existing undo stack across live typography reloads. Verify this interaction and refine it before production release. The block-cursor option currently renders a highlighted character cell through extra selections; the native insertion caret remains Qt's beam caret.

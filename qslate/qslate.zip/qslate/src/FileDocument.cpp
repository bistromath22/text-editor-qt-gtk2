#include "FileDocument.h"

#include "TextNormalization.h"

#include <QFile>
#include <QFileInfo>
#include <QSaveFile>
#include <QStringConverter>

namespace FileDocument {

LoadResult decode(const QByteArray &input)
{
    LoadResult result;
    QByteArray bytes = input;
    static const char bom[] = "\xEF\xBB\xBF";
    if (bytes.startsWith(QByteArray(bom, 3))) {
        bytes.remove(0, 3);
        result.hadBom = true;
    }

    QStringDecoder decoder(QStringConverter::Utf8);
    const QString text = decoder.decode(bytes);
    if (decoder.hasError()) {
        result.error = QStringLiteral("The file is not valid UTF-8 text.");
        return result;
    }
    result.text = TextNormalization::normalizeNewlines(text);
    result.ok = true;
    return result;
}

LoadResult load(const QString &path)
{
    LoadResult result;
    const QFileInfo info(path);
    if (!info.exists()) {
        result.error = QStringLiteral("File does not exist: %1").arg(path);
        return result;
    }
    if (info.isDir()) {
        result.error = QStringLiteral("Not a file: %1").arg(path);
        return result;
    }
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        result.error = QStringLiteral("Cannot read %1: %2").arg(path, file.errorString());
        return result;
    }
    const QByteArray bytes = file.readAll();
    if (file.error() != QFileDevice::NoError) {
        result.error = QStringLiteral("Error reading %1: %2").arg(path, file.errorString());
        return result;
    }
    result = decode(bytes);
    if (!result.ok) {
        result.error = QStringLiteral("%1: %2").arg(path, result.error);
    }
    return result;
}

QByteArray encode(const QString &text)
{
    return TextNormalization::normalizeNewlines(text).toUtf8();
}

SaveResult save(const QString &path, const QString &text)
{
    SaveResult result;
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        result.error = QStringLiteral("Cannot write %1: %2").arg(path, file.errorString());
        return result;
    }
    const QByteArray bytes = encode(text);
    if (file.write(bytes) != bytes.size()) {
        file.cancelWriting();
        result.error = QStringLiteral("Error writing %1: %2").arg(path, file.errorString());
        return result;
    }
    if (!file.commit()) {
        result.error = QStringLiteral("Cannot commit %1: %2").arg(path, file.errorString());
        return result;
    }
    result.ok = true;
    return result;
}

} // namespace FileDocument

// QSlate - GTK-style accelerator parsing and QAction shortcut application.
#pragma once

#include "ConfigManager.h"

#include <QHash>
#include <QKeySequence>
#include <QStringList>

class QAction;

struct ResolvedShortcuts {
    QHash<QString, QKeySequence> sequences; // action id -> active sequence
    QStringList warnings;                   // invalid / conflicting bindings
};

class KeyBindings
{
public:
    // Parses "<Primary><Shift>s", "<Primary>plus", "F11", ... into a Qt key
    // sequence. <Primary> is Ctrl. The GTK text is never handed to
    // QKeySequence::fromString (different syntax).
    static bool parseAccelerator(const QString &text, QKeySequence *out, QString *error);

    // Parse every entry. Invalid entries are dropped with a warning. When two
    // actions share a sequence, the one listed FIRST in the config order wins;
    // the later binding is disabled and reported. Deterministic.
    static ResolvedShortcuts resolve(const ShortcutConfig &config);

    // Apply to existing actions (never recreated). Actions with no binding get
    // their shortcut cleared.
    static void apply(const QHash<QString, QAction *> &actions, const ResolvedShortcuts &resolved);
};

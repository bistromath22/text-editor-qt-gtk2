// QSlate - newline normalization helpers (pure, Qt Core only).
#pragma once

#include <QString>

namespace TextNormalization {

// Canonical internal representation is LF. Order matters: CRLF is replaced
// first so that one CRLF never becomes two LF characters, then any remaining
// lone CR becomes LF. All pre-existing LF characters are preserved.
QString normalizeNewlines(const QString &text);

} // namespace TextNormalization

#include "LineNumberArea.h"

#include "Editor.h"

#include <QPaintEvent>
#include <QPainter>
#include <QScrollBar>
#include <QTextBlock>
#include <QTextDocument>
#include <QTextLayout>

LineNumberArea::LineNumberArea(Editor *editor)
    : QWidget(editor)
    , m_editor(editor)
{
    setAttribute(Qt::WA_OpaquePaintEvent);
}

void LineNumberArea::setColors(const QColor &background, const QColor &foreground)
{
    m_background = background;
    m_foreground = foreground;
    update();
}

// Position of block N's FIRST text line in gutter coordinates (== viewport
// coordinates: the gutter and the viewport share the same top edge). Taken from
// the document layout so a wrapped paragraph still gets exactly one number.
QList<int> LineNumberArea::visibleLineNumbers() const
{
    QList<int> numbers;
    const int offset = m_editor->verticalScrollBar()->value();
    QTextBlock block = m_editor->cursorForPosition(QPoint(0, 0)).block();
    for (; block.isValid(); block = block.next()) {
        const QTextLayout *tl = block.layout();
        if (!tl || tl->lineCount() == 0) {
            break;
        }
        const QTextLine line = tl->lineAt(0);
        const qreal top = tl->position().y() + line.y() - offset;
        if (top > height()) {
            break;
        }
        if (top + line.height() >= 0 && block.isVisible()) {
            numbers.append(block.blockNumber() + 1);
        }
    }
    return numbers;
}

void LineNumberArea::paintEvent(QPaintEvent *event)
{
    QPainter painter(this); // we are inside our OWN paint event
    painter.fillRect(event->rect(), m_background);
    painter.setPen(m_foreground);
    painter.setFont(m_editor->font());
    const QFontMetricsF fm(m_editor->font());

    const int offset = m_editor->verticalScrollBar()->value();
    const qreal rightEdge = width() - kPaddingRight;
    QTextBlock block = m_editor->cursorForPosition(QPoint(0, 0)).block();
    for (; block.isValid(); block = block.next()) {
        const QTextLayout *tl = block.layout();
        if (!tl || tl->lineCount() == 0) {
            break;
        }
        const QTextLine line = tl->lineAt(0);
        const qreal top = tl->position().y() + line.y() - offset;
        if (top > event->rect().bottom()) {
            break;
        }
        if (!block.isVisible() || top + line.height() < event->rect().top()) {
            continue;
        }
        const QString number = QString::number(block.blockNumber() + 1);
        const qreal baseline = top + line.ascent(); // same baseline as the text
        painter.drawText(QPointF(rightEdge - fm.horizontalAdvance(number), baseline), number);
    }
}

#include "KeyBindings.h"

#include <QAction>
#include <QRegularExpression>

namespace {

int keyFromName(const QString &raw)
{
    if (raw.isEmpty()) {
        return -1;
    }
    const QString n = raw.toLower();
    if (n.size() == 1) {
        const ushort c = n.at(0).unicode();
        if (c >= 'a' && c <= 'z') {
            return int(Qt::Key_A) + (c - 'a');
        }
        if (c >= '0' && c <= '9') {
            return int(Qt::Key_0) + (c - '0');
        }
    }
    static const QHash<QString, int> names = {
        {QStringLiteral("plus"), int(Qt::Key_Plus)},
        {QStringLiteral("minus"), int(Qt::Key_Minus)},
        {QStringLiteral("equal"), int(Qt::Key_Equal)},
        {QStringLiteral("space"), int(Qt::Key_Space)},
        {QStringLiteral("return"), int(Qt::Key_Return)},
        {QStringLiteral("enter"), int(Qt::Key_Enter)},
        {QStringLiteral("escape"), int(Qt::Key_Escape)},
        {QStringLiteral("tab"), int(Qt::Key_Tab)},
        {QStringLiteral("backspace"), int(Qt::Key_Backspace)},
        {QStringLiteral("delete"), int(Qt::Key_Delete)},
        {QStringLiteral("insert"), int(Qt::Key_Insert)},
        {QStringLiteral("home"), int(Qt::Key_Home)},
        {QStringLiteral("end"), int(Qt::Key_End)},
        {QStringLiteral("pageup"), int(Qt::Key_PageUp)},
        {QStringLiteral("pagedown"), int(Qt::Key_PageDown)},
        {QStringLiteral("up"), int(Qt::Key_Up)},
        {QStringLiteral("down"), int(Qt::Key_Down)},
        {QStringLiteral("left"), int(Qt::Key_Left)},
        {QStringLiteral("right"), int(Qt::Key_Right)},
        {QStringLiteral("comma"), int(Qt::Key_Comma)},
        {QStringLiteral("period"), int(Qt::Key_Period)},
        {QStringLiteral("slash"), int(Qt::Key_Slash)},
        {QStringLiteral("backslash"), int(Qt::Key_Backslash)},
        {QStringLiteral("semicolon"), int(Qt::Key_Semicolon)},
        {QStringLiteral("apostrophe"), int(Qt::Key_Apostrophe)},
        {QStringLiteral("bracketleft"), int(Qt::Key_BracketLeft)},
        {QStringLiteral("bracketright"), int(Qt::Key_BracketRight)},
        {QStringLiteral("grave"), int(Qt::Key_QuoteLeft)},
    };
    const auto it = names.constFind(n);
    if (it != names.constEnd()) {
        return it.value();
    }
    static const QRegularExpression fkey(QStringLiteral("^f([1-9]|[12][0-9]|3[0-5])$"));
    const QRegularExpressionMatch m = fkey.match(n);
    if (m.hasMatch()) {
        return int(Qt::Key_F1) + m.captured(1).toInt() - 1;
    }
    return -1;
}

} // namespace

bool KeyBindings::parseAccelerator(const QString &text, QKeySequence *out, QString *error)
{
    auto fail = [error](const QString &message) {
        if (error) {
            *error = message;
        }
        return false;
    };

    QString rest = text.trimmed();
    if (rest.isEmpty()) {
        return fail(QStringLiteral("empty accelerator"));
    }

    Qt::KeyboardModifiers mods;
    while (rest.startsWith(QLatin1Char('<'))) {
        const int end = rest.indexOf(QLatin1Char('>'));
        if (end < 0) {
            return fail(QStringLiteral("unterminated modifier tag in '%1'").arg(text));
        }
        const QString tag = rest.mid(1, end - 1).toLower();
        if (tag == QLatin1String("primary") || tag == QLatin1String("control")
            || tag == QLatin1String("ctrl")) {
            mods |= Qt::ControlModifier;
        } else if (tag == QLatin1String("shift")) {
            mods |= Qt::ShiftModifier;
        } else if (tag == QLatin1String("alt") || tag == QLatin1String("mod1")) {
            mods |= Qt::AltModifier;
        } else if (tag == QLatin1String("meta") || tag == QLatin1String("super")) {
            mods |= Qt::MetaModifier;
        } else {
            return fail(QStringLiteral("unknown modifier <%1>").arg(tag));
        }
        rest = rest.mid(end + 1);
    }

    const int key = keyFromName(rest.trimmed());
    if (key < 0) {
        return fail(QStringLiteral("unknown key name '%1'").arg(rest.trimmed()));
    }
    if (out) {
        *out = QKeySequence(QKeyCombination(mods, Qt::Key(key)));
    }
    return true;
}

ResolvedShortcuts KeyBindings::resolve(const ShortcutConfig &config)
{
    ResolvedShortcuts result;
    QHash<QString, QString> owner; // portable sequence text -> action id
    for (const auto &entry : config.entries) {
        const QString &id = entry.first;
        if (entry.second.trimmed().isEmpty()) {
            continue; // intentionally unbound
        }
        QKeySequence seq;
        QString err;
        if (!parseAccelerator(entry.second, &seq, &err)) {
            result.warnings << QStringLiteral("shortcut '%1' = '%2' ignored: %3")
                                   .arg(id, entry.second, err);
            continue;
        }
        const QString portable = seq.toString(QKeySequence::PortableText);
        const auto it = owner.constFind(portable);
        if (it != owner.constEnd()) {
            result.warnings << QStringLiteral("shortcut conflict: '%1' for '%2' is already used by "
                                              "'%3'; '%2' is left unbound")
                                   .arg(entry.second, id, it.value());
            continue;
        }
        owner.insert(portable, id);
        result.sequences.insert(id, seq);
    }
    return result;
}

void KeyBindings::apply(const QHash<QString, QAction *> &actions, const ResolvedShortcuts &resolved)
{
    for (auto it = actions.cbegin(); it != actions.cend(); ++it) {
        it.value()->setShortcut(resolved.sequences.value(it.key()));
    }
}

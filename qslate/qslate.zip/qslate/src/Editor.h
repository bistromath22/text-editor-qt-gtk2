// QSlate - the plain-text editing widget (QTextEdit over one QTextDocument).
#pragma once

#include "ConfigManager.h"

#include <QKeySequence>
#include <QList>
#include <QTextBlockFormat>
#include <QTextEdit>
#include <QTimer>

class LineNumberArea;

class Editor : public QTextEdit
{
    Q_OBJECT
public:
    enum class FindResult { Found, FoundWrapped, NotFound };

    explicit Editor(QWidget *parent = nullptr);

    // Apply a full configuration. Numeric fields are re-validated with the
    // shared Validation functions; invalid values keep the previous value.
    void applyConfig(const EditorConfig &config);
    const EditorConfig &config() const { return m_config; }

    // The family actually used for display (config keeps the requested one).
    QString effectiveFontFamily() const { return m_effectiveFamily; }

    // Validated setters (return false and change nothing when invalid).
    bool setFontSize(double points);
    bool setLineHeight(double multiplier);
    bool setPixelsAbove(int px);
    bool setPixelsBelow(int px);
    bool setLineDistance(int px);
    void setWordWrap(bool on);
    void setBlockCursor(bool on);
    void setBlockCursorBlink(bool on);
    void setShowLineNumbers(bool on);
    void setHighlightCurrentLine(bool on);

    // Plain text = block texts joined by LF (bijective with the file content).
    QString exportPlainText() const;
    // Replace the document; establishes a clean, empty-undo baseline.
    void loadPlainText(const QString &text);

    int currentLine() const;   // 1-based logical line
    int currentColumn() const; // 1-based
    bool goToLine(int line);   // 1-based; false when out of range
    FindResult findText(const QString &needle); // case-insensitive, wraps

    // Key sequences owned by QActions: the editor must not swallow them.
    void setReservedShortcuts(const QList<QKeySequence> &sequences);

    int lineNumberAreaWidth() const; // 0 when hidden
    LineNumberArea *lineNumberArea() const { return m_gutter; }
    QTextBlockFormat policyBlockFormat() const;
    bool blockCursorBlinks() const { return m_config.blockCursor && m_config.blockCursorBlink; }

signals:
    void configApplied();

protected:
    bool event(QEvent *e) override;
    void keyPressEvent(QKeyEvent *e) override;
    void paintEvent(QPaintEvent *e) override;
    void resizeEvent(QResizeEvent *e) override;
    void focusInEvent(QFocusEvent *e) override;
    void focusOutEvent(QFocusEvent *e) override;
    bool canInsertFromMimeData(const QMimeData *source) const override;
    void insertFromMimeData(const QMimeData *source) override;
    QMimeData *createMimeDataFromSelection() const override;

private:
    void applyCurrentConfig(bool policyChanged);
    void insertParagraphBreak();
    void insertPlainTextTransaction(const QString &normalized);
    void formatRange(int firstBlock, int lastBlock);
    void reformatAllBlocks();
    void updateGutterLayout();
    void updateCurrentLineHighlight();
    void updateBlinkState();
    void paintBlockCursor();
    int blockCellWidth() const;
    QString selectedPlainText() const;

    EditorConfig m_config;
    QString m_effectiveFamily;
    QString m_lastFallbackWarning;
    LineNumberArea *m_gutter = nullptr;
    QList<QKeySequence> m_reserved;
    QTimer m_blinkTimer;
    bool m_blockPhaseOn = true;
};

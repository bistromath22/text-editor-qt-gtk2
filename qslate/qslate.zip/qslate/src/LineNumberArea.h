// QSlate - logical line-number gutter (child of the Editor, paints itself).
#pragma once

#include <QColor>
#include <QList>
#include <QWidget>

class Editor;

class LineNumberArea : public QWidget
{
    Q_OBJECT
public:
    static constexpr int kPaddingLeft = 12;
    static constexpr int kPaddingRight = 12;

    explicit LineNumberArea(Editor *editor);

    void setColors(const QColor &background, const QColor &foreground);
    QColor backgroundColor() const { return m_background; }

    // Logical line numbers (1-based document block numbers) whose first text
    // line intersects the gutter's visible rectangle, in order.
    QList<int> visibleLineNumbers() const;

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    Editor *m_editor;
    QColor m_background;
    QColor m_foreground;
};

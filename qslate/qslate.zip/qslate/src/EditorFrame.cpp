#include "EditorFrame.h"

#include "Editor.h"

#include <QPaintEvent>
#include <QPainter>
#include <QVBoxLayout>

EditorFrame::EditorFrame(Editor *editor, QWidget *parent)
    : QWidget(parent)
    , m_editor(editor)
{
    auto *layout = new QVBoxLayout(this);
    layout->setSpacing(0);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->addWidget(editor);
}

void EditorFrame::setBorder(int size, const QColor &color)
{
    if (size < 0) {
        size = 0;
    }
    if (color.isValid()) {
        m_color = color;
    }
    m_size = size;
    layout()->setContentsMargins(size, size, size, size);
    update(); // repaint immediately with the new color
}

void EditorFrame::paintEvent(QPaintEvent *event)
{
    // The frame paints only itself, only in its own paint event. The editor
    // (a child widget) covers the interior; what remains visible is the surround.
    QPainter painter(this);
    painter.fillRect(event->rect(), m_color);
}

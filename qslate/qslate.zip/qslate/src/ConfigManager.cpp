#include "ConfigManager.h"

#include "KeyBindings.h"
#include "TextNormalization.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QKeySequence>
#include <QStandardPaths>

#include <cmath>

// ---------------------------------------------------------------- validation

namespace Validation {
bool fontSize(double v) { return std::isfinite(v) && v >= kFontSizeMin && v <= kFontSizeMax; }
bool borderSize(int v) { return v >= kBorderSizeMin && v <= kBorderSizeMax; }
bool paragraphSpacing(int v) { return v >= kParagraphSpacingMin && v <= kParagraphSpacingMax; }
bool lineDistance(int v) { return v >= kLineDistanceMin && v <= kLineDistanceMax; }
bool lineHeight(double v) { return std::isfinite(v) && v >= kLineHeightMin && v <= kLineHeightMax; }
} // namespace Validation

namespace ColorUtil {
QColor blend(const QColor &a, const QColor &b, double t)
{
    auto mix = [t](int x, int y) { return int(std::lround(x + (y - x) * t)); };
    return QColor(mix(a.red(), b.red()), mix(a.green(), b.green()), mix(a.blue(), b.blue()));
}
} // namespace ColorUtil

// ------------------------------------------------------ canonical defaults
// This is the ONE place the default values live. They are the exact contents
// of the user's preferred config.ini and are parsed through the same code
// path as any user file.

namespace {

struct DefaultEntry {
    const char *key;
    const char *value;
};

const DefaultEntry kEditorDefaults[] = {
    {"wordwrap", "true"},
    {"border_size", "20"},
    {"border_color", "#313244"},
    {"background_color", "#1e1e2e"},
    {"gutter_background_color", "#313244"},
    {"current_line_color", "#313244"},
    {"line_number_color", "#6c7086"},
    {"text_color", "#cdd6f4"},
    {"block_cursor", "true"},
    {"block_cursor_blink", "false"},
    {"font_family", "Monaco"},
    {"font_size", "18"},
    {"line_height", "1.4"},
    {"pixels_above", "0"},
    {"pixels_below", "0"},
    {"line_distance", "0"},
    {"show_line_numbers", "false"},
    {"highlight_current_line", "true"},
    {"show_statusbar", "false"},
};

const DefaultEntry kShortcutDefaults[] = {
    {"new_file", "<Primary>n"},
    {"open", "<Primary>o"},
    {"save", "<Primary>s"},
    {"save_as", "<Primary><Shift>s"},
    {"quit", "<Primary>q"},
    {"undo", "<Primary>z"},
    {"redo", "<Primary>y"},
    {"cut", "<Primary>x"},
    {"copy", "<Primary>c"},
    {"paste", "<Primary>v"},
    {"find", "<Primary>f"},
    {"find_next", "F3"},
    {"goto_line", "<Primary>g"},
    {"reload_config", "<Primary>r"},
    {"toggle_wordwrap", "<Primary>w"},
    {"increase_font", "<Primary>plus"},
    {"decrease_font", "<Primary>minus"},
    {"fullscreen", "F11"},
    {"toggle_line_numbers", "<Primary>l"},
    {"toggle_current_line", "<Primary>h"},
    {"toggle_statusbar", "<Primary><Shift>b"},
};

// Accepted in [shortcuts] but has no default binding.
const char *const kOptionalShortcutIds[] = {"toggle_block_cursor"};

// ------------------------------------------------------------ value parsing

bool parseBool(const QString &raw, bool &out, QString *err)
{
    const QString v = raw.trimmed().toLower();
    if (v == QLatin1String("true") || v == QLatin1String("1") || v == QLatin1String("yes")
        || v == QLatin1String("on")) {
        out = true;
        return true;
    }
    if (v == QLatin1String("false") || v == QLatin1String("0") || v == QLatin1String("no")
        || v == QLatin1String("off")) {
        out = false;
        return true;
    }
    if (err) {
        *err = QStringLiteral("expected true or false");
    }
    return false;
}

QString boolText(bool b) { return b ? QStringLiteral("true") : QStringLiteral("false"); }

bool parseColor(const QString &raw, QColor &out, QString *err)
{
    const QColor c(raw.trimmed());
    if (!c.isValid()) {
        if (err) {
            *err = QStringLiteral("not a valid color");
        }
        return false;
    }
    out = c;
    return true;
}

bool parseInt(const QString &raw, int &out, bool (*valid)(int), const char *range, QString *err)
{
    bool ok = false;
    const int v = raw.trimmed().toInt(&ok);
    if (!ok) {
        if (err) {
            *err = QStringLiteral("expected an integer");
        }
        return false;
    }
    if (!valid(v)) {
        if (err) {
            *err = QStringLiteral("out of range (%1)").arg(QLatin1String(range));
        }
        return false;
    }
    out = v;
    return true;
}

bool parseDouble(const QString &raw, double &out, bool (*valid)(double), const char *range,
                 QString *err)
{
    bool ok = false;
    const double v = raw.trimmed().toDouble(&ok);
    if (!ok || !std::isfinite(v)) {
        if (err) {
            *err = QStringLiteral("expected a finite number");
        }
        return false;
    }
    if (!valid(v)) {
        if (err) {
            *err = QStringLiteral("out of range (%1)").arg(QLatin1String(range));
        }
        return false;
    }
    out = v;
    return true;
}

QString numberText(double v)
{
    if (v == std::floor(v) && std::fabs(v) < 1e9) {
        return QString::number(static_cast<long long>(v));
    }
    return QString::number(v, 'g', 6);
}

struct EditorKey {
    const char *key;
    bool (*parse)(EditorConfig &, const QString &, QString *);
    QString (*format)(const EditorConfig &);
};

#define BOOL_KEY(K, M)                                                                      \
    {                                                                                       \
        K, [](EditorConfig &c, const QString &v, QString *e) { return parseBool(v, c.M, e); }, \
            [](const EditorConfig &c) { return boolText(c.M); }                             \
    }
#define COLOR_KEY(K, M)                                                                       \
    {                                                                                         \
        K, [](EditorConfig &c, const QString &v, QString *e) { return parseColor(v, c.M, e); }, \
            [](const EditorConfig &c) { return c.M.name(); }                                  \
    }
#define INT_KEY(K, M, V, R)                                                             \
    {                                                                                   \
        K,                                                                              \
            [](EditorConfig &c, const QString &v, QString *e) {                         \
                return parseInt(v, c.M, V, R, e);                                       \
            },                                                                          \
            [](const EditorConfig &c) { return QString::number(c.M); }                  \
    }
#define DOUBLE_KEY(K, M, V, R)                                                          \
    {                                                                                   \
        K,                                                                              \
            [](EditorConfig &c, const QString &v, QString *e) {                         \
                return parseDouble(v, c.M, V, R, e);                                    \
            },                                                                          \
            [](const EditorConfig &c) { return numberText(c.M); }                       \
    }

const EditorKey kEditorKeys[] = {
    BOOL_KEY("wordwrap", wordWrap),
    INT_KEY("border_size", borderSize, Validation::borderSize, "0..100"),
    COLOR_KEY("border_color", borderColor),
    COLOR_KEY("background_color", backgroundColor),
    COLOR_KEY("gutter_background_color", gutterBackgroundColor),
    COLOR_KEY("current_line_color", currentLineColor),
    COLOR_KEY("line_number_color", lineNumberColor),
    COLOR_KEY("text_color", textColor),
    BOOL_KEY("block_cursor", blockCursor),
    BOOL_KEY("block_cursor_blink", blockCursorBlink),
    {"font_family",
     [](EditorConfig &c, const QString &v, QString *e) {
         const QString t = v.trimmed();
         if (t.isEmpty()) {
             if (e) {
                 *e = QStringLiteral("font family must not be empty");
             }
             return false;
         }
         c.fontFamily = t;
         return true;
     },
     [](const EditorConfig &c) { return c.fontFamily; }},
    DOUBLE_KEY("font_size", fontSize, Validation::fontSize, "6..96"),
    DOUBLE_KEY("line_height", lineHeight, Validation::lineHeight, "0.5..5.0"),
    INT_KEY("pixels_above", pixelsAbove, Validation::paragraphSpacing, "0..200"),
    INT_KEY("pixels_below", pixelsBelow, Validation::paragraphSpacing, "0..200"),
    INT_KEY("line_distance", lineDistance, Validation::lineDistance, "0..100"),
    BOOL_KEY("show_line_numbers", showLineNumbers),
    BOOL_KEY("highlight_current_line", highlightCurrentLine),
    BOOL_KEY("show_statusbar", showStatusbar),
};

const EditorKey *findEditorKey(const QString &key)
{
    for (const EditorKey &k : kEditorKeys) {
        if (key == QLatin1String(k.key)) {
            return &k;
        }
    }
    return nullptr;
}

QFileInfo infoFor(const QString &path) { return QFileInfo(path); }

ConfigCandidate makeCandidate(const QString &path, const QString &label)
{
    ConfigCandidate c;
    c.path = path;
    c.label = label;
    const QFileInfo fi = infoFor(path);
    c.exists = fi.exists();
    c.readable = fi.isFile() && fi.isReadable();
    return c;
}

} // namespace

// ----------------------------------------------------------- ShortcutConfig

bool ShortcutConfig::contains(const QString &id) const
{
    for (const auto &e : entries) {
        if (e.first == id) {
            return true;
        }
    }
    return false;
}

QString ShortcutConfig::value(const QString &id) const
{
    for (const auto &e : entries) {
        if (e.first == id) {
            return e.second;
        }
    }
    return QString();
}

void ShortcutConfig::set(const QString &id, const QString &accelerator)
{
    for (auto &e : entries) {
        if (e.first == id) {
            e.second = accelerator;
            return;
        }
    }
    entries.append(qMakePair(id, accelerator));
}

// ------------------------------------------------------------ ConfigManager

AppConfig ConfigManager::defaults()
{
    AppConfig cfg;
    for (const DefaultEntry &d : kEditorDefaults) {
        const EditorKey *k = findEditorKey(QString::fromLatin1(d.key));
        QString err;
        const bool ok = k && k->parse(cfg.editor, QString::fromLatin1(d.value), &err);
        Q_ASSERT_X(ok, "ConfigManager::defaults", d.key);
        Q_UNUSED(ok)
    }
    for (const DefaultEntry &d : kShortcutDefaults) {
        cfg.shortcuts.set(QString::fromLatin1(d.key), QString::fromLatin1(d.value));
    }
    return cfg;
}

QString ConfigManager::serialize(const AppConfig &config)
{
    QString out;
    out += QStringLiteral("[editor]\n");
    for (const EditorKey &k : kEditorKeys) {
        out += QStringLiteral("%1=%2\n").arg(QLatin1String(k.key), k.format(config.editor));
    }
    out += QStringLiteral("\n[shortcuts]\n");
    for (const auto &e : config.shortcuts.entries) {
        out += QStringLiteral("%1=%2\n").arg(e.first, e.second);
    }
    return out;
}

QStringList ConfigManager::shortcutIds()
{
    QStringList ids;
    for (const DefaultEntry &d : kShortcutDefaults) {
        ids << QString::fromLatin1(d.key);
    }
    for (const char *id : kOptionalShortcutIds) {
        ids << QString::fromLatin1(id);
    }
    return ids;
}

ConfigSelection ConfigManager::discover(const QString &explicitPath, const QStringList &searchOverride)
{
    ConfigSelection sel;
    if (!explicitPath.isEmpty()) {
        sel.explicitRequested = true;
        ConfigCandidate c = makeCandidate(QDir::current().absoluteFilePath(explicitPath),
                                          QStringLiteral("--config"));
        if (c.exists && c.readable) {
            c.selected = true;
            sel.selectedPath = c.path;
        } else {
            sel.ok = false;
            sel.error = c.exists
                ? QStringLiteral("Configuration file is not readable: %1").arg(c.path)
                : QStringLiteral("Configuration file does not exist: %1").arg(c.path);
        }
        sel.candidates.append(c);
        return sel;
    }

    QVector<QPair<QString, QString>> paths;
    if (!searchOverride.isEmpty()) {
        for (const QString &p : searchOverride) {
            paths.append(qMakePair(p, QStringLiteral("search path")));
        }
    } else {
        paths.append(qMakePair(QDir::current().absoluteFilePath(QStringLiteral("config.ini")),
                               QStringLiteral("current directory")));
        paths.append(qMakePair(QStandardPaths::writableLocation(QStandardPaths::ConfigLocation)
                                   + QStringLiteral("/qslate/config.ini"),
                               QStringLiteral("user config")));
        paths.append(qMakePair(QStringLiteral("/etc/qslate/config.ini"),
                               QStringLiteral("system config")));
    }
    for (const auto &p : paths) {
        ConfigCandidate c = makeCandidate(p.first, p.second);
        if (sel.selectedPath.isEmpty() && c.exists && c.readable) {
            c.selected = true;
            sel.selectedPath = c.path;
        }
        sel.candidates.append(c);
    }
    return sel;
}

AppConfig ConfigManager::load(const QString &path, QStringList *diagnostics, bool *ok)
{
    QStringList localDiag;
    QStringList &diag = diagnostics ? *diagnostics : localDiag;
    if (ok) {
        *ok = true;
    }
    AppConfig cfg = defaults();

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        diag << QStringLiteral("%1: cannot open: %2").arg(path, file.errorString());
        if (ok) {
            *ok = false;
        }
        return cfg;
    }
    QString content = QString::fromUtf8(file.readAll());
    if (content.startsWith(QChar(0xFEFF))) {
        content.remove(0, 1);
    }
    content = TextNormalization::normalizeNewlines(content);

    const QStringList knownShortcuts = shortcutIds();
    QString section;
    int lineNo = 0;
    const QStringList lines = content.split(QLatin1Char('\n'));
    for (const QString &rawLine : lines) {
        ++lineNo;
        const QString line = rawLine.trimmed();
        if (line.isEmpty() || line.at(0) == QLatin1Char(';') || line.at(0) == QLatin1Char('#')) {
            continue;
        }
        const QString where = QStringLiteral("%1:%2").arg(path).arg(lineNo);
        if (line.at(0) == QLatin1Char('[')) {
            if (!line.endsWith(QLatin1Char(']'))) {
                diag << QStringLiteral("%1: malformed section header").arg(where);
                section.clear();
                continue;
            }
            section = line.mid(1, line.size() - 2).trimmed();
            if (section != QLatin1String("editor") && section != QLatin1String("shortcuts")) {
                diag << QStringLiteral("%1: unknown section [%2] ignored").arg(where, section);
            }
            continue;
        }
        const int eq = line.indexOf(QLatin1Char('='));
        if (eq <= 0) {
            diag << QStringLiteral("%1: expected key=value").arg(where);
            continue;
        }
        const QString key = line.left(eq).trimmed();
        const QString value = line.mid(eq + 1).trimmed();

        if (section == QLatin1String("editor")) {
            const EditorKey *k = findEditorKey(key);
            if (!k) {
                diag << QStringLiteral("%1: unknown [editor] key '%2' ignored").arg(where, key);
                continue;
            }
            EditorConfig trial = cfg.editor;
            QString err;
            if (!k->parse(trial, value, &err)) {
                diag << QStringLiteral("%1: [editor] %2='%3': %4; value ignored")
                            .arg(where, key, value, err);
                continue;
            }
            cfg.editor = trial;
        } else if (section == QLatin1String("shortcuts")) {
            if (!knownShortcuts.contains(key)) {
                diag << QStringLiteral("%1: unknown shortcut action '%2' ignored").arg(where, key);
                continue;
            }
            if (!value.isEmpty()) {
                QKeySequence seq;
                QString err;
                if (!KeyBindings::parseAccelerator(value, &seq, &err)) {
                    diag << QStringLiteral("%1: [shortcuts] %2='%3': %4; value ignored")
                                .arg(where, key, value, err);
                    continue;
                }
            }
            cfg.shortcuts.set(key, value); // an empty value deliberately disables the binding
        } else {
            diag << QStringLiteral("%1: key '%2' outside [editor]/[shortcuts] ignored")
                        .arg(where, key);
        }
    }
    return cfg;
}

QString ConfigManager::describeSelection(const ConfigSelection &sel)
{
    QString out = QStringLiteral("QSlate configuration search order:\n");
    int n = 1;
    for (const ConfigCandidate &c : sel.candidates) {
        QString state = !c.exists ? QStringLiteral("missing")
                                  : (c.readable ? QStringLiteral("found")
                                                : QStringLiteral("unreadable"));
        out += QStringLiteral("  %1. [%2] %3  (%4)%5\n")
                   .arg(n++)
                   .arg(c.label, c.path, state,
                        c.selected ? QStringLiteral("  <- selected") : QString());
    }
    if (sel.selectedPath.isEmpty()) {
        out += sel.ok ? QStringLiteral("Active configuration: built-in defaults (no usable file found)\n")
                      : QStringLiteral("Error: %1\n").arg(sel.error);
    } else {
        out += QStringLiteral("Active configuration: %1\n").arg(sel.selectedPath);
    }
    return out;
}

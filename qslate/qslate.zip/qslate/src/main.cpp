// QSlate - entry point and command-line handling.
//
// Exit codes: 0 success | 1 command-line usage error (QCommandLineParser)
//             2 explicit --config file missing/unreadable
#include "ConfigManager.h"
#include "MainWindow.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QCoreApplication>
#include <QGuiApplication>
#include <QTextStream>

namespace {

void setupParser(QCommandLineParser &parser)
{
    parser.setApplicationDescription(
        QStringLiteral("QSlate - lightweight native plain-text editor.\n"
                       "Exit codes: 0 ok, 1 usage error, 2 unreadable --config file."));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addOption(QCommandLineOption(
        QStringLiteral("config"),
        QStringLiteral("Use PATH as the only configuration file (highest priority)."),
        QStringLiteral("PATH")));
    parser.addOption(QCommandLineOption(
        QStringLiteral("print-config"),
        QStringLiteral("Print the canonical built-in default configuration and exit.")));
    parser.addOption(QCommandLineOption(
        QStringLiteral("print-config-paths"),
        QStringLiteral("Print the configuration search order and the active file, then exit.")));
    parser.addPositionalArgument(
        QStringLiteral("FILE"),
        QStringLiteral("File to open. Only the first file is opened (one document at a time)."),
        QStringLiteral("[FILE...]"));
}

// Non-GUI commands run on a QCoreApplication so they work without a display.
int runConsoleMode(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("qslate"));
    QCoreApplication::setApplicationVersion(QStringLiteral(QSLATE_VERSION));
    QCommandLineParser parser;
    setupParser(parser);
    parser.process(app); // handles --help / --version, exits 1 on bad options

    QTextStream out(stdout);
    QTextStream err(stderr);
    if (parser.isSet(QStringLiteral("print-config"))) {
        out << ConfigManager::serialize(ConfigManager::defaults());
        return 0;
    }
    // --print-config-paths
    const ConfigSelection sel = ConfigManager::discover(parser.value(QStringLiteral("config")));
    out << ConfigManager::describeSelection(sel);
    if (!sel.ok) {
        err << sel.error << "\n";
        return 2;
    }
    return 0;
}

bool wantsConsoleMode(int argc, char **argv)
{
    for (int i = 1; i < argc; ++i) {
        const QString a = QString::fromLocal8Bit(argv[i]);
        if (a == QLatin1String("--help") || a == QLatin1String("-h") || a == QLatin1String("--version")
            || a == QLatin1String("-v") || a == QLatin1String("--print-config")
            || a == QLatin1String("--print-config-paths") || a == QLatin1String("--help-all")) {
            return true;
        }
    }
    return false;
}

} // namespace

int main(int argc, char *argv[])
{
    if (wantsConsoleMode(argc, argv)) {
        return runConsoleMode(argc, argv);
    }

    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("qslate"));
    QCoreApplication::setApplicationVersion(QStringLiteral(QSLATE_VERSION));
    QGuiApplication::setDesktopFileName(QStringLiteral("qslate"));
    QApplication::setStyle(QStringLiteral("Fusion"));

    QCommandLineParser parser;
    setupParser(parser);
    parser.process(app);

    QTextStream err(stderr);
    const ConfigSelection sel = ConfigManager::discover(parser.value(QStringLiteral("config")));
    if (!sel.ok) {
        err << "qslate: " << sel.error << "\n";
        return 2;
    }

    AppConfig config = ConfigManager::defaults();
    if (!sel.selectedPath.isEmpty()) {
        QStringList diagnostics;
        bool ok = false;
        config = ConfigManager::load(sel.selectedPath, &diagnostics, &ok);
        for (const QString &d : std::as_const(diagnostics)) {
            err << "qslate: " << d << "\n";
        }
        if (!ok) {
            if (sel.explicitRequested) {
                return 2;
            }
            config = ConfigManager::defaults();
        }
    }

    MainWindow window(config, parser.value(QStringLiteral("config")), sel.selectedPath);
    window.show();

    const QString notice = window.openInitialFiles(parser.positionalArguments());
    if (!notice.isEmpty()) {
        err << "qslate: " << notice << "\n";
    }
    return app.exec();
}

// QSlate - owner and painter of the editor surround (border_color/border_size).
//
// This is QSlate's own frame inside the window. It has nothing to do with the
// native title bar or window-manager decorations.
#pragma once

#include <QColor>
#include <QWidget>

class Editor;

class EditorFrame : public QWidget
{
    Q_OBJECT
public:
    explicit EditorFrame(Editor *editor, QWidget *parent = nullptr);

    // size 0 removes the surround completely.
    void setBorder(int size, const QColor &color);
    int borderSize() const { return m_size; }
    QColor borderColor() const { return m_color; }
    Editor *editor() const { return m_editor; }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    Editor *m_editor;
    int m_size = 0;
    QColor m_color;
};

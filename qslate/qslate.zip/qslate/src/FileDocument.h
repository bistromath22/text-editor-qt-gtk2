// QSlate - UTF-8 plain-text load/save with BOM handling and safe writes.
#pragma once

#include <QByteArray>
#include <QString>

struct LoadResult {
    bool ok = false;
    QString text;      // LF-normalized, BOM removed
    QString error;     // human readable when !ok
    bool hadBom = false;
};

struct SaveResult {
    bool ok = false;
    QString error;
};

namespace FileDocument {

// Policy: one leading UTF-8 BOM is stripped. Invalid UTF-8 is rejected with an
// error (never silently replaced). CRLF/CR become LF. Empty input is valid.
LoadResult decode(const QByteArray &bytes);
LoadResult load(const QString &path);

// Always UTF-8, no BOM, LF newlines.
QByteArray encode(const QString &text);

// Atomic write using QSaveFile; the target is untouched if anything fails.
SaveResult save(const QString &path, const QString &text);

} // namespace FileDocument

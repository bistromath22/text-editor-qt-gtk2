// QSlate - main window: menus, actions, file flow, status bar, title.
#pragma once

#include "ConfigManager.h"

#include <QHash>
#include <QMainWindow>
#include <QMessageBox>

#include <functional>

class Editor;
class EditorFrame;
class QAction;
class QLabel;

// Every modal interaction goes through these hooks so tests can drive the
// window without blocking dialogs. Defaults use the real Qt dialogs.
struct UiHooks {
    std::function<QMessageBox::StandardButton(const QString &documentName)> askSave;
    std::function<QString()> openFileName;
    std::function<QString(const QString &suggested)> saveFileName;
    std::function<QString(const QString &title, const QString &label, const QString &initial, bool *ok)> getText;
    std::function<void(const QString &title, const QString &message)> showError;
    std::function<void(const QString &title, const QString &message)> showInfo;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(const AppConfig &config, const QString &explicitConfigPath,
               const QString &activeConfigPath, QWidget *parent = nullptr);

    Editor *editor() const { return m_editor; }
    EditorFrame *frame() const { return m_frame; }
    QAction *action(const QString &id) const { return m_actions.value(id); }
    QString currentPath() const { return m_path; }
    UiHooks &hooks() { return m_hooks; }
    bool statusBarShown() const { return m_showStatusBar; }
    QString statusText() const;

    // Opens only the first path. Returns a notice (empty if nothing to report)
    // describing ignored extra paths; open errors go through hooks().showError.
    QString openInitialFiles(const QStringList &paths);

    bool newDocument();
    bool openDocument();
    bool openPath(const QString &path);
    bool saveDocument();
    bool saveDocumentAs();
    void showFindDialog();
    void findNext();
    void showGoToLineDialog();
    void reloadConfig();
    void applyConfig(const AppConfig &config);

protected:
    void closeEvent(QCloseEvent *event) override;
    void changeEvent(QEvent *event) override;

private:
    void buildActions();
    QAction *addAction(class QMenu *menu, const QString &id, const QString &text,
                       std::function<void()> handler);
    QAction *addCheckable(class QMenu *menu, const QString &id, const QString &text,
                          std::function<void(bool)> handler);
    bool maybeSave();
    bool writeTo(const QString &path);
    void updateTitle();
    void updateStatusText();
    void syncActions();
    void toggleFullScreen(bool on);
    void applyAppearance();

    Editor *m_editor = nullptr;
    EditorFrame *m_frame = nullptr;
    QLabel *m_statusLabel = nullptr;
    QHash<QString, QAction *> m_actions;
    UiHooks m_hooks;
    AppConfig m_config;
    QString m_explicitConfig;
    QString m_activeConfig;
    QString m_path;
    QString m_lastSearch;
    bool m_showStatusBar = false;
    bool m_wasMaximized = false;
};

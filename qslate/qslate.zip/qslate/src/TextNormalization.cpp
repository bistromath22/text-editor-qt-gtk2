#include "TextNormalization.h"

namespace TextNormalization {

QString normalizeNewlines(const QString &text)
{
    if (!text.contains(QLatin1Char('\r'))) {
        return text;
    }
    QString result = text;
    result.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    result.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    return result;
}

} // namespace TextNormalization

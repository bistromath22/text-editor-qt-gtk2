#include "MainWindow.h"

#include "Editor.h"
#include "EditorFrame.h"
#include "FileDocument.h"
#include "KeyBindings.h"

#include <QAction>
#include <QCloseEvent>
#include <QDebug>
#include <QFileDialog>
#include <QFileInfo>
#include <QInputDialog>
#include <QLabel>
#include <QMenu>
#include <QMenuBar>
#include <QRegularExpression>
#include <QSignalBlocker>
#include <QStatusBar>
#include <QTextDocument>

MainWindow::MainWindow(const AppConfig &config, const QString &explicitConfigPath,
                       const QString &activeConfigPath, QWidget *parent)
    : QMainWindow(parent)
    , m_config(config)
    , m_explicitConfig(explicitConfigPath)
    , m_activeConfig(activeConfigPath)
{
    m_editor = new Editor;
    m_frame = new EditorFrame(m_editor, this);
    setCentralWidget(m_frame);

    m_statusLabel = new QLabel(this);
    statusBar()->addWidget(m_statusLabel);
    statusBar()->setSizeGripEnabled(false);

    // Default (real) dialogs.
    m_hooks.askSave = [this](const QString &name) {
        return QMessageBox::question(this, QStringLiteral("QSlate"),
                                     tr("Save changes to %1?").arg(name),
                                     QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel,
                                     QMessageBox::Save);
    };
    m_hooks.openFileName = [this] {
        return QFileDialog::getOpenFileName(this, tr("Open"), QFileInfo(m_path).absolutePath());
    };
    m_hooks.saveFileName = [this](const QString &suggested) {
        return QFileDialog::getSaveFileName(this, tr("Save As"), suggested);
    };
    m_hooks.getText = [this](const QString &title, const QString &label, const QString &initial,
                             bool *ok) {
        return QInputDialog::getText(this, title, label, QLineEdit::Normal, initial, ok);
    };
    m_hooks.showError = [this](const QString &title, const QString &msg) {
        QMessageBox::warning(this, title, msg);
    };
    m_hooks.showInfo = [this](const QString &title, const QString &msg) {
        QMessageBox::information(this, title, msg);
    };

    buildActions();

    connect(m_editor, &QTextEdit::cursorPositionChanged, this, &MainWindow::updateStatusText);
    connect(m_editor, &QTextEdit::textChanged, this, &MainWindow::updateStatusText);
    connect(m_editor->document(), &QTextDocument::modificationChanged, this,
            [this](bool) { updateTitle(); });
    connect(m_editor, &QTextEdit::undoAvailable, action(QStringLiteral("undo")), &QAction::setEnabled);
    connect(m_editor, &QTextEdit::redoAvailable, action(QStringLiteral("redo")), &QAction::setEnabled);
    connect(m_editor, &QTextEdit::copyAvailable, action(QStringLiteral("cut")), &QAction::setEnabled);
    connect(m_editor, &QTextEdit::copyAvailable, action(QStringLiteral("copy")), &QAction::setEnabled);
    connect(m_editor, &Editor::configApplied, this, &MainWindow::syncActions);

    action(QStringLiteral("undo"))->setEnabled(false);
    action(QStringLiteral("redo"))->setEnabled(false);
    action(QStringLiteral("cut"))->setEnabled(false);
    action(QStringLiteral("copy"))->setEnabled(false);

    setMinimumSize(400, 300);
    resize(900, 600);
    applyConfig(config);
    updateTitle();
    updateStatusText();
    m_editor->setFocus();
}

// ------------------------------------------------------------------- actions

QAction *MainWindow::addAction(QMenu *menu, const QString &id, const QString &text,
                               std::function<void()> handler)
{
    auto *a = new QAction(text, this);
    connect(a, &QAction::triggered, this, [handler](bool) { handler(); });
    menu->addAction(a);
    m_actions.insert(id, a);
    return a;
}

QAction *MainWindow::addCheckable(QMenu *menu, const QString &id, const QString &text,
                                  std::function<void(bool)> handler)
{
    auto *a = new QAction(text, this);
    a->setCheckable(true);
    connect(a, &QAction::toggled, this, [handler](bool on) { handler(on); });
    menu->addAction(a);
    m_actions.insert(id, a);
    return a;
}

void MainWindow::buildActions()
{
    QMenu *file = menuBar()->addMenu(tr("&File"));
    addAction(file, QStringLiteral("new_file"), tr("New"), [this] { newDocument(); });
    addAction(file, QStringLiteral("open"), tr("Open..."), [this] { openDocument(); });
    addAction(file, QStringLiteral("save"), tr("Save"), [this] { saveDocument(); });
    addAction(file, QStringLiteral("save_as"), tr("Save As..."), [this] { saveDocumentAs(); });
    file->addSeparator();
    addAction(file, QStringLiteral("quit"), tr("Quit"), [this] { close(); });

    QMenu *edit = menuBar()->addMenu(tr("&Edit"));
    addAction(edit, QStringLiteral("undo"), tr("Undo"), [this] { m_editor->undo(); });
    addAction(edit, QStringLiteral("redo"), tr("Redo"), [this] { m_editor->redo(); });
    edit->addSeparator();
    addAction(edit, QStringLiteral("cut"), tr("Cut"), [this] { m_editor->cut(); });
    addAction(edit, QStringLiteral("copy"), tr("Copy"), [this] { m_editor->copy(); });
    addAction(edit, QStringLiteral("paste"), tr("Paste"), [this] { m_editor->paste(); });
    edit->addSeparator();
    addAction(edit, QStringLiteral("find"), tr("Find..."), [this] { showFindDialog(); });
    addAction(edit, QStringLiteral("find_next"), tr("Find Next"), [this] { findNext(); });
    addAction(edit, QStringLiteral("goto_line"), tr("Go to Line..."), [this] { showGoToLineDialog(); });
    edit->addSeparator();
    addAction(edit, QStringLiteral("reload_config"), tr("Reload Config"), [this] { reloadConfig(); });
    addCheckable(edit, QStringLiteral("toggle_wordwrap"), tr("Toggle Word Wrap"),
                 [this](bool on) { m_editor->setWordWrap(on); });
    addCheckable(edit, QStringLiteral("toggle_block_cursor"), tr("Toggle Block Cursor"),
                 [this](bool on) { m_editor->setBlockCursor(on); });
    addAction(edit, QStringLiteral("increase_font"), tr("Increase Font"),
              [this] { m_editor->setFontSize(m_editor->config().fontSize + 1.0); });
    addAction(edit, QStringLiteral("decrease_font"), tr("Decrease Font"),
              [this] { m_editor->setFontSize(m_editor->config().fontSize - 1.0); });

    QMenu *view = menuBar()->addMenu(tr("&View"));
    addCheckable(view, QStringLiteral("fullscreen"), tr("Full Screen"),
                 [this](bool on) { toggleFullScreen(on); });
    addCheckable(view, QStringLiteral("toggle_line_numbers"), tr("Show Line Numbers"),
                 [this](bool on) { m_editor->setShowLineNumbers(on); });
    addCheckable(view, QStringLiteral("toggle_current_line"), tr("Highlight Current Line"),
                 [this](bool on) { m_editor->setHighlightCurrentLine(on); });
    addCheckable(view, QStringLiteral("toggle_statusbar"), tr("Show Status Bar"), [this](bool on) {
        m_showStatusBar = on;
        statusBar()->setVisible(on);
        syncActions();
    });
}

void MainWindow::syncActions()
{
    const EditorConfig &c = m_editor->config();
    auto set = [this](const char *id, bool checked) {
        QAction *a = m_actions.value(QLatin1String(id));
        const QSignalBlocker blocker(a);
        a->setChecked(checked);
    };
    set("toggle_wordwrap", c.wordWrap);
    set("toggle_block_cursor", c.blockCursor);
    set("toggle_line_numbers", c.showLineNumbers);
    set("toggle_current_line", c.highlightCurrentLine);
    set("toggle_statusbar", m_showStatusBar);
    set("fullscreen", isFullScreen());
}

void MainWindow::toggleFullScreen(bool on)
{
    if (on) {
        m_wasMaximized = isMaximized();
        showFullScreen();
    } else if (m_wasMaximized) {
        showMaximized();
    } else {
        showNormal();
    }
}

void MainWindow::changeEvent(QEvent *event)
{
    QMainWindow::changeEvent(event);
    if (event->type() == QEvent::WindowStateChange && !m_actions.isEmpty()) {
        syncActions();
    }
}

// ------------------------------------------------------------ configuration

void MainWindow::applyAppearance()
{
    const EditorConfig &c = m_config.editor;
    QPalette p = palette();
    p.setColor(QPalette::Window, c.gutterBackgroundColor);
    p.setColor(QPalette::WindowText, c.textColor);
    p.setColor(QPalette::Base, c.backgroundColor);
    p.setColor(QPalette::Text, c.textColor);
    p.setColor(QPalette::Button, c.gutterBackgroundColor);
    p.setColor(QPalette::ButtonText, c.textColor);
    p.setColor(QPalette::Highlight, ColorUtil::blend(c.backgroundColor, c.textColor, 0.28));
    p.setColor(QPalette::HighlightedText, c.textColor);
    p.setColor(QPalette::PlaceholderText, c.lineNumberColor);
    p.setColor(QPalette::Disabled, QPalette::WindowText, c.lineNumberColor);
    p.setColor(QPalette::Disabled, QPalette::Text, c.lineNumberColor);
    p.setColor(QPalette::Disabled, QPalette::ButtonText, c.lineNumberColor);
    setPalette(p);

    QPalette sp = statusBar()->palette();
    sp.setColor(QPalette::Window, c.gutterBackgroundColor);
    sp.setColor(QPalette::WindowText, c.textColor);
    statusBar()->setPalette(sp);
    statusBar()->setAutoFillBackground(true);
}

void MainWindow::applyConfig(const AppConfig &config)
{
    m_config = config;
    m_showStatusBar = config.editor.showStatusbar;
    applyAppearance();
    m_frame->setBorder(config.editor.borderSize, config.editor.borderColor);
    m_editor->applyConfig(config.editor); // also re-syncs the checkable actions
    statusBar()->setVisible(m_showStatusBar);

    const ResolvedShortcuts resolved = KeyBindings::resolve(config.shortcuts);
    KeyBindings::apply(m_actions, resolved); // existing QActions are updated in place
    m_editor->setReservedShortcuts(resolved.sequences.values());
    for (const QString &w : resolved.warnings) {
        qWarning().noquote() << "QSlate:" << w;
    }
    syncActions();
}

void MainWindow::reloadConfig()
{
    const ConfigSelection sel = ConfigManager::discover(m_explicitConfig);
    if (!sel.ok) {
        m_hooks.showError(tr("Reload Config"), sel.error);
        return;
    }
    AppConfig cfg = ConfigManager::defaults();
    QStringList diagnostics;
    if (!sel.selectedPath.isEmpty()) {
        bool ok = false;
        cfg = ConfigManager::load(sel.selectedPath, &diagnostics, &ok);
        if (!ok) {
            m_hooks.showError(tr("Reload Config"), diagnostics.join(QLatin1Char('\n')));
            return;
        }
    }
    m_activeConfig = sel.selectedPath;
    applyConfig(cfg);
    for (const QString &d : std::as_const(diagnostics)) {
        qWarning().noquote() << "QSlate:" << d;
    }
    statusBar()->showMessage(diagnostics.isEmpty() ? tr("Configuration reloaded")
                                                   : tr("Configuration reloaded with %1 warning(s)")
                                                         .arg(diagnostics.size()),
                             4000);
}

// ---------------------------------------------------------------- file flow

QString MainWindow::openInitialFiles(const QStringList &paths)
{
    if (paths.isEmpty()) {
        return QString();
    }
    openPath(paths.first());
    if (paths.size() > 1) {
        return tr("QSlate holds one document at a time: opened '%1' and ignored %2 additional "
                  "file(s): %3")
            .arg(paths.first())
            .arg(paths.size() - 1)
            .arg(paths.mid(1).join(QStringLiteral(", ")));
    }
    return QString();
}

bool MainWindow::maybeSave()
{
    if (!m_editor->document()->isModified()) {
        return true;
    }
    const QString name = m_path.isEmpty() ? tr("Untitled") : QFileInfo(m_path).fileName();
    switch (m_hooks.askSave(name)) {
    case QMessageBox::Save:
        return saveDocument();
    case QMessageBox::Discard:
        return true;
    default:
        return false; // Cancel: nothing changes
    }
}

bool MainWindow::newDocument()
{
    if (!maybeSave()) {
        return false;
    }
    m_editor->loadPlainText(QString());
    m_path.clear();
    updateTitle();
    return true;
}

bool MainWindow::openDocument()
{
    if (!maybeSave()) {
        return false;
    }
    const QString path = m_hooks.openFileName();
    return !path.isEmpty() && openPath(path);
}

bool MainWindow::openPath(const QString &path)
{
    const LoadResult r = FileDocument::load(path); // read exactly once
    if (!r.ok) {
        m_hooks.showError(tr("Open"), r.error); // current document stays untouched
        return false;
    }
    m_editor->loadPlainText(r.text);
    m_path = QFileInfo(path).absoluteFilePath();
    updateTitle();
    updateStatusText();
    return true;
}

bool MainWindow::writeTo(const QString &path)
{
    const SaveResult r = FileDocument::save(path, m_editor->exportPlainText());
    if (!r.ok) {
        m_hooks.showError(tr("Save"), r.error); // path and modified state unchanged
        return false;
    }
    m_path = QFileInfo(path).absoluteFilePath(); // only after a committed write
    m_editor->document()->setModified(false);
    updateTitle();
    return true;
}

bool MainWindow::saveDocument()
{
    return m_path.isEmpty() ? saveDocumentAs() : writeTo(m_path);
}

bool MainWindow::saveDocumentAs()
{
    const QString path = m_hooks.saveFileName(m_path);
    return !path.isEmpty() && writeTo(path);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (maybeSave()) {
        event->accept();
    } else {
        event->ignore();
    }
}

void MainWindow::updateTitle()
{
    const QString name = m_path.isEmpty() ? tr("Untitled") : QFileInfo(m_path).fileName();
    QString title = QStringLiteral("QSlate — %1").arg(name);
    if (m_editor->document()->isModified()) {
        title += QStringLiteral(" [modified]");
    }
    setWindowTitle(title);
}

// ------------------------------------------------- find / go to / status bar

void MainWindow::showFindDialog()
{
    bool ok = false;
    const QString text = m_hooks.getText(tr("Find"), tr("Find:"), m_lastSearch, &ok);
    if (ok && !text.isEmpty()) {
        m_lastSearch = text;
        findNext();
    }
}

void MainWindow::findNext()
{
    if (m_lastSearch.isEmpty()) {
        showFindDialog();
        return;
    }
    switch (m_editor->findText(m_lastSearch)) {
    case Editor::FindResult::Found:
        break;
    case Editor::FindResult::FoundWrapped:
        statusBar()->showMessage(tr("Search wrapped to the beginning"), 3000);
        break;
    case Editor::FindResult::NotFound:
        m_hooks.showInfo(tr("Find"), tr("Not found: %1").arg(m_lastSearch));
        break;
    }
}

void MainWindow::showGoToLineDialog()
{
    const int maxLine = m_editor->document()->blockCount();
    bool ok = false;
    const QString text = m_hooks.getText(tr("Go to Line"), tr("Line number (1-%1):").arg(maxLine),
                                         QString(), &ok);
    if (!ok) {
        return;
    }
    static const QRegularExpression digits(QStringLiteral("^[0-9]+$"));
    const QString t = text.trimmed();
    bool parsed = false;
    const int line = digits.match(t).hasMatch() ? t.toInt(&parsed) : 0;
    if (!parsed || !m_editor->goToLine(line)) {
        m_hooks.showError(tr("Go to Line"),
                          tr("Enter a whole number between 1 and %1.").arg(maxLine));
    }
}

QString MainWindow::statusText() const
{
    return tr("Ln %1, Col %2").arg(m_editor->currentLine()).arg(m_editor->currentColumn());
}

void MainWindow::updateStatusText()
{
    if (m_statusLabel) {
        m_statusLabel->setText(statusText());
    }
}

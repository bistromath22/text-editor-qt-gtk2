// QSlate - canonical configuration model, validation, INI loading/serialization.
#pragma once

#include <QColor>
#include <QPair>
#include <QString>
#include <QStringList>
#include <QVector>

// Shared numeric validation. Used by ConfigManager (INI parsing) AND by the
// Editor setter APIs so both always agree on the accepted ranges.
namespace Validation {
constexpr double kFontSizeMin = 6.0;
constexpr double kFontSizeMax = 96.0;
constexpr int kBorderSizeMin = 0;
constexpr int kBorderSizeMax = 100;
constexpr int kParagraphSpacingMin = 0;
constexpr int kParagraphSpacingMax = 200;
constexpr int kLineDistanceMin = 0;
constexpr int kLineDistanceMax = 100;
constexpr double kLineHeightMin = 0.5;
constexpr double kLineHeightMax = 5.0;

bool fontSize(double value);        // finite and within [6, 96]
bool borderSize(int value);         // [0, 100]
bool paragraphSpacing(int value);   // [0, 200]
bool lineDistance(int value);       // [0, 100]
bool lineHeight(double value);      // finite and within [0.5, 5.0]
} // namespace Validation

namespace ColorUtil {
// Linear blend: t = 0 -> a, t = 1 -> b.
QColor blend(const QColor &a, const QColor &b, double t);
}

// Values are filled in by ConfigManager::defaults(); the zero-initialised
// members here are NOT defaults and must never be used directly.
struct EditorConfig {
    bool wordWrap = false;
    int borderSize = 0;
    QColor borderColor;
    QColor backgroundColor;
    QColor gutterBackgroundColor;
    QColor currentLineColor;
    QColor lineNumberColor;
    QColor textColor;
    bool blockCursor = false;
    bool blockCursorBlink = false;
    QString fontFamily;
    double fontSize = 0.0;
    double lineHeight = 0.0;
    int pixelsAbove = 0;
    int pixelsBelow = 0;
    int lineDistance = 0;
    bool showLineNumbers = false;
    bool highlightCurrentLine = false;
    bool showStatusbar = false;
};

// Ordered list of (action id, GTK-style accelerator text). The text is kept
// exactly as written so printing preserves the user's spelling.
struct ShortcutConfig {
    QVector<QPair<QString, QString>> entries;

    bool contains(const QString &id) const;
    QString value(const QString &id) const;
    void set(const QString &id, const QString &accelerator);
};

struct AppConfig {
    EditorConfig editor;
    ShortcutConfig shortcuts;
};

struct ConfigCandidate {
    QString path;
    QString label;
    bool exists = false;
    bool readable = false;
    bool selected = false;
};

struct ConfigSelection {
    QVector<ConfigCandidate> candidates;
    QString selectedPath;      // empty => built-in defaults
    bool explicitRequested = false;
    bool ok = true;
    QString error;
};

class ConfigManager
{
public:
    // The single canonical defaults source (the user's preferred config.ini).
    static AppConfig defaults();

    // Serialize to INI text; this drives --print-config and the tests that
    // check config.example.ini.
    static QString serialize(const AppConfig &config);

    // All action ids that may appear in [shortcuts] (defaults + optional).
    static QStringList shortcutIds();

    // Search order: explicit path | ./config.ini | ~/.config/qslate/config.ini |
    // /etc/qslate/config.ini. `searchOverride` replaces the three automatic
    // locations (used by tests).
    static ConfigSelection discover(const QString &explicitPath = QString(),
                                    const QStringList &searchOverride = QStringList());

    // Load a file over the canonical defaults. Invalid keys keep their default
    // and add a diagnostic. *ok is false only if the file cannot be opened.
    static AppConfig load(const QString &path, QStringList *diagnostics, bool *ok);

    static QString describeSelection(const ConfigSelection &selection);
};

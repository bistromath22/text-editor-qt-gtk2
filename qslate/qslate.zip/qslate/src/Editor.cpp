#include "Editor.h"

#include "LineNumberArea.h"
#include "TextNormalization.h"

#include <QAbstractTextDocumentLayout>
#include <QDebug>
#include <QFontDatabase>
#include <QFontMetricsF>
#include <QKeyEvent>
#include <QMimeData>
#include <QPaintEngine>
#include <QPainter>
#include <QScrollBar>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextDocument>

#include <cmath>

namespace {

// Internal geometry, deliberately independent from border_size:
//  * kContentInset  - padding between viewport edge and text (all four sides,
//                     painted with background_color, owned by QTextDocument).
//  * the gutter     - Editor::lineNumberAreaWidth(), owned by the Editor.
//  * the surround   - EditorFrame (border_size), a separate widget.
constexpr qreal kContentInset = 8.0;
constexpr int kBlinkIntervalMs = 530;

QString resolveFontFamily(const QString &requested, QString *note)
{
    const QStringList families = QFontDatabase::families();
    for (const QString &f : families) {
        if (f.compare(requested, Qt::CaseInsensitive) == 0) {
            return f;
        }
    }
    const QString fallback = QFontDatabase::systemFont(QFontDatabase::FixedFont).family();
    if (note) {
        *note = QStringLiteral("QSlate: font family '%1' is not installed; displaying with the "
                               "system monospace font '%2' (configuration value unchanged)")
                    .arg(requested, fallback);
    }
    return fallback;
}

bool formatMatches(const QTextBlockFormat &a, const QTextBlockFormat &b)
{
    return a.lineHeightType() == b.lineHeightType()
        && std::fabs(a.lineHeight() - b.lineHeight()) < 1e-6
        && std::fabs(a.topMargin() - b.topMargin()) < 1e-6
        && std::fabs(a.bottomMargin() - b.bottomMargin()) < 1e-6;
}

} // namespace

Editor::Editor(QWidget *parent)
    : QTextEdit(parent)
    , m_config(ConfigManager::defaults().editor)
    , m_gutter(new LineNumberArea(this))
{
    setAcceptRichText(false);
    setFrameShape(QFrame::NoFrame);
    setTabChangesFocus(false);
    setAutoFormatting(QTextEdit::AutoNone);

    m_blinkTimer.setInterval(kBlinkIntervalMs);
    connect(&m_blinkTimer, &QTimer::timeout, this, [this] {
        m_blockPhaseOn = !m_blockPhaseOn;
        viewport()->update();
    });

    // Gutter/highlight bookkeeping only. Paragraph formatting is NOT done from
    // blockCountChanged (that broke consecutive empty blocks in the old code).
    connect(document(), &QTextDocument::blockCountChanged, this, [this] { updateGutterLayout(); });
    connect(verticalScrollBar(), &QScrollBar::valueChanged, this, [this] { m_gutter->update(); });
    connect(document()->documentLayout(), &QAbstractTextDocumentLayout::documentSizeChanged, this,
            [this] { m_gutter->update(); });
    connect(this, &QTextEdit::textChanged, this, [this] { m_gutter->update(); });
    connect(this, &QTextEdit::cursorPositionChanged, this, [this] {
        m_blockPhaseOn = true;
        if (m_blinkTimer.isActive()) {
            m_blinkTimer.start();
        }
        updateCurrentLineHighlight();
        viewport()->update();
        m_gutter->update();
    });

    applyCurrentConfig(true);
    document()->setModified(false);
}

// ------------------------------------------------------------ configuration

void Editor::applyConfig(const EditorConfig &requested)
{
    EditorConfig c = requested;
    if (!Validation::fontSize(c.fontSize)) c.fontSize = m_config.fontSize;
    if (!Validation::borderSize(c.borderSize)) c.borderSize = m_config.borderSize;
    if (!Validation::lineHeight(c.lineHeight)) c.lineHeight = m_config.lineHeight;
    if (!Validation::paragraphSpacing(c.pixelsAbove)) c.pixelsAbove = m_config.pixelsAbove;
    if (!Validation::paragraphSpacing(c.pixelsBelow)) c.pixelsBelow = m_config.pixelsBelow;
    if (!Validation::lineDistance(c.lineDistance)) c.lineDistance = m_config.lineDistance;
    if (!c.borderColor.isValid()) c.borderColor = m_config.borderColor;
    if (!c.backgroundColor.isValid()) c.backgroundColor = m_config.backgroundColor;
    if (!c.gutterBackgroundColor.isValid()) c.gutterBackgroundColor = m_config.gutterBackgroundColor;
    if (!c.currentLineColor.isValid()) c.currentLineColor = m_config.currentLineColor;
    if (!c.lineNumberColor.isValid()) c.lineNumberColor = m_config.lineNumberColor;
    if (!c.textColor.isValid()) c.textColor = m_config.textColor;
    if (c.fontFamily.trimmed().isEmpty()) c.fontFamily = m_config.fontFamily;

    const bool policyChanged = c.lineHeight != m_config.lineHeight
        || c.pixelsAbove != m_config.pixelsAbove || c.pixelsBelow != m_config.pixelsBelow
        || c.lineDistance != m_config.lineDistance;
    m_config = c;
    applyCurrentConfig(policyChanged);
}

void Editor::applyCurrentConfig(bool policyChanged)
{
    QString note;
    m_effectiveFamily = resolveFontFamily(m_config.fontFamily, &note);
    if (!note.isEmpty() && note != m_lastFallbackWarning) {
        qWarning().noquote() << note;
    }
    m_lastFallbackWarning = note;

    QFont f(m_effectiveFamily);
    f.setPointSizeF(m_config.fontSize);
    f.setStyleHint(QFont::Monospace);
    setFont(f);
    document()->setDefaultFont(f);
    document()->setDocumentMargin(kContentInset);
    setTabStopDistance(4.0 * QFontMetricsF(f).horizontalAdvance(QLatin1Char(' ')));

    QPalette p = palette();
    p.setColor(QPalette::Base, m_config.backgroundColor);
    p.setColor(QPalette::Window, m_config.backgroundColor);
    p.setColor(QPalette::Text, m_config.textColor);
    p.setColor(QPalette::WindowText, m_config.textColor);
    p.setColor(QPalette::Highlight, ColorUtil::blend(m_config.backgroundColor, m_config.textColor, 0.28));
    p.setColor(QPalette::HighlightedText, m_config.textColor);
    setPalette(p);

    setLineWrapMode(m_config.wordWrap ? QTextEdit::WidgetWidth : QTextEdit::NoWrap);
    setWordWrapMode(QTextOption::WrapAtWordBoundaryOrAnywhere);

    if (policyChanged) {
        reformatAllBlocks();
    }

    setCursorWidth(m_config.blockCursor ? 0 : 1); // block caret is drawn by paintBlockCursor()
    updateBlinkState();
    updateGutterLayout();
    updateCurrentLineHighlight();
    viewport()->update();
    emit configApplied();
}

bool Editor::setFontSize(double v)
{
    if (!Validation::fontSize(v)) return false;
    EditorConfig c = m_config;
    c.fontSize = v;
    applyConfig(c);
    return true;
}

bool Editor::setLineHeight(double v)
{
    if (!Validation::lineHeight(v)) return false;
    EditorConfig c = m_config;
    c.lineHeight = v;
    applyConfig(c);
    return true;
}

bool Editor::setPixelsAbove(int v)
{
    if (!Validation::paragraphSpacing(v)) return false;
    EditorConfig c = m_config;
    c.pixelsAbove = v;
    applyConfig(c);
    return true;
}

bool Editor::setPixelsBelow(int v)
{
    if (!Validation::paragraphSpacing(v)) return false;
    EditorConfig c = m_config;
    c.pixelsBelow = v;
    applyConfig(c);
    return true;
}

bool Editor::setLineDistance(int v)
{
    if (!Validation::lineDistance(v)) return false;
    EditorConfig c = m_config;
    c.lineDistance = v;
    applyConfig(c);
    return true;
}

void Editor::setWordWrap(bool on)
{
    EditorConfig c = m_config;
    c.wordWrap = on;
    applyConfig(c);
}

void Editor::setBlockCursor(bool on)
{
    EditorConfig c = m_config;
    c.blockCursor = on;
    applyConfig(c);
}

void Editor::setBlockCursorBlink(bool on)
{
    EditorConfig c = m_config;
    c.blockCursorBlink = on;
    applyConfig(c);
}

void Editor::setShowLineNumbers(bool on)
{
    EditorConfig c = m_config;
    c.showLineNumbers = on;
    applyConfig(c);
}

void Editor::setHighlightCurrentLine(bool on)
{
    EditorConfig c = m_config;
    c.highlightCurrentLine = on;
    applyConfig(c);
}

// ----------------------------------------------- paragraph presentation policy

// line_height  -> proportional line box inside every block (140.0 == 1.4x).
// pixels_above -> block top margin.
// pixels_below -> block bottom margin.
// line_distance-> extra gap added to the block bottom margin (documented in
//                 DESIGN.md; Qt allows only one lineHeightType per block, so it
//                 cannot be an intra-paragraph gap together with proportional
//                 height). Qt collapses adjacent block margins (larger wins).
QTextBlockFormat Editor::policyBlockFormat() const
{
    QTextBlockFormat f;
    f.setLineHeight(m_config.lineHeight * 100.0, QTextBlockFormat::ProportionalHeight);
    f.setTopMargin(m_config.pixelsAbove);
    f.setBottomMargin(m_config.pixelsBelow + m_config.lineDistance);
    return f;
}

void Editor::formatRange(int firstBlock, int lastBlock)
{
    const QTextBlockFormat policy = policyBlockFormat();
    QTextBlock block = document()->findBlockByNumber(qMax(0, firstBlock));
    for (int n = qMax(0, firstBlock); block.isValid() && n <= lastBlock; ++n, block = block.next()) {
        if (!formatMatches(block.blockFormat(), policy)) {
            QTextCursor bc(block);
            bc.mergeBlockFormat(policy);
        }
    }
}

// Used for load and for a changed spacing policy only. With no undo history
// nothing is recorded. If history exists the change is one extra undo entry
// (Qt records block-format changes); the modified flag is restored either way.
void Editor::reformatAllBlocks()
{
    QTextDocument *doc = document();
    const bool wasModified = doc->isModified();
    const bool hasHistory = doc->isUndoAvailable() || doc->isRedoAvailable();
    if (!hasHistory) {
        doc->setUndoRedoEnabled(false);
        formatRange(0, doc->blockCount() - 1);
        doc->setUndoRedoEnabled(true);
    } else {
        QTextCursor c(doc);
        c.beginEditBlock();
        formatRange(0, doc->blockCount() - 1);
        c.endEditBlock();
    }
    doc->setModified(wasModified);
}

// ------------------------------------------------------------ text access

QString Editor::exportPlainText() const
{
    QString out;
    out.reserve(document()->characterCount());
    bool first = true;
    for (QTextBlock b = document()->begin(); b.isValid(); b = b.next()) {
        if (!first) {
            out += QLatin1Char('\n');
        }
        first = false;
        out += b.text();
    }
    return out;
}

void Editor::loadPlainText(const QString &text)
{
    QTextDocument *doc = document();
    doc->setUndoRedoEnabled(false);
    setPlainText(TextNormalization::normalizeNewlines(text));
    formatRange(0, doc->blockCount() - 1);
    doc->setUndoRedoEnabled(true);
    doc->setModified(false);
    setTextCursor(QTextCursor(doc));
    verticalScrollBar()->setValue(0);
    updateGutterLayout();
    updateCurrentLineHighlight();
}

int Editor::currentLine() const { return textCursor().blockNumber() + 1; }
int Editor::currentColumn() const { return textCursor().positionInBlock() + 1; }

bool Editor::goToLine(int line)
{
    if (line < 1 || line > document()->blockCount()) {
        return false;
    }
    const QTextBlock block = document()->findBlockByNumber(line - 1);
    setTextCursor(QTextCursor(block));
    ensureCursorVisible();
    return true;
}

Editor::FindResult Editor::findText(const QString &needle)
{
    if (needle.isEmpty()) {
        return FindResult::NotFound;
    }
    QTextCursor found = document()->find(needle, textCursor());
    FindResult result = FindResult::Found;
    if (found.isNull()) {
        found = document()->find(needle, 0);
        result = FindResult::FoundWrapped;
    }
    if (found.isNull()) {
        return FindResult::NotFound; // selection and caret untouched
    }
    setTextCursor(found);
    ensureCursorVisible();
    return result;
}

void Editor::setReservedShortcuts(const QList<QKeySequence> &sequences) { m_reserved = sequences; }

// --------------------------------------------------------- Enter and clipboard

bool Editor::event(QEvent *e)
{
    if (e->type() == QEvent::ShortcutOverride) {
        auto *ke = static_cast<QKeyEvent *>(e);
        Qt::KeyboardModifiers mods = ke->modifiers();
        mods.setFlag(Qt::KeypadModifier, false);
        Qt::KeyboardModifiers noShift = mods;
        noShift.setFlag(Qt::ShiftModifier, false);
        const QKeyCombination withShift(mods, Qt::Key(ke->key()));
        const QKeyCombination withoutShift(noShift, Qt::Key(ke->key()));
        for (const QKeySequence &s : std::as_const(m_reserved)) {
            if (s.count() == 1 && (s[0] == withShift || s[0] == withoutShift)) {
                e->ignore(); // let the QAction (configurable shortcut) handle it
                return true;
            }
        }
    }
    return QTextEdit::event(e);
}

void Editor::keyPressEvent(QKeyEvent *e)
{
    // Enter / Return (also Shift+Enter, because a soft line break is not plain
    // text) inserts exactly one logical paragraph break. Other modified Enter
    // combinations are left to Qt.
    Qt::KeyboardModifiers mods = e->modifiers();
    mods.setFlag(Qt::KeypadModifier, false);
    mods.setFlag(Qt::ShiftModifier, false);
    if ((e->key() == Qt::Key_Return || e->key() == Qt::Key_Enter) && mods == Qt::KeyboardModifiers()) {
        insertParagraphBreak();
        e->accept();
        return;
    }
    QTextEdit::keyPressEvent(e);
}

void Editor::insertParagraphBreak()
{
    QTextCursor c = textCursor();
    const int first = document()->findBlock(c.selectionStart()).blockNumber();
    c.beginEditBlock();
    c.removeSelectedText();
    c.insertBlock();
    formatRange(first, c.blockNumber());
    c.endEditBlock();
    setTextCursor(c);
    ensureCursorVisible();
}

bool Editor::canInsertFromMimeData(const QMimeData *source) const
{
    return source && source->hasText();
}

void Editor::insertFromMimeData(const QMimeData *source)
{
    // Plain text only: HTML, images and every other format are ignored, and
    // the base-class rich-text path is never reached.
    if (!source || !source->hasText()) {
        return;
    }
    insertPlainTextTransaction(TextNormalization::normalizeNewlines(source->text()));
}

void Editor::insertPlainTextTransaction(const QString &normalized)
{
    QTextCursor c = textCursor();
    const int first = document()->findBlock(c.selectionStart()).blockNumber();
    c.beginEditBlock(); // the whole paste is ONE undo step
    c.removeSelectedText();
    c.insertText(normalized);
    formatRange(first, c.blockNumber());
    c.endEditBlock();
    setTextCursor(c);
    ensureCursorVisible();
    // Once Qt has finished its layout pass, make sure the last line is reachable.
    QTimer::singleShot(0, this, [this] {
        ensureCursorVisible();
        m_gutter->update();
    });
}

QString Editor::selectedPlainText() const
{
    QString t = textCursor().selectedText();
    t.replace(QChar::ParagraphSeparator, QLatin1Char('\n'));
    return t;
}

QMimeData *Editor::createMimeDataFromSelection() const
{
    auto *data = new QMimeData;
    data->setText(selectedPlainText()); // text/plain only, LF separators
    return data;
}

// ------------------------------------------------------ gutter and highlight

int Editor::lineNumberAreaWidth() const
{
    if (!m_config.showLineNumbers) {
        return 0;
    }
    int digits = 1;
    int n = qMax(1, document()->blockCount());
    while (n >= 10) {
        n /= 10;
        ++digits;
    }
    return LineNumberArea::kPaddingLeft + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits
        + LineNumberArea::kPaddingRight;
}

void Editor::updateGutterLayout()
{
    const int w = lineNumberAreaWidth();
    setViewportMargins(w, 0, 0, 0);
    m_gutter->setColors(m_config.gutterBackgroundColor, m_config.lineNumberColor);
    m_gutter->setVisible(w > 0);
    const QRect cr = contentsRect();
    m_gutter->setGeometry(QRect(cr.left(), cr.top(), w, viewport()->height()));
    m_gutter->update();
}

void Editor::updateCurrentLineHighlight()
{
    QList<QTextEdit::ExtraSelection> selections;
    if (m_config.highlightCurrentLine) {
        QTextEdit::ExtraSelection sel;
        sel.format.setBackground(m_config.currentLineColor);
        sel.format.setProperty(QTextFormat::FullWidthSelection, true);
        QTextCursor c = textCursor();
        c.movePosition(QTextCursor::StartOfBlock);
        c.movePosition(QTextCursor::EndOfBlock, QTextCursor::KeepAnchor); // whole logical block
        sel.cursor = c;
        selections.append(sel);
    }
    setExtraSelections(selections);
}

void Editor::resizeEvent(QResizeEvent *e)
{
    QTextEdit::resizeEvent(e);
    updateGutterLayout();
}

// ------------------------------------------------------------- block cursor

int Editor::blockCellWidth() const
{
    return qMax(1, int(std::ceil(QFontMetricsF(font()).horizontalAdvance(QLatin1Char('M')))));
}

void Editor::updateBlinkState()
{
    m_blockPhaseOn = true;
    if (blockCursorBlinks() && hasFocus()) {
        m_blinkTimer.start();
    } else {
        m_blinkTimer.stop();
    }
}

void Editor::focusInEvent(QFocusEvent *e)
{
    QTextEdit::focusInEvent(e);
    updateBlinkState();
    viewport()->update();
}

void Editor::focusOutEvent(QFocusEvent *e)
{
    QTextEdit::focusOutEvent(e);
    m_blinkTimer.stop();
    m_blockPhaseOn = true;
    viewport()->update();
}

void Editor::paintEvent(QPaintEvent *e)
{
    QTextEdit::paintEvent(e); // draws the text into the viewport
    if (m_config.blockCursor) {
        paintBlockCursor();
    }
}

// Runs inside the QTextEdit paint event and paints ONLY onto viewport(), the
// device that owns this paint cycle.
void Editor::paintBlockCursor()
{
    const bool focused = hasFocus();
    if (focused && !m_blockPhaseOn) {
        return;
    }
    QPainter p(viewport());
    const QRect r = cursorRect();
    const QRect cell(r.left(), r.top(), blockCellWidth(), r.height());
    if (!focused) {
        p.setPen(m_config.textColor);
        p.drawRect(cell.adjusted(0, 0, -1, -1)); // hollow block when unfocused
        return;
    }
    if (p.paintEngine() && p.paintEngine()->hasFeature(QPaintEngine::RasterOpModes)) {
        p.setCompositionMode(QPainter::RasterOp_NotDestination); // inverse video, glyph stays legible
        p.fillRect(cell, Qt::white);
    } else {
        QColor translucent = m_config.textColor;
        translucent.setAlpha(170);
        p.fillRect(cell, translucent);
    }
}

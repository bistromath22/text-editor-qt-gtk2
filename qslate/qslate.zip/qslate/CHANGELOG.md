# Changelog

## 1.0.0
Complete rewrite of Slate as QSlate (Qt 6 Widgets, C++17, CMake).

Defects fixed relative to the reference: deliberate plain-text paste (one undo step);
formatting no longer driven by `blockCountChanged`; Enter and paste share one structure and
format policy; proportional line height; single canonical defaults source; shared numeric
validation; single file read and first-file-only policy; `.desktop` Exec is `qslate %F`;
reload updates existing QActions; separate geometry regions; safe painting; border colour
painted by a dedicated frame widget; GTK accelerator parsing; atomic UTF-8/LF save.

### Verification status (honest report)
- Written in an environment (Ubuntu 24.04, no Qt 6, no network for packages).
- **Not compiled. Automated tests not run. No manual GUI checks performed.**
- Expect to fix some compile or test failures on first build; none have been hidden or disabled.
- Known design limitation: a changed paragraph-spacing policy on a document with undo
  history adds one undo entry (see DESIGN.md).
- No project icon is shipped; the launcher uses the theme icon `text-editor`.

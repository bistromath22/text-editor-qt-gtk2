# QSlate

QSlate is a lightweight, native **Qt 6 Widgets** plain-text editor for Ubuntu 26.04 LTS
(C++17, CMake). One window, one document, UTF-8 text, a restrained dark look, and a small
INI configuration file. The executable is `qslate`.

> **Status:** the source tree, tests and docs are complete, but this release was authored in
> an environment without Qt 6, so it has **not been compiled or run yet**. See
> [CHANGELOG.md](CHANGELOG.md) ("Verification status"). Build it and run the tests first.

## Build (Ubuntu 26.04)

    sudo apt update
    sudo apt install build-essential cmake ninja-build pkg-config \
        qt6-base-dev qt6-base-dev-tools

    cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DQSLATE_BUILD_TESTS=ON
    cmake --build build --parallel
    ctest --test-dir build --output-on-failure   # tests use QT_QPA_PLATFORM=offscreen

    ./build/qslate [FILE]
    sudo cmake --install build-release           # after a Release build in build-release/

Use `-DQSLATE_BUILD_TESTS=OFF` for a minimal build. Any Qt 6 release is accepted.

## Command line

    qslate [FILE ...]            only the FIRST file is opened; the rest are reported and ignored
    qslate --config PATH [FILE]  use exactly this config file
    qslate --print-config        print canonical defaults (no GUI needed)
    qslate --print-config-paths  print the search order and the active file
    qslate --help | --version

Exit codes: `0` success, `1` usage error, `2` explicit `--config` file missing/unreadable.

## Configuration

Search order: `--config PATH` (only) → `./config.ini` → `~/.config/qslate/config.ini` →
`/etc/qslate/config.ini` → built-in defaults. The first existing, readable file wins.
Missing keys keep their defaults; an invalid value is reported on stderr and replaced by the
default for that key only. The file is never rewritten. `Reload Config` (default `Ctrl+R`)
re-reads it live.

`config.example.ini` holds the canonical values (identical to `qslate --print-config`).
Numeric ranges: font_size 6..96, border_size 0..100, pixels_above/below 0..200,
line_distance 0..100, line_height 0.5..5.0.

Shortcuts use GTK-style accelerators (`<Primary>n`, `<Primary><Shift>s`, `<Primary>plus`,
`F11`); `<Primary>` is Ctrl. An empty value unbinds an action. `toggle_block_cursor` may be
added optionally (no default). If two actions share a key, the first one in the file keeps it
and the other is disabled with a warning.

Notes: `border_color`/`border_size` style QSlate's own editor surround — **not** the native
title bar or window decorations. If `font_family` (default Monaco) is not installed, the
system monospace font is displayed while the configured value is kept. `line_distance` is
added to the paragraph bottom spacing (see DESIGN.md).

## Behaviour summary

Plain text only (no HTML on copy/paste), LF internally and on save, UTF-8 (one leading BOM
stripped; invalid UTF-8 is refused). Tab inserts a literal tab shown as 4 spaces. Enter and
Shift+Enter insert one paragraph break. Find is case-insensitive and wraps.

## Manual test checklist (NOT performed; tick on a real Ubuntu desktop)

Record session type (Wayland/X11) and Qt platform plugin: ______

- [ ] Normal ≈900×600, maximized, full screen (F11), minimum size 400×300, high-DPI
- [ ] Status bar and line numbers toggled on/off; word wrap on/off; small/large fonts
- [ ] Several line_height / pixels_above / pixels_below combinations; no clipped glyphs (emoji, CJK)
- [ ] Large multiline paste, then scroll to the final line
- [ ] Block cursor on/off, blink on/off; gutter numbers on the same baseline as text
- [ ] border_color `#ff0000`, reload with `#00ff00` (instant), border_size 0 and 20
- [ ] No unexplained bottom gap; no gutter drift, overlap or status-bar collision
- [ ] Launch from a terminal: no `QPainter::begin`/`paintEngine` warnings on start, resize, reload

## Troubleshooting

- *Qt6 not found*: install `qt6-base-dev`; check with `apt-cache policy qt6-base-dev`.
- *Tests fail without a display*: run with `QT_QPA_PLATFORM=offscreen`.
- *Shortcut does nothing*: run `qslate` from a terminal; conflicts and bad accelerators are printed.
- *Font looks different*: Monaco is likely not installed (fallback is intentional).

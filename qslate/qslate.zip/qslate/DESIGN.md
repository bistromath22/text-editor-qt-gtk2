# QSlate design notes

## Document and newline policy
One `QTextDocument` (inside a `QTextEdit`, chosen because it provides block structure,
block formats, undo and `insertFromMimeData` hooks) is the only source of truth. One logical
newline = one block boundary; wrapped rows are not newlines. Input is normalized by
`TextNormalization::normalizeNewlines` (CRLF→LF first, then CR→LF). Export
(`Editor::exportPlainText`) joins `QTextBlock::text()` with `\n`, so file content ↔ blocks is
bijective: `n` LF characters ⇔ `n+1` blocks (empty file = 1 empty block, trailing LF = final
empty block). `toPlainText()` is avoided because it turns NBSP into spaces.
Known limitation: pasted U+2029 splits a block (Qt behaviour); U+2028 is kept as is.

## Clipboard transaction
`insertFromMimeData` accepts only `text/plain` (HTML-only/image data is ignored; the base
class rich path is never called). Steps inside **one** `beginEditBlock/endEditBlock`:
remove selection → `insertText(normalized)` → format affected blocks → end block. Hence one
undo step. Copy/cut use `createMimeDataFromSelection` (text/plain only, LF).

## Paragraph formatting
`line_height` → `QTextBlockFormat::ProportionalHeight` (1.4 → 140). `pixels_above` → top
margin, `pixels_below` → bottom margin, `line_distance` → extra bottom margin (Qt allows one
line-height type per block, so it cannot be an intra-paragraph gap; Qt collapses adjacent
margins, larger wins). Formatting is applied only to the affected block range, inside the
edit transaction — never from `blockCountChanged`. On load it runs with undo disabled. A
*changed* spacing policy on a document that already has undo history adds one undo entry
(Qt records block-format changes); the modified flag is restored. Unchanged reloads and
font/colour/border changes touch no formats.

## Geometry ownership
- `EditorFrame` owns the surround (`border_size`/`border_color`), a layout margin plus its
  own `paintEvent`.
- `Editor` owns the gutter (viewport left margin) and `kContentInset` (document margin, 8 px,
  painted in `background_color`).
- `MainWindow` owns the status bar (never an editor margin).
`border_size` is used for nothing but the surround.

## Gutter
`LineNumberArea` is a child of the editor; it paints only in its own `paintEvent`. Numbers
come from each block's layout (`position().y() + line(0).y() + ascent`) minus the scroll
offset, so each logical block gets one number on the text baseline.

## Paint lifecycle
No painter is ever opened on a widget outside its own paint event. The block cursor is drawn
in `Editor::paintEvent` after the base paint, on `viewport()` (inverse video via
`RasterOp_NotDestination`, translucent fill fallback; hollow when unfocused). Blink uses a
private `QTimer`; the desktop flash time is untouched.

## Config model
Defaults exist once: a table in `ConfigManager.cpp` holding the user's exact `config.ini`,
parsed through the same per-key parsers as user files. `serialize()` drives `--print-config`
and the example-file test. A small own INI reader is used instead of QSettings so values
containing `#`, `<`, `>` or `,` are read verbatim and nothing is ever written. Numeric ranges
live in `Validation::*`, shared by the parser and the `Editor` setters.

## Shortcut conversion
`KeyBindings::parseAccelerator` reads `<Mod>` tags (Primary/Control→Ctrl, Shift, Alt, Meta)
followed by a key name (letters, digits, `plus`, `minus`, F1–F35, …) and builds a
`QKeyCombination`; GTK text never goes through `QKeySequence::fromString`. Config text is
kept verbatim for printing. The editor ignores `ShortcutOverride` for configured sequences so
remapped actions fire.

#include "Editor.h"
#include "LineNumberArea.h"

#include <QScrollBar>
#include <QTextBlock>
#include <QTextLayout>
#include <QTextCursor>
#include <QTextDocument>
#include <QtTest>

class TstEditor : public QObject
{
    Q_OBJECT
private slots:
    void enterInsertsExactlyOneBlockBoundary()
    {
        Editor e;
        e.loadPlainText("abc");
        e.moveCursor(QTextCursor::End);
        QTest::keyClick(&e, Qt::Key_Return);
        QCOMPARE(e.document()->blockCount(), 2);
        QCOMPARE(e.exportPlainText(), QString("abc\n"));
        e.undo();
        QCOMPARE(e.exportPlainText(), QString("abc"));
        e.redo();
        QCOMPARE(e.document()->blockCount(), 2);
    }
    void enterAtStartMiddleAndOnEmpty()
    {
        Editor e;
        e.loadPlainText("abcd");
        e.moveCursor(QTextCursor::Start);
        QTest::keyClick(&e, Qt::Key_Return);
        QCOMPARE(e.exportPlainText(), QString("\nabcd"));
        QTextCursor c = e.textCursor();
        c.setPosition(3);
        e.setTextCursor(c);
        QTest::keyClick(&e, Qt::Key_Enter);
        QCOMPARE(e.exportPlainText(), QString("\nab\ncd"));
    }
    void repeatedEnterCreatesExpectedBlankBlocks()
    {
        Editor e;
        for (int i = 0; i < 5; ++i) {
            QTest::keyClick(&e, Qt::Key_Return);
        }
        QCOMPARE(e.document()->blockCount(), 6);
        QCOMPARE(e.exportPlainText(), QString("\n\n\n\n\n"));
    }
    void enterReplacesSelectionOnce()
    {
        Editor e;
        e.loadPlainText("one two three");
        QTextCursor c = e.textCursor();
        c.setPosition(4);
        c.setPosition(7, QTextCursor::KeepAnchor);
        e.setTextCursor(c);
        QTest::keyClick(&e, Qt::Key_Return);
        QCOMPARE(e.exportPlainText(), QString("one \n three"));
        QCOMPARE(e.document()->blockCount(), 2);
    }
    void shiftEnterIsPlainParagraphBreakNotSoftBreak()
    {
        Editor e;
        e.loadPlainText("ab");
        e.moveCursor(QTextCursor::End);
        QTest::keyClick(&e, Qt::Key_Return, Qt::ShiftModifier);
        QCOMPARE(e.exportPlainText(), QString("ab\n"));
        QVERIFY(!e.exportPlainText().contains(QChar::LineSeparator));
    }
    void wordWrapDoesNotChangeStructure()
    {
        Editor e;
        e.resize(200, 150);
        e.loadPlainText(QString(400, 'x') + "\nsecond");
        const QString before = e.exportPlainText();
        e.setWordWrap(false);
        QCOMPARE(e.document()->blockCount(), 2);
        e.setWordWrap(true);
        e.resize(120, 150);
        QCOMPARE(e.document()->blockCount(), 2);
        QCOMPARE(e.exportPlainText(), before);
    }
    void typedAndLoadedBlocksShareFormatPolicy()
    {
        Editor e;
        e.loadPlainText("a\n\nb");
        QTest::keyClick(&e, Qt::Key_Return);
        QTest::keyClicks(&e, "zz");
        const QTextBlockFormat policy = e.policyBlockFormat();
        QCOMPARE(policy.lineHeight(), 140.0);
        QCOMPARE(int(policy.lineHeightType()), int(QTextBlockFormat::ProportionalHeight));
        for (QTextBlock b = e.document()->begin(); b.isValid(); b = b.next()) {
            QCOMPARE(b.blockFormat().lineHeight(), 140.0);
            QCOMPARE(int(b.blockFormat().lineHeightType()), int(QTextBlockFormat::ProportionalHeight));
        }
    }
    void spacingChangeReformatsAllBlocksWithoutDirtying()
    {
        Editor e;
        e.loadPlainText("a\nb\nc");
        QVERIFY(e.setPixelsAbove(7));
        QVERIFY(e.setLineHeight(2.0));
        QVERIFY(!e.document()->isModified());
        for (QTextBlock b = e.document()->begin(); b.isValid(); b = b.next()) {
            QCOMPARE(b.blockFormat().topMargin(), 7.0);
            QCOMPARE(b.blockFormat().lineHeight(), 200.0);
        }
        QCOMPARE(e.exportPlainText(), QString("a\nb\nc"));
    }
    void settersRejectInvalidValuesLikeConfig()
    {
        Editor e;
        QVERIFY(!e.setFontSize(5));
        QVERIFY(!e.setFontSize(std::nan("")));
        QVERIFY(!e.setLineHeight(0.1));
        QVERIFY(!e.setPixelsBelow(201));
        QVERIFY(!e.setLineDistance(-1));
        QCOMPARE(e.config().fontSize, 18.0);
        QVERIFY(e.setFontSize(6));
        QVERIFY(e.setFontSize(96));
    }
    void appearanceChangesDoNotDirtyOrTouchHistory()
    {
        Editor e;
        e.loadPlainText("hello\nworld");
        QTest::keyClicks(&e, "!");
        e.document()->setModified(false);
        const bool undo = e.document()->isUndoAvailable();
        const int steps = e.document()->availableUndoSteps();
        QTextCursor c = e.textCursor();
        c.setPosition(2);
        c.setPosition(5, QTextCursor::KeepAnchor);
        e.setTextCursor(c);
        e.setFontSize(20);
        e.setWordWrap(false);
        e.setBlockCursor(false);
        e.setShowLineNumbers(true);
        e.setHighlightCurrentLine(false);
        QVERIFY(!e.document()->isModified());
        QCOMPARE(e.document()->isUndoAvailable(), undo);
        QCOMPARE(e.document()->availableUndoSteps(), steps);
        QCOMPARE(e.textCursor().selectionStart(), 2);
        QCOMPARE(e.textCursor().selectionEnd(), 5);
        QCOMPARE(e.exportPlainText(), QString("hello\nworld!"));
    }
    void missingFontFallsBackWithoutRewritingConfig()
    {
        Editor e;
        EditorConfig c = e.config();
        c.fontFamily = "Definitely Not A Real Font 12345";
        e.applyConfig(c);
        QCOMPARE(e.config().fontFamily, c.fontFamily);
        QVERIFY(!e.effectiveFontFamily().isEmpty());
        QVERIFY(e.effectiveFontFamily() != c.fontFamily);
    }
    void gutterNumbersFollowLogicalBlocksNotWrappedRows()
    {
        Editor e;
        e.resize(240, 400);
        e.setShowLineNumbers(true);
        e.show();
        QVERIFY(QTest::qWaitForWindowExposed(&e));
        e.loadPlainText(QString(30, 'w') + "\nshort\nthird");
        QTest::qWait(30);
        QVERIFY(e.document()->firstBlock().layout()->lineCount() > 1); // really wrapped
        QCOMPARE(e.lineNumberArea()->visibleLineNumbers(), (QList<int>{1, 2, 3}));
    }
    void gutterWidthGrowsAtDigitBoundariesAndHides()
    {
        Editor e;
        e.setShowLineNumbers(true);
        auto widthFor = [&](int lines) {
            e.loadPlainText(QString("x\n").repeated(lines - 1) + "x");
            return e.lineNumberAreaWidth();
        };
        const int w9 = widthFor(9), w10 = widthFor(10), w99 = widthFor(99), w100 = widthFor(100);
        QVERIFY(w10 > w9);
        QCOMPARE(w99, w10);
        QVERIFY(w100 > w99);
        e.setShowLineNumbers(false);
        QCOMPARE(e.lineNumberAreaWidth(), 0);
        QVERIFY(!e.lineNumberArea()->isVisible());
        QCOMPARE(e.viewport()->x(), 0);
    }
    void currentLineHighlightFollowsLogicalBlock()
    {
        Editor e;
        e.resize(240, 300);
        e.loadPlainText(QString(300, 'w') + "\nsecond");
        e.goToLine(2);
        QCOMPARE(e.extraSelections().size(), 1);
        QCOMPARE(e.extraSelections().first().cursor.blockNumber(), 1);
        QCOMPARE(e.extraSelections().first().format.background().color(), e.config().currentLineColor);
        e.setHighlightCurrentLine(false);
        QVERIFY(e.extraSelections().isEmpty());
    }
    void blockCursorModesAndSteadyBlink()
    {
        Editor e;
        QVERIFY(e.config().blockCursor);
        QVERIFY(!e.blockCursorBlinks()); // supplied config: steady
        e.loadPlainText("abc");
        e.setBlockCursor(false);
        QCOMPARE(e.cursorWidth(), 1);
        e.setBlockCursor(true);
        QCOMPARE(e.cursorWidth(), 0);
        e.setBlockCursorBlink(true);
        QVERIFY(e.blockCursorBlinks());
        QCOMPARE(e.exportPlainText(), QString("abc"));
    }
    void goToLineAndFind()
    {
        Editor e;
        e.loadPlainText("alpha\nbeta\ngamma\nbeta");
        QVERIFY(e.goToLine(3));
        QCOMPARE(e.currentLine(), 3);
        QCOMPARE(e.currentColumn(), 1);
        QVERIFY(!e.goToLine(0));
        QVERIFY(!e.goToLine(5));
        e.moveCursor(QTextCursor::Start);
        QCOMPARE(int(e.findText("BETA")), int(Editor::FindResult::Found));
        QCOMPARE(e.currentLine(), 2);
        QCOMPARE(int(e.findText("beta")), int(Editor::FindResult::Found));
        QCOMPARE(e.currentLine(), 4);
        QCOMPARE(int(e.findText("beta")), int(Editor::FindResult::FoundWrapped));
        QCOMPARE(e.currentLine(), 2);
        const int pos = e.textCursor().position();
        QCOMPARE(int(e.findText("zzz")), int(Editor::FindResult::NotFound));
        QCOMPARE(e.textCursor().position(), pos);
    }
    void loadEstablishesCleanBaseline()
    {
        Editor e;
        QTest::keyClicks(&e, "abc");
        e.loadPlainText("fresh\r\ntext");
        QVERIFY(!e.document()->isModified());
        QVERIFY(!e.document()->isUndoAvailable());
        QCOMPARE(e.exportPlainText(), QString("fresh\ntext"));
    }
    void exportPreservesBlankLinesAndNbsp()
    {
        Editor e;
        const QString text = QString::fromUtf8("\n\na\xC2\xA0" "b\n\n\n");
        e.loadPlainText(text);
        QCOMPARE(e.exportPlainText(), text); // NBSP and every blank block survive
        QCOMPARE(e.document()->blockCount(), 6);
    }
};

QTEST_MAIN(TstEditor)
#include "tst_editor.moc"

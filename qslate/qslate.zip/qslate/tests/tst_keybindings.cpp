#include "ConfigManager.h"
#include "KeyBindings.h"

#include <QAction>
#include <QtTest>

static QKeySequence seq(Qt::KeyboardModifiers m, Qt::Key k) { return QKeySequence(QKeyCombination(m, k)); }

class TstKeyBindings : public QObject
{
    Q_OBJECT
private slots:
    void parses_data()
    {
        QTest::addColumn<QString>("text");
        QTest::addColumn<QKeySequence>("expected");
        QTest::newRow("primary n") << "<Primary>n" << seq(Qt::ControlModifier, Qt::Key_N);
        QTest::newRow("upper letter") << "<Primary>N" << seq(Qt::ControlModifier, Qt::Key_N);
        QTest::newRow("primary shift s") << "<Primary><Shift>s"
                                         << seq(Qt::ControlModifier | Qt::ShiftModifier, Qt::Key_S);
        QTest::newRow("plus") << "<Primary>plus" << seq(Qt::ControlModifier, Qt::Key_Plus);
        QTest::newRow("minus") << "<Primary>minus" << seq(Qt::ControlModifier, Qt::Key_Minus);
        QTest::newRow("F3") << "F3" << seq({}, Qt::Key_F3);
        QTest::newRow("F11") << "F11" << seq({}, Qt::Key_F11);
        QTest::newRow("case-insensitive tags") << "<primary><SHIFT>b"
                                               << seq(Qt::ControlModifier | Qt::ShiftModifier, Qt::Key_B);
    }
    void parses()
    {
        QFETCH(QString, text);
        QFETCH(QKeySequence, expected);
        QKeySequence got;
        QString err;
        QVERIFY2(KeyBindings::parseAccelerator(text, &got, &err), qPrintable(err));
        QCOMPARE(got, expected);
    }
    void rejectsInvalid_data()
    {
        QTest::addColumn<QString>("text");
        QTest::newRow("empty") << "";
        QTest::newRow("unknown modifier") << "<Hyper>n";
        QTest::newRow("unterminated") << "<Primary n";
        QTest::newRow("unknown key") << "<Primary>bogus";
        QTest::newRow("no key") << "<Primary>";
        QTest::newRow("f99") << "F99";
    }
    void rejectsInvalid()
    {
        QFETCH(QString, text);
        QString err;
        QVERIFY(!KeyBindings::parseAccelerator(text, nullptr, &err));
        QVERIFY(!err.isEmpty());
    }
    void defaultsAllParseAndDoNotConflict()
    {
        const ResolvedShortcuts r = KeyBindings::resolve(ConfigManager::defaults().shortcuts);
        QVERIFY2(r.warnings.isEmpty(), qPrintable(r.warnings.join("; ")));
        QCOMPARE(r.sequences.size(), 21);
        QVERIFY(!r.sequences.contains("toggle_block_cursor")); // no invented shortcut
    }
    void conflictFirstEntryWinsDeterministically()
    {
        ShortcutConfig c;
        c.set("save", "<Primary>s");
        c.set("find", "<Primary>S"); // same sequence
        c.set("open", "<Primary>bogus");
        for (int i = 0; i < 3; ++i) {
            const ResolvedShortcuts r = KeyBindings::resolve(c);
            QVERIFY(r.sequences.contains("save"));
            QVERIFY(!r.sequences.contains("find"));
            QVERIFY(!r.sequences.contains("open"));
            QCOMPARE(r.warnings.size(), 2);
        }
    }
    void applyUpdatesExistingActionsAndClearsMissing()
    {
        QAction a, b;
        QHash<QString, QAction *> actions{{"save", &a}, {"toggle_block_cursor", &b}};
        b.setShortcut(seq(Qt::ControlModifier, Qt::Key_J));
        ShortcutConfig c;
        c.set("save", "<Primary>k");
        KeyBindings::apply(actions, KeyBindings::resolve(c));
        QCOMPARE(a.shortcut(), seq(Qt::ControlModifier, Qt::Key_K));
        QVERIFY(b.shortcut().isEmpty());
    }
};

QTEST_MAIN(TstKeyBindings)
#include "tst_keybindings.moc"

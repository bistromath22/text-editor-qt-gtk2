#include "ConfigManager.h"

#include <QProcess>
#include <QtTest>

struct Run {
    int code = -1;
    QString out, err;
};

static Run run(const QStringList &args, const QString &cwd = QString())
{
    QProcess p;
    if (!cwd.isEmpty()) p.setWorkingDirectory(cwd);
    p.start(QSLATE_BINARY, args);
    Run r;
    if (!p.waitForFinished(20000)) {
        p.kill();
        return r;
    }
    r.code = p.exitCode();
    r.out = QString::fromUtf8(p.readAllStandardOutput());
    r.err = QString::fromUtf8(p.readAllStandardError());
    return r;
}

class TstCli : public QObject
{
    Q_OBJECT
    QTemporaryDir dir;
private slots:
    void initTestCase() { QVERIFY(dir.isValid()); }

    void versionNamesQslate()
    {
        const Run r = run({"--version"});
        QCOMPARE(r.code, 0);
        QVERIFY(r.out.contains("qslate"));
        QVERIFY(r.out.contains(QSLATE_VERSION));
    }
    void helpDocumentsInterface()
    {
        const Run r = run({"--help"});
        QCOMPARE(r.code, 0);
        QVERIFY(r.out.contains("qslate"));
        QVERIFY(r.out.contains("--config"));
        QVERIFY(r.out.contains("--print-config-paths"));
        QVERIFY(r.out.contains("QSlate"));
    }
    void printConfigIsCanonicalDefaults()
    {
        const Run r = run({"--print-config"});
        QCOMPARE(r.code, 0);
        QCOMPARE(r.out, ConfigManager::serialize(ConfigManager::defaults()));
        QVERIFY(r.out.contains("<Primary><Shift>s"));
        QVERIFY(r.out.contains("font_family=Monaco"));
    }
    void printConfigPathsReportsDefaultsWhenNothingFound()
    {
        const Run r = run({"--print-config-paths"}, dir.path());
        QCOMPARE(r.code, 0);
        QVERIFY(r.out.contains("config.ini"));
        QVERIFY(r.out.contains("missing"));
        QVERIFY(r.out.contains("Active configuration"));
        QVERIFY(!r.out.contains(dir.path() + "/config.ini  (found)"));
    }
    void printConfigPathsMarksSelectedExplicitFile()
    {
        const QString p = dir.filePath("mine.ini");
        QFile f(p);
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.close();
        const Run r = run({"--print-config-paths", "--config", p});
        QCOMPARE(r.code, 0);
        QVERIFY(r.out.contains("<- selected"));
        QVERIFY(r.out.contains("Active configuration: " + p));
    }
    void unreadableExplicitConfigExitsNonZero()
    {
        const Run r = run({"--print-config-paths", "--config", dir.filePath("nope.ini")});
        QCOMPARE(r.code, 2);
        QVERIFY(r.err.contains("does not exist"));
        QVERIFY(!r.out.contains("<- selected"));
    }
    void unknownOptionIsUsageError()
    {
        const Run r = run({"--help-me-please-not-real", "--version"}, dir.path());
        QVERIFY(r.code != 0);
    }
};

QTEST_APPLESS_MAIN(TstCli)
#include "tst_cli.moc"

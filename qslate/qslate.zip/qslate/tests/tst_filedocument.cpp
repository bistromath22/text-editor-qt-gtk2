#include "FileDocument.h"

#include <QtTest>

class TstFileDocument : public QObject
{
    Q_OBJECT
    QTemporaryDir dir;
    QString p(const QString &n) const { return dir.filePath(n); }
    static QByteArray readAll(const QString &path)
    {
        QFile f(path);
        return f.open(QIODevice::ReadOnly) ? f.readAll() : QByteArray();
    }
private slots:
    void initTestCase() { QVERIFY(dir.isValid()); }

    void roundTrip_data()
    {
        QTest::addColumn<QString>("text");
        QTest::newRow("empty") << "";
        QTest::newRow("plain") << "hello";
        QTest::newRow("blank lines") << "a\n\n\n\nb";
        QTest::newRow("leading") << "\n\nx";
        QTest::newRow("trailing") << "x\n";
        QTest::newRow("unicode") << QString::fromUtf8("é 日本語 \U0001F600 é");
    }
    void roundTrip()
    {
        QFETCH(QString, text);
        QVERIFY(FileDocument::save(p("rt.txt"), text).ok);
        const LoadResult r = FileDocument::load(p("rt.txt"));
        QVERIFY(r.ok);
        QCOMPARE(r.text, text);
        QCOMPARE(readAll(p("rt.txt")), text.toUtf8()); // UTF-8, LF, no BOM
    }
    void lineEndingsNormalizedOnLoad()
    {
        QCOMPARE(FileDocument::decode("a\r\nb\rc\nd").text, QString("a\nb\nc\nd"));
    }
    void saveAlwaysWritesLf()
    {
        QVERIFY(FileDocument::save(p("lf.txt"), "a\r\nb\rc").ok);
        QCOMPARE(readAll(p("lf.txt")), QByteArray("a\nb\nc"));
    }
    void bomStripped()
    {
        const LoadResult r = FileDocument::decode(QByteArray("\xEF\xBB\xBF" "abc"));
        QVERIFY(r.ok);
        QVERIFY(r.hadBom);
        QCOMPARE(r.text, QString("abc"));
    }
    void invalidUtf8Rejected()
    {
        const LoadResult r = FileDocument::decode(QByteArray("ab\xFF\xFEcd"));
        QVERIFY(!r.ok);
        QVERIFY(!r.error.isEmpty());
    }
    void emptyFileIsValid()
    {
        QFile f(p("empty.txt"));
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.close();
        const LoadResult r = FileDocument::load(p("empty.txt"));
        QVERIFY(r.ok);
        QVERIFY(r.text.isEmpty());
    }
    void missingFileReportsError()
    {
        const LoadResult r = FileDocument::load(p("nope.txt"));
        QVERIFY(!r.ok);
        QVERIFY(r.error.contains("nope.txt"));
    }
    void saveFailureKeepsOldFile()
    {
        QVERIFY(FileDocument::save(p("keep.txt"), "original").ok);
        const SaveResult bad = FileDocument::save(p("no_such_dir/x.txt"), "new");
        QVERIFY(!bad.ok);
        QVERIFY(!bad.error.isEmpty());
        QCOMPARE(readAll(p("keep.txt")), QByteArray("original"));
    }
};

QTEST_APPLESS_MAIN(TstFileDocument)
#include "tst_filedocument.moc"

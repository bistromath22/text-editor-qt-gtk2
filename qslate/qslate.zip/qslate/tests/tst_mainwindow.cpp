#include "ConfigManager.h"
#include "Editor.h"
#include "EditorFrame.h"
#include "MainWindow.h"

#include <QAction>
#include <QStatusBar>
#include <QTextCursor>
#include <QTextDocument>
#include <QMessageBox>
#include <QFileInfo>
#include <QtTest>

class TstMainWindow : public QObject
{
    Q_OBJECT
    QTemporaryDir dir;
    QString file(const QString &name, const QByteArray &content = QByteArray())
    {
        const QString p = dir.filePath(name);
        QFile f(p);
        f.open(QIODevice::WriteOnly);
        f.write(content);
        return p;
    }
    struct Rig {
        QMessageBox::StandardButton answer = QMessageBox::Cancel;
        QString openPath, savePath;
        QString lastError, lastInfo, textAnswer;
        bool textOk = true;
        int askCount = 0;
        void install(MainWindow &w)
        {
            w.hooks().askSave = [this](const QString &) { ++askCount; return answer; };
            w.hooks().openFileName = [this] { return openPath; };
            w.hooks().saveFileName = [this](const QString &) { return savePath; };
            w.hooks().getText = [this](const QString &, const QString &, const QString &, bool *ok) {
                *ok = textOk;
                return textAnswer;
            };
            w.hooks().showError = [this](const QString &, const QString &m) { lastError = m; };
            w.hooks().showInfo = [this](const QString &, const QString &m) { lastInfo = m; };
        }
    };
private slots:
    void initTestCase() { QVERIFY(dir.isValid()); }

    void titleTracksUntitledNamedAndModified()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        QCOMPARE(w.windowTitle(), QString::fromUtf8("QSlate — Untitled"));
        QTest::keyClicks(w.editor(), "x");
        QVERIFY(w.windowTitle().endsWith("[modified]"));
        Rig r;
        r.install(w);
        r.savePath = dir.filePath("t.txt");
        QVERIFY(w.saveDocumentAs());
        QCOMPARE(w.windowTitle(), QString::fromUtf8("QSlate — t.txt"));
    }
    void cancelPreservesDocument()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        QTest::keyClicks(w.editor(), "keep me");
        r.answer = QMessageBox::Cancel;
        QVERIFY(!w.newDocument());
        QCOMPARE(w.editor()->exportPlainText(), QString("keep me"));
        r.openPath = file("o.txt", "other");
        QVERIFY(!w.openDocument());
        QCOMPARE(w.editor()->exportPlainText(), QString("keep me"));
        QVERIFY(w.editor()->document()->isModified());
        QCOMPARE(r.askCount, 2);
    }
    void discardAndSavePaths()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        QTest::keyClicks(w.editor(), "dirty");
        r.answer = QMessageBox::Discard;
        QVERIFY(w.newDocument());
        QCOMPARE(w.editor()->exportPlainText(), QString());
        QTest::keyClicks(w.editor(), "saved text");
        r.answer = QMessageBox::Save;
        r.savePath = dir.filePath("saved.txt");
        QVERIFY(w.newDocument()); // saves first
        QFile f(r.savePath);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("saved text"));
    }
    void saveFailureKeepsStateAndPath()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        const QString good = file("g.txt", "old");
        QVERIFY(w.openPath(good));
        QTest::keyClicks(w.editor(), "new");
        r.savePath = dir.filePath("missing_dir/x.txt");
        QVERIFY(!w.saveDocumentAs());
        QVERIFY(!r.lastError.isEmpty());
        QCOMPARE(w.currentPath(), QFileInfo(good).absoluteFilePath());
        QVERIFY(w.editor()->document()->isModified());
    }
    void failedOpenLeavesDocumentAlone()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        QTest::keyClicks(w.editor(), "abc");
        QVERIFY(!w.openPath(dir.filePath("nonexistent.txt")));
        QVERIFY(!r.lastError.isEmpty());
        QVERIFY(!w.openPath(file("bad.txt", QByteArray("a\xFF\xFE"))));
        QCOMPARE(w.editor()->exportPlainText(), QString("abc"));
    }
    void openLoadsCleanAndSaveRoundTrips()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        QVERIFY(w.openPath(file("rt.txt", "\xEF\xBB\xBF" "a\r\n\r\nb\n")));
        QCOMPARE(w.editor()->exportPlainText(), QString("a\n\nb\n"));
        QVERIFY(!w.editor()->document()->isModified());
        QTest::keyClicks(w.editor(), "!");
        QVERIFY(w.saveDocument());
        QVERIFY(!w.editor()->document()->isModified());
        QFile f(w.currentPath());
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("!a\n\nb\n"));
    }
    void multipleFileArgumentsOpenOnlyFirst()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        const QString notice = w.openInitialFiles({file("1.txt", "first"), file("2.txt", "second"), file("3.txt", "third")});
        QCOMPARE(w.editor()->exportPlainText(), QString("first"));
        QVERIFY(notice.contains("2 additional"));
        QVERIFY(notice.contains("2.txt") && notice.contains("3.txt"));
        QVERIFY(w.openInitialFiles({file("4.txt", "only")}).isEmpty());
    }
    void findFindNextAndWrap()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        w.editor()->loadPlainText("foo\nbar\nfoo");
        r.textAnswer = "foo";
        w.showFindDialog();
        QCOMPARE(w.editor()->currentLine(), 1);
        w.findNext();
        QCOMPARE(w.editor()->currentLine(), 3);
        w.findNext(); // wraps
        QCOMPARE(w.editor()->currentLine(), 1);
        r.textAnswer = "absent";
        w.showFindDialog();
        QVERIFY(r.lastInfo.contains("absent"));
        QCOMPARE(w.editor()->currentLine(), 1); // did not jump
    }
    void goToLineValidAndInvalid_data()
    {
        QTest::addColumn<QString>("input");
        QTest::addColumn<bool>("valid");
        QTest::addColumn<int>("line");
        QTest::newRow("valid") << "3" << true << 3;
        QTest::newRow("first") << " 1 " << true << 1;
        QTest::newRow("last") << "4" << true << 4;
        QTest::newRow("zero") << "0" << false << 1;
        QTest::newRow("too big") << "5" << false << 1;
        QTest::newRow("empty") << "" << false << 1;
        QTest::newRow("malformed") << "1x" << false << 1;
        QTest::newRow("negative") << "-2" << false << 1;
        QTest::newRow("float") << "2.5" << false << 1;
    }
    void goToLineValidAndInvalid()
    {
        QFETCH(QString, input);
        QFETCH(bool, valid);
        QFETCH(int, line);
        MainWindow w(ConfigManager::defaults(), {}, {});
        Rig r;
        r.install(w);
        w.editor()->loadPlainText("a\nb\nc\nd");
        r.textAnswer = input;
        w.showGoToLineDialog();
        QCOMPARE(w.editor()->currentLine(), line);
        QCOMPARE(r.lastError.isEmpty(), valid);
        QCOMPARE(w.editor()->currentColumn(), 1);
    }
    void statusBarTextAndVisibilityFollowConfig()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        w.show();
        QVERIFY(QTest::qWaitForWindowExposed(&w));
        QVERIFY(!w.statusBar()->isVisible()); // supplied config: hidden
        QVERIFY(!w.action("toggle_statusbar")->isChecked());
        w.action("toggle_statusbar")->trigger();
        QVERIFY(w.statusBar()->isVisible());
        w.editor()->loadPlainText("abc\ndef");
        w.editor()->goToLine(2);
        QTest::keyClick(w.editor(), Qt::Key_Right);
        QCOMPARE(w.statusText(), QString("Ln 2, Col 2"));
        QTest::keyClick(w.editor(), Qt::Key_Return);
        QCOMPARE(w.statusText(), QString("Ln 3, Col 1"));
        w.editor()->undo();
        QCOMPARE(w.statusText(), QString("Ln 2, Col 2"));
        // the editor never overlaps the status bar
        QVERIFY(w.frame()->geometry().bottom() < w.statusBar()->geometry().top());
    }
    void initialStateMatchesSuppliedConfig()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        QCOMPARE(w.size(), QSize(900, 600));
        QCOMPARE(w.minimumSize(), QSize(400, 300));
        QVERIFY(w.action("toggle_wordwrap")->isChecked());
        QVERIFY(w.action("toggle_block_cursor")->isChecked());
        QVERIFY(w.action("toggle_current_line")->isChecked());
        QVERIFY(!w.action("toggle_line_numbers")->isChecked());
        QCOMPARE(w.frame()->borderSize(), 20);
        QCOMPARE(w.action("save_as")->shortcut(),
                 QKeySequence(QKeyCombination(Qt::ControlModifier | Qt::ShiftModifier, Qt::Key_S)));
        QCOMPARE(w.action("increase_font")->shortcut(),
                 QKeySequence(QKeyCombination(Qt::ControlModifier, Qt::Key_Plus)));
        QVERIFY(w.action("toggle_block_cursor")->shortcut().isEmpty());
        QVERIFY(!w.action("undo")->isEnabled());
        QVERIFY(!w.action("copy")->isEnabled());
    }
    void fontActionsChangeRenderingOnly()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        w.editor()->loadPlainText("abc");
        w.action("increase_font")->trigger();
        QCOMPARE(w.editor()->config().fontSize, 19.0);
        w.action("decrease_font")->trigger();
        w.action("decrease_font")->trigger();
        QCOMPARE(w.editor()->config().fontSize, 17.0);
        for (int i = 0; i < 30; ++i) w.action("decrease_font")->trigger();
        QCOMPARE(w.editor()->config().fontSize, 6.0); // floor
        QVERIFY(!w.editor()->document()->isModified());
    }
    void menuTogglesStayInSync()
    {
        MainWindow w(ConfigManager::defaults(), {}, {});
        w.action("toggle_line_numbers")->trigger();
        QVERIFY(w.editor()->config().showLineNumbers);
        w.action("toggle_wordwrap")->trigger();
        QVERIFY(!w.editor()->config().wordWrap);
        w.editor()->setShowLineNumbers(false); // changed behind the menu's back
        QVERIFY(!w.action("toggle_line_numbers")->isChecked());
    }
    void reloadUpdatesActionsAppearanceAndKeepsDocument()
    {
        const QString cfgPath = file("reload.ini", "[editor]\nborder_color=#ff0000\n");
        MainWindow w(ConfigManager::defaults(), cfgPath, cfgPath);
        Rig r;
        r.install(w);
        w.editor()->loadPlainText("hello\nworld");
        QTest::keyClicks(w.editor(), "Z");
        QTextCursor c = w.editor()->textCursor();
        c.setPosition(1);
        c.setPosition(3, QTextCursor::KeepAnchor);
        w.editor()->setTextCursor(c);
        const bool modified = w.editor()->document()->isModified();
        const int steps = w.editor()->document()->availableUndoSteps();
        const QString path = w.currentPath();

        file("reload.ini", "[editor]\nborder_color=#00ff00\nborder_size=0\nshow_line_numbers=true\n"
                           "show_statusbar=true\n[shortcuts]\nsave=<Primary>k\ntoggle_block_cursor=<Primary>b\n");
        w.reloadConfig();
        QVERIFY2(r.lastError.isEmpty(), qPrintable(r.lastError));
        QCOMPARE(w.frame()->borderColor(), QColor("#00ff00"));
        QCOMPARE(w.frame()->borderSize(), 0);
        QVERIFY(w.editor()->config().showLineNumbers);
        QVERIFY(w.action("toggle_line_numbers")->isChecked());
        QVERIFY(w.statusBarShown());
        QVERIFY(w.action("toggle_statusbar")->isChecked());
        QCOMPARE(w.action("save")->shortcut(), QKeySequence(QKeyCombination(Qt::ControlModifier, Qt::Key_K)));
        QCOMPARE(w.action("toggle_block_cursor")->shortcut(),
                 QKeySequence(QKeyCombination(Qt::ControlModifier, Qt::Key_B)));
        // the QAction object itself was updated, not replaced; and the document is untouched
        QCOMPARE(w.editor()->document()->isModified(), modified);
        QCOMPARE(w.editor()->document()->availableUndoSteps(), steps);
        QCOMPARE(w.editor()->textCursor().selectionStart(), 1);
        QCOMPARE(w.editor()->textCursor().selectionEnd(), 3);
        QCOMPARE(w.editor()->exportPlainText(), QString("Zhello\nworld"));
        QCOMPARE(w.currentPath(), path);
    }
    void reloadWithUnreadableExplicitConfigKeepsCurrentSettings()
    {
        MainWindow w(ConfigManager::defaults(), dir.filePath("gone.ini"), {});
        Rig r;
        r.install(w);
        w.reloadConfig();
        QVERIFY(!r.lastError.isEmpty());
        QCOMPARE(w.frame()->borderSize(), 20);
    }
    void conflictingShortcutsDisableLaterBinding()
    {
        AppConfig c = ConfigManager::defaults();
        c.shortcuts.set("find", "<Primary>s"); // clashes with save (listed earlier)
        MainWindow w(c, {}, {});
        QCOMPARE(w.action("save")->shortcut(), QKeySequence(QKeyCombination(Qt::ControlModifier, Qt::Key_S)));
        QVERIFY(w.action("find")->shortcut().isEmpty());
    }
};

QTEST_MAIN(TstMainWindow)
#include "tst_mainwindow.moc"

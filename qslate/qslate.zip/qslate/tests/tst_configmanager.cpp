#include "ConfigManager.h"

#include <QFile>
#include <QTemporaryDir>
#include <QtTest>

static const char *kUserConfig =
    "[editor]\nwordwrap=true\nborder_size=20\nborder_color=#313244\nbackground_color=#1e1e2e\n"
    "gutter_background_color=#313244\ncurrent_line_color=#313244\nline_number_color=#6c7086\n"
    "text_color=#cdd6f4\nblock_cursor=true\nblock_cursor_blink=false\nfont_family=Monaco\n"
    "font_size=18\nline_height=1.4\npixels_above=0\npixels_below=0\nline_distance=0\n"
    "show_line_numbers=false\nhighlight_current_line=true\nshow_statusbar=false\n\n"
    "[shortcuts]\nnew_file=<Primary>n\nopen=<Primary>o\nsave=<Primary>s\n"
    "save_as=<Primary><Shift>s\nquit=<Primary>q\nundo=<Primary>z\nredo=<Primary>y\n"
    "cut=<Primary>x\ncopy=<Primary>c\npaste=<Primary>v\nfind=<Primary>f\nfind_next=F3\n"
    "goto_line=<Primary>g\nreload_config=<Primary>r\ntoggle_wordwrap=<Primary>w\n"
    "increase_font=<Primary>plus\ndecrease_font=<Primary>minus\nfullscreen=F11\n"
    "toggle_line_numbers=<Primary>l\ntoggle_current_line=<Primary>h\n"
    "toggle_statusbar=<Primary><Shift>b\n";

class TstConfigManager : public QObject
{
    Q_OBJECT
    QTemporaryDir dir;
    QString write(const QString &name, const QString &content)
    {
        const QString path = dir.filePath(name);
        QFile f(path);
        f.open(QIODevice::WriteOnly);
        f.write(content.toUtf8());
        return path;
    }
private slots:
    void initTestCase() { QVERIFY(dir.isValid()); }

    void defaultsMatchSuppliedConfigExactly()
    {
        QCOMPARE(ConfigManager::serialize(ConfigManager::defaults()), QString(kUserConfig));
        const EditorConfig e = ConfigManager::defaults().editor;
        QVERIFY(e.wordWrap);
        QCOMPARE(e.borderSize, 20);
        QVERIFY(e.blockCursor);
        QVERIFY(!e.blockCursorBlink);
        QCOMPARE(e.fontFamily, QString("Monaco"));
        QCOMPARE(e.fontSize, 18.0);
        QCOMPARE(e.lineHeight, 1.4);
        QVERIFY(!e.showLineNumbers);
        QVERIFY(e.highlightCurrentLine);
        QVERIFY(!e.showStatusbar);
        QCOMPARE(e.gutterBackgroundColor, QColor("#313244"));
    }
    void exampleFileMatchesCanonicalDefaults()
    {
        QFile f(QString(QSLATE_SOURCE_DIR) + "/config.example.ini");
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(QString::fromUtf8(f.readAll()).trimmed(),
                 ConfigManager::serialize(ConfigManager::defaults()).trimmed());
    }
    void loadingSuppliedFileEqualsDefaults()
    {
        bool ok = false;
        QStringList diag;
        const AppConfig c = ConfigManager::load(write("full.ini", kUserConfig), &diag, &ok);
        QVERIFY(ok);
        QVERIFY2(diag.isEmpty(), qPrintable(diag.join("; ")));
        QCOMPARE(ConfigManager::serialize(c), QString(kUserConfig));
    }
    void partialOverridesOnlyPresentKeys()
    {
        bool ok = false;
        const AppConfig c = ConfigManager::load(
            write("part.ini", "[editor]\nborder_color=#ff0000\nfont_size=12\n"), nullptr, &ok);
        const AppConfig d = ConfigManager::defaults();
        QVERIFY(ok);
        QCOMPARE(c.editor.borderColor, QColor("#ff0000"));
        QCOMPARE(c.editor.fontSize, 12.0);
        QCOMPARE(c.editor.borderSize, d.editor.borderSize);
        QCOMPARE(c.editor.textColor, d.editor.textColor);
        QCOMPARE(c.shortcuts.entries, d.shortcuts.entries);
    }
    void invalidValuesFallBackIndividually_data()
    {
        QTest::addColumn<QString>("line");
        QTest::newRow("bad color") << "border_color=notacolor";
        QTest::newRow("nan") << "font_size=nan";
        QTest::newRow("inf") << "line_height=inf";
        QTest::newRow("font too small") << "font_size=5";
        QTest::newRow("font too large") << "font_size=97";
        QTest::newRow("border negative") << "border_size=-1";
        QTest::newRow("border too large") << "border_size=101";
        QTest::newRow("spacing too large") << "pixels_above=201";
        QTest::newRow("distance too large") << "line_distance=101";
        QTest::newRow("line height low") << "line_height=0.4";
        QTest::newRow("line height high") << "line_height=5.1";
        QTest::newRow("bad bool") << "wordwrap=maybe";
        QTest::newRow("empty family") << "font_family=";
    }
    void invalidValuesFallBackIndividually()
    {
        QFETCH(QString, line);
        QStringList diag;
        bool ok = false;
        const AppConfig c = ConfigManager::load(
            write("bad.ini", "[editor]\n" + line + "\ntext_color=#010203\n"), &diag, &ok);
        QVERIFY(ok);
        QCOMPARE(diag.size(), 1);
        const AppConfig d = ConfigManager::defaults();
        QCOMPARE(ConfigManager::serialize(AppConfig{[&] { auto e = c.editor; e.textColor = d.editor.textColor; return e; }(), c.shortcuts}),
                 ConfigManager::serialize(d));      // only the bad key was rejected
        QCOMPARE(c.editor.textColor, QColor("#010203")); // later keys still applied
    }
    void invalidShortcutKeepsDefaultAndReports()
    {
        QStringList diag;
        bool ok = false;
        const AppConfig c = ConfigManager::load(
            write("sc.ini", "[shortcuts]\nsave=<Primary>bogus\nopen=<Primary>k\nnonsense=F1\n"), &diag, &ok);
        QCOMPARE(diag.size(), 2);
        QCOMPARE(c.shortcuts.value("save"), QString("<Primary>s"));
        QCOMPARE(c.shortcuts.value("open"), QString("<Primary>k"));
    }
    void optionalBlockCursorShortcutAccepted()
    {
        bool ok = false;
        const AppConfig c = ConfigManager::load(
            write("bc.ini", "[shortcuts]\ntoggle_block_cursor=<Primary>b\n"), nullptr, &ok);
        QCOMPARE(c.shortcuts.value("toggle_block_cursor"), QString("<Primary>b"));
    }
    void loadDoesNotModifyFile()
    {
        const QString path = write("ro.ini", "[editor]\nborder_size=5\n");
        const QByteArray before = QFile(path).readAll();
        ConfigManager::load(path, nullptr, nullptr);
        QFile f(path);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("[editor]\nborder_size=5\n"));
        Q_UNUSED(before)
    }
    void discoveryExplicitWinsAndMissingIsError()
    {
        const QString good = write("exp.ini", "[editor]\n");
        ConfigSelection s = ConfigManager::discover(good, {write("other.ini", "")});
        QVERIFY(s.ok);
        QCOMPARE(s.candidates.size(), 1);
        QCOMPARE(s.selectedPath, good);
        s = ConfigManager::discover(dir.filePath("absent.ini"));
        QVERIFY(!s.ok);
        QVERIFY(s.selectedPath.isEmpty());
        QVERIFY(!s.candidates.first().selected);
    }
    void discoveryPicksFirstReadableAndNeverLabelsMissingActive()
    {
        const QString a = dir.filePath("missing_a.ini");
        const QString b = write("found_b.ini", "");
        const QString c = write("found_c.ini", "");
        const ConfigSelection s = ConfigManager::discover({}, {a, b, c});
        QCOMPARE(s.selectedPath, b);
        QVERIFY(!s.candidates[0].exists && !s.candidates[0].selected);
        QVERIFY(s.candidates[1].selected);
        QVERIFY(!s.candidates[2].selected);
        QVERIFY(ConfigManager::describeSelection(s).contains("missing"));
    }
    void discoveryFallsBackToBuiltInDefaults()
    {
        const ConfigSelection s = ConfigManager::discover({}, {dir.filePath("none1.ini")});
        QVERIFY(s.ok);
        QVERIFY(s.selectedPath.isEmpty());
        QVERIFY(ConfigManager::describeSelection(s).contains("built-in defaults"));
    }
    void validationRangesAreInclusive()
    {
        QVERIFY(Validation::fontSize(6) && Validation::fontSize(96));
        QVERIFY(!Validation::fontSize(5.99) && !Validation::fontSize(96.01));
        QVERIFY(!Validation::fontSize(std::nan("")));
        QVERIFY(Validation::borderSize(0) && Validation::borderSize(100) && !Validation::borderSize(101));
        QVERIFY(Validation::lineHeight(0.5) && Validation::lineHeight(5.0));
        QVERIFY(!Validation::lineHeight(std::numeric_limits<double>::infinity()));
        QVERIFY(Validation::paragraphSpacing(200) && !Validation::paragraphSpacing(201));
        QVERIFY(Validation::lineDistance(100) && !Validation::lineDistance(101));
    }
};

QTEST_MAIN(TstConfigManager)
#include "tst_configmanager.moc"

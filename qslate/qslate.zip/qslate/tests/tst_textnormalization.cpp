#include "TextNormalization.h"

#include <QtTest>

class TstTextNormalization : public QObject
{
    Q_OBJECT
private slots:
    void cases_data()
    {
        QTest::addColumn<QString>("input");
        QTest::addColumn<QString>("expected");
        QTest::newRow("lf unchanged") << "a\nb\n" << "a\nb\n";
        QTest::newRow("crlf is one lf") << "a\r\nb" << "a\nb";
        QTest::newRow("cr becomes lf") << "a\rb" << "a\nb";
        QTest::newRow("mixed") << "a\r\nb\rc\nd" << "a\nb\nc\nd";
        QTest::newRow("leading newline") << "\r\nx" << "\nx";
        QTest::newRow("trailing newline") << "x\r\n" << "x\n";
        QTest::newRow("repeated blanks") << "a\r\n\r\n\r\nb" << "a\n\n\nb";
        QTest::newRow("cr cr is two") << "a\r\rb" << "a\n\nb";
        QTest::newRow("empty") << "" << "";
        QTest::newRow("unicode") << QString::fromUtf8("é\r\n日本語\r\U0001F600") << QString::fromUtf8("é\n日本語\n\U0001F600");
    }
    void cases()
    {
        QFETCH(QString, input);
        QFETCH(QString, expected);
        QCOMPARE(TextNormalization::normalizeNewlines(input), expected);
    }
};

QTEST_APPLESS_MAIN(TstTextNormalization)
#include "tst_textnormalization.moc"

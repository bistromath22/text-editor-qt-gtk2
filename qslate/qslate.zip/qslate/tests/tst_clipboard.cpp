#include "Editor.h"

#include <QClipboard>
#include <QGuiApplication>
#include <QMimeData>
#include <QScrollBar>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextDocument>
#include <QtTest>

struct TestEditor : Editor {
    using Editor::insertFromMimeData;
    void pasteText(const QString &t)
    {
        QMimeData md;
        md.setText(t);
        insertFromMimeData(&md);
    }
};

class TstClipboard : public QObject
{
    Q_OBJECT
    static void select(Editor &e, int from, int to)
    {
        QTextCursor c = e.textCursor();
        c.setPosition(from);
        c.setPosition(to, QTextCursor::KeepAnchor);
        e.setTextCursor(c);
    }
private slots:
    void pasteIntoEmpty_data()
    {
        QTest::addColumn<QString>("input");
        QTest::addColumn<QString>("expected");
        QTest::newRow("single line") << "hello" << "hello";
        QTest::newRow("lf") << "a\nb\nc" << "a\nb\nc";
        QTest::newRow("crlf") << "a\r\nb\r\nc" << "a\nb\nc";
        QTest::newRow("cr") << "a\rb\rc" << "a\nb\nc";
        QTest::newRow("mixed") << "a\r\nb\rc\nd" << "a\nb\nc\nd";
        QTest::newRow("blank lines") << "a\n\n\n\nb" << "a\n\n\n\nb";
        QTest::newRow("crlf blank lines") << "a\r\n\r\n\r\nb" << "a\n\n\nb";
        QTest::newRow("leading") << "\n\nx" << "\n\nx";
        QTest::newRow("trailing") << "x\n\n" << "x\n\n";
        QTest::newRow("unicode") << QString::fromUtf8("日本語\né\n\U0001F600") << QString::fromUtf8("日本語\né\n\U0001F600");
    }
    void pasteIntoEmpty()
    {
        QFETCH(QString, input);
        QFETCH(QString, expected);
        TestEditor e;
        e.pasteText(input);
        QCOMPARE(e.exportPlainText(), expected);
        QCOMPARE(e.document()->blockCount(), expected.count('\n') + 1);
        QVERIFY(e.document()->isModified());
    }
    void pasteMatchesEnterStructure()
    {
        TestEditor a, b;
        a.pasteText("x\n\n\ny");
        QTest::keyClick(&b, Qt::Key_X);
        QTest::keyClick(&b, Qt::Key_Return);
        QTest::keyClick(&b, Qt::Key_Return);
        QTest::keyClick(&b, Qt::Key_Return);
        QTest::keyClick(&b, Qt::Key_Y);
        QCOMPARE(a.exportPlainText(), b.exportPlainText());
        QCOMPARE(a.document()->blockCount(), b.document()->blockCount());
    }
    void pasteAtBeginningMiddleEnd()
    {
        TestEditor e;
        e.loadPlainText("abcd");
        e.moveCursor(QTextCursor::Start);
        e.pasteText("1\n2");
        QCOMPARE(e.exportPlainText(), QString("1\n2abcd"));
        e.loadPlainText("abcd");
        QTextCursor c = e.textCursor();
        c.setPosition(2);
        e.setTextCursor(c);
        e.pasteText("X\n");
        QCOMPARE(e.exportPlainText(), QString("abX\ncd"));
        e.loadPlainText("abcd");
        e.moveCursor(QTextCursor::End);
        e.pasteText("\nend");
        QCOMPARE(e.exportPlainText(), QString("abcd\nend"));
        QCOMPARE(e.textCursor().position(), e.document()->characterCount() - 1);
    }
    void pasteOverSelections()
    {
        TestEditor e;
        e.loadPlainText("one\ntwo\nthree");
        select(e, 1, 2);
        e.pasteText("X");
        QCOMPARE(e.exportPlainText(), QString("oXe\ntwo\nthree"));
        e.loadPlainText("one\ntwo\nthree");
        select(e, 2, 9); // across blocks
        e.pasteText("A\nB");
        QCOMPARE(e.exportPlainText(), QString("onA\nBhree"));
    }
    void pasteBesideEmptyParagraphs()
    {
        TestEditor e;
        e.loadPlainText("a\n\n\nb");
        QTextCursor c = e.textCursor();
        c.setPosition(3); // inside the blank run
        e.setTextCursor(c);
        e.pasteText("p\nq");
        QCOMPARE(e.exportPlainText(), QString("a\n\np\nq\nb"));
    }
    void multilinePasteIsOneUndoAndOneRedo()
    {
        TestEditor e;
        e.loadPlainText("base");
        e.moveCursor(QTextCursor::End);
        e.pasteText("1\n2\n\n3\r\n4");
        const QString after = e.exportPlainText();
        e.undo();
        QCOMPARE(e.exportPlainText(), QString("base"));
        QVERIFY(!e.document()->isUndoAvailable());
        QVERIFY(!e.document()->isModified()); // back at saved state
        e.redo();
        QCOMPARE(e.exportPlainText(), after);
        QVERIFY(!e.document()->isRedoAvailable());
        QVERIFY(e.document()->isModified());
    }
    void pastedBlocksUseSameFormatPolicy()
    {
        TestEditor e;
        e.pasteText("a\n\nb\nc");
        for (QTextBlock b = e.document()->begin(); b.isValid(); b = b.next()) {
            QCOMPARE(b.blockFormat().lineHeight(), 140.0);
        }
    }
    void htmlPlusPlainInsertsPlainOnly()
    {
        TestEditor e;
        QMimeData md;
        md.setText("plain");
        md.setHtml("<b style='color:red'>rich</b>");
        e.insertFromMimeData(&md);
        QCOMPARE(e.exportPlainText(), QString("plain"));
        QVERIFY(e.document()->toHtml().contains("plain"));
        QVERIFY(!e.document()->toHtml().contains("color:red"));
    }
    void htmlOnlyAndImageOnlyIgnored()
    {
        TestEditor e;
        QMimeData html;
        html.setHtml("<b>rich</b>");
        e.insertFromMimeData(&html);
        QCOMPARE(e.exportPlainText(), QString());
        QMimeData img;
        img.setImageData(QImage(4, 4, QImage::Format_RGB32));
        e.insertFromMimeData(&img);
        QCOMPARE(e.exportPlainText(), QString());
        QVERIFY(!e.document()->isModified());
    }
    void copyIsPlainTextOnly()
    {
        TestEditor e;
        e.loadPlainText("one\ntwo\n\nthree");
        e.selectAll();
        e.copy();
        const QMimeData *md = QGuiApplication::clipboard()->mimeData();
        QVERIFY(md);
        QVERIFY(md->hasText());
        QVERIFY(!md->hasHtml());
        QCOMPARE(md->text(), QString("one\ntwo\n\nthree"));
    }
    void cutCopiesAndRemovesAsOneUndo()
    {
        TestEditor e;
        e.loadPlainText("one\ntwo\nthree");
        select(e, 2, 9);
        e.cut();
        QCOMPARE(QGuiApplication::clipboard()->text(), QString("e\ntwo\nt"));
        QCOMPARE(e.exportPlainText(), QString("onhree"));
        e.undo();
        QCOMPARE(e.exportPlainText(), QString("one\ntwo\nthree"));
    }
    void copyWithoutSelectionIsSafe()
    {
        TestEditor e;
        e.loadPlainText("abc");
        QGuiApplication::clipboard()->setText("keep");
        e.copy();
        QCOMPARE(QGuiApplication::clipboard()->text(), QString("keep"));
    }
    void largePasteUpdatesScrollRange()
    {
        TestEditor e;
        e.resize(300, 200);
        e.show();
        QVERIFY(QTest::qWaitForWindowExposed(&e));
        e.pasteText(QString("line\n").repeated(500) + "last");
        QTest::qWait(30);
        QVERIFY(e.verticalScrollBar()->maximum() > 0);
        QCOMPARE(e.currentLine(), 501);
        QVERIFY(e.verticalScrollBar()->value() > 0);
    }
};

QTEST_MAIN(TstClipboard)
#include "tst_clipboard.moc"

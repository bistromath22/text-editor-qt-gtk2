#include "Editor.h"
#include "EditorFrame.h"

#include <QLayout>
#include <QTextCursor>
#include <QTextDocument>
#include <QtTest>

class TstEditorFrame : public QObject
{
    Q_OBJECT
    static QColor px(QWidget &w, int x, int y) { return w.grab().toImage().pixelColor(x, y); }
private slots:
    void borderColorRenderedAndReloadedWithoutRestart()
    {
        Editor ed;
        EditorFrame frame(&ed);
        frame.resize(300, 200);
        frame.setBorder(20, QColor("#ff0000"));
        frame.show();
        QVERIFY(QTest::qWaitForWindowExposed(&frame));
        QCOMPARE(frame.borderColor(), QColor("#ff0000"));
        QCOMPARE(px(frame, 3, 3), QColor("#ff0000"));
        QCOMPARE(px(frame, 296, 100), QColor("#ff0000"));
        QCOMPARE(px(frame, 150, 197), QColor("#ff0000")); // bottom side too: no unexplained gap
        frame.setBorder(20, QColor("#00ff00"));
        QCOMPARE(px(frame, 3, 3), QColor("#00ff00"));
        QCOMPARE(px(frame, 150, 100), ed.config().backgroundColor); // viewport keeps its own color
    }
    void sizeZeroRemovesSurroundAndPositiveRestoresIt()
    {
        Editor ed;
        EditorFrame frame(&ed);
        frame.resize(300, 200);
        frame.setBorder(0, QColor("#ff0000"));
        frame.show();
        QVERIFY(QTest::qWaitForWindowExposed(&frame));
        frame.layout()->activate();
        QCOMPARE(ed.geometry(), QRect(0, 0, 300, 200));
        frame.setBorder(20, QColor("#ff0000"));
        frame.layout()->activate();
        QCOMPARE(ed.geometry(), QRect(20, 20, 260, 160));
    }
    void borderChangesDoNotTouchDocumentState()
    {
        Editor ed;
        EditorFrame frame(&ed);
        ed.loadPlainText("hello\nworld");
        QTest::keyClicks(&ed, "x");
        ed.document()->setModified(false);
        QTextCursor c = ed.textCursor();
        c.setPosition(1);
        c.setPosition(4, QTextCursor::KeepAnchor);
        ed.setTextCursor(c);
        const int steps = ed.document()->availableUndoSteps();
        frame.setBorder(40, QColor("#123456"));
        frame.setBorder(0, QColor("#654321"));
        QVERIFY(!ed.document()->isModified());
        QCOMPARE(ed.document()->availableUndoSteps(), steps);
        QCOMPARE(ed.textCursor().selectionStart(), 1);
        QCOMPARE(ed.textCursor().selectionEnd(), 4);
        QCOMPARE(ed.exportPlainText(), QString("hellox\nworld"));
    }
    void invalidColorKeepsPreviousColor()
    {
        Editor ed;
        EditorFrame frame(&ed);
        frame.setBorder(5, QColor("#abcdef"));
        frame.setBorder(5, QColor());
        QCOMPARE(frame.borderColor(), QColor("#abcdef"));
    }
};

QTEST_MAIN(TstEditorFrame)
#include "tst_editorframe.moc"
